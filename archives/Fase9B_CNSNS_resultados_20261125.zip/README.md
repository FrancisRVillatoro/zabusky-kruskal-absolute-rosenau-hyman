# CNSNS, fase 9B — mechanism and modal transfer

**Scope.** Phase 9A is closed. Phase 9B has executed 39 independent, fixed-cutoff Fourier–Galerkin integrations locally, plus a direct audit of 84 all-node profiles exported by Picasso in 9A (42 minima + 42 common-time profiles). Full Padé detuning trajectories and flux histories remain to be executed on Picasso. Nothing in this package claims continuum convergence or a proven resonance.

## Local results

- `SPECTRAL_MECHANISM_CNSNS.tex`: mode-excitation bound, exact discrete null, finite-dimensional quadratic detuning law, modal power budget.
- `INFORME_FASE9B.md`: scientific interpretation with numerical values and limitations.
- `galerkin_cases.csv`: 39 completed cases with p=2.25, time horizon 4.25, odd harmonic cutoffs 7…51, quadrature/time controls, length variation, single-multiplier interventions and six small detunings. Flux quadrature is finite; not an exact projection of a fractional power. All integrations use DOP853; sample grid 1/3200 tau. `probe` changes one multiplier in a finite ODE, not the physical PDE.
- `results_local/summary/`: exact summary computed from the full sampled local traces, including `near_null.csv`, all fixed-window minima and all prominent chronological minima, mode statistics, signed/gross exchange and phase-coordinate comparisons. The field-normalized power is `e_n=4|a_n|^2` for the signed unit cosine. Positive/negative rates are not a conserved quadratic-energy transfer. Minima are sampled, no interpolated digits.
- `results_local/snapshot_audit/`: spectra, instantaneous power rates and near/far residual decomposition from 9A all-node fields. Signed shares distribute the interference term symmetrically; they are not local energies and can be negative for other masks/cases. Source: `Fase9A_HDF5_3831810.zip`.
- `results_local/plot_traces/`: decimated copies **for plotting only**, exact full-trace SHA256 list. The full endpoint samples (~200 MB) can be regenerated from the manifest and code; no full local traces are included in the delivery ZIP. The aggregate tables were generated from the undecimated data. Plot figures are generated directly from numerical data.
- `results_local/tests.log`, `report_smoke.log`, and `galerkin_logs/`: actual execution and test records. The three-case smoke uses actual Radau with N=900/1800 over tau=0.0025, not production results.

To reproduce the local Galerkin results (write to a fresh directory):
```
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
mkdir -p fase9b/reproduced
awk -F, 'NR>1 {print $1}' fase9b/galerkin_cases.csv | xargs -P4 -I{} python -m fase9b.galerkin --case {} --out fase9b/reproduced
python -m fase9b.analyze --input fase9b/reproduced --out fase9b/reproduced_summary --manifest fase9b/galerkin_cases.csv
python -m fase9b.near_null --input fase9b/reproduced --out fase9b/reproduced_summary/near_null.csv
python -m fase9b.snapshot_audit --source Fase9A_HDF5_3831810.zip --out fase9b/reproduced_snapshots
```
Reproduction uses existing NumPy/SciPy; Matplotlib only for figures; h5py and original `absk_radau` for production. Runtime depends on hardware. No pip installation on Picasso.

## Picasso (existing project root)

Unzip into `~/fscratch/zk_absK_recurrence/CNSNS_Fase2_Radau_Python_20261117`. Only `fase9b/` and the new SHA256 manifest are added; source solver is unchanged. `bash fase9b/submit.sh` verifies hashes and submits 4 jobs: verify, archive, main array 1–14%8, report. The 14 new trajectories are:
- eight combinations nstar=6.8,7.0,7.2,7.4 and N=900,1800, step Δτ=1/6400;
- four corresponding N=1800 controls with Δτ=1/12800 **from tau=0**;
- two exact discrete-null lengths (to floating accuracy), N=900,1800, Δτ=1/6400.
All are p=2.25, Z, nu=0, half-wave projected. M=nstar*(p-1)/p; T_cross=2*pi*nstar*2*p/(p+1). Integrations start from the initial cosine and use the same spatial operator and Newton tolerance as production, to tau=4.25. Four checkpoint blocks, no silent step halving; completed blocks are reused and incomplete files are preserved. Each accepted step stores low-mode coefficients and fluxes, enabling endpoint quadrature on a fine and a decimated grid. Physical fields are also saved on common time grids. The archived results are read-only: phase3 plus zoom and 4/4B segments (3 inviscid trajectories), phase6 (6 long and 3 short regularized trajectories). Seam equality and provenance are checked. Coarser archived cadence limits the integrated budget; compare defect and quadrature sensitivity before interpreting it. The report separates chronological prominent dips (prominence ≥0.03 after tau=0.2) from deepest local minima in j±0.2. A shallow dip in an integer window is not necessarily the corresponding return. Cross-run free events are matched by chronology and checked within 0.15 tau, but ambiguous matching remains a scientific limitation. It also computes common-time, unaligned field discrepancies, not just modal distances. New failures or missing trajectories stay in inventory.

Check `fase9b/jobs/*JOBID.txt`, `fase9b/results/archive/status.json`, `fase9b/results/report/status.json`, and `fase9b/Fase9B_CNSNS_resultados_20261125.zip`. The final zip includes archive traces, reduced new traces, all reports/logs/audits, but not large original/new HDF5 or full new endpoint traces. No external network required. A closure decision needs these data; a completed job alone is not sufficient.
