# Cierre científico de la fase 9A — 25 de noviembre de 2026

## Procedencia y verificación

Fuente: `Fase9A_HDF5_3831810.zip`, exportación de Picasso del trabajo 3831810. El ZIP contiene 18 entradas, pasa CRC y registra 42/42 perfiles, 42/42 comparaciones a tiempos comunes, 12 reproducciones contrastadas y cero errores. No contiene los HDF5 originales: esta auditoría independiente opera sobre los campos exportados. El script `audit.py` recalcula D, H, e5/H, la fase del coseno de referencia y las integrales cuadráticas del interpolante lineal periódico, para las máscaras |u|<=0.2 y distancia <=0.4 a un cruce. Los 84 perfiles (mínimos y tiempos comunes) reproducen los diagnósticos tabulados con defecto máximo 1.857e-13. Los tiempos comunes coinciden con sus objetivos en los 42 registros. La diferencia máxima entre reproducciones y originales reportada por Picasso es 4.748521e-7 en L2 normalizada y 1.750108e-6 en Linf. En N=1800, los tres primeros perfiles reproducidos coinciden hasta redondeo. Las auditorías HDF5 no se pueden repetir aquí sin los archivos fuente.

## Localización y crecimiento del residuo

En N=1800 y nu=0, las fracciones del residuo cuadrático en |u|<=0.2 son 0.805016, 0.490321, 0.169748, 0.026520. Las áreas relativas son 0.119399, 0.111547, 0.093866, 0.032669. La fracción en entornos de radio físico 0.4 de los cruces es 0.307055, 0.187826, 0.096989, 0.020780. En esos cuatro perfiles finos hay dos cruces, por lo que el área relativa de los entornos de radio fijo es 0.035368. La cuarta ventana procede del reinicio temporal de fase 4B (divisor 4), no de una integración uniforme con paso reducido desde t=0. Las integrales son las del interpolante lineal del residuo, normalizadas por L/2 (A=1). El total crece de 0.002117 a 0.056530; la parte fuera de |u|<=0.2 crece de 0.000413 a 0.055030, factor 133.3. En el radio fijo, la contribución absoluta crece de 0.000650 a 0.001175 (factor 1.81). La reducción de fracciones no implica eliminación del defecto local. Las máscaras se mueven y no constituyen una región material: no hay demostración de transporte causal.

## Regularización

En N=1800, la fracción en |u|<=0.2 al cuarto mínimo es 2.65%, 5.58%, 16.71%, 22.70% para nu=0, 0.00025, 0.001, 0.004. Para el radio 0.4 las correspondientes fracciones son 2.08%, 2.72%, 5.76%, 9.90%. A las regularizaciones estudiadas, las fracciones decrecen con el índice de retorno; el incremento de nu retrasa la pérdida de localización relativa. Esto no prueba un mecanismo de transferencia ni convergencia de la PDE. La comparación es entre mínimos individuales a diferentes tiempos según nu. En j=4, nu=0 emplea divisor 4 y nu>0 el paso base. Los presupuestos de campo tardío anteriores siguen vigentes.

## Cruces y capas

En nu=0, las secantes máximas de los cruces en los tres primeros mínimos aumentan con N, pero los incrementos por celda no muestran una tendencia hacia un salto finito. Para el primer mínimo son 0.083113, 0.064217, 0.047507 con N=450,900,1800. En el tercero, las mallas 450 y 900 registran seis cruces y la fina dos; en el cuarto, N=1800 con divisor 2 registra seis y con divisor 4 dos. Los recuentos son del interpolante lineal y sensibles al paso y la malla. No es evidencia de discontinuidad o de una ley de espesor. El máximo de la secante en el cuarto retorno fino va de 1.85475 (nu=0) a 0.14579 (nu=0.004), con diferencias temporales indicadas arriba.

## Resultado analítico y alcance bibliográfico

La proposición de 9A (ver `zero_scaling_CNSNS.tex` del paquete anterior) establece la escala de la velocidad semidiscreta inicial para datos periódicos C4 con ceros simples: Theta(h^(p-5/2)) si 1<p<5/2, Theta(sqrt(log(L/h))) si p=5/2 y convergencia en L2 del segundo miembro si p>5/2. El coeficiente subcrítico depende del offset del cero y el crítico no. No implica mala formulación ni pérdida de regularidad a tiempo positivo. La búsqueda bibliográfica focalizada no identificó esa fórmula para la matriz de masa Padé y los offsets. No es prueba de prioridad. Precedentes relevantes: de Frutos et al., JCP 120 (1995), 248–252, doi:10.1006/jcph.1995.1161; Rus y Villatoro, Math. Comput. Simul. 76 (2007), 188–192, doi:10.1016/j.matcom.2007.01.016; Ambrose et al., Nonlinearity 25 (2012), 2655–2680, arXiv:1104.2571; Zilburg y Rosenau, arXiv:1709.03322 (2017); Jeong y Oh, Anal. PDE 19 (2026), 721–782, doi:10.2140/apde.2026.19.721. Distinguir resultados sobre pérdida de regularidad, choques y mala formulación de nuestro análisis de consistencia localizado del segundo miembro discreto.

## Decisión

9A cerrada en su alcance analítico y computacional. No se requieren nuevas integraciones para cerrar esta fase. No se reivindica prioridad absoluta, convergencia fuerte de la evolución, discontinuidad ni inestabilidad del continuo. La próxima fase 9B debe contrastar el mecanismo modal, incluyendo el efecto del nulo del multiplicador y la transferencia de potencia al quinto modo, sin confundir correlación con causalidad.
