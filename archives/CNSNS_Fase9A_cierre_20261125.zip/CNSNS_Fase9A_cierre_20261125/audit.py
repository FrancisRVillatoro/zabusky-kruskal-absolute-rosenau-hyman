"""Independent audit of the exported profiles, not raw HDF5 (not included).
Usage: python audit.py Fase9A_HDF5_3831810.zip [output_dir]
"""
import sys, zipfile, json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

K=['j','N','nu','divisor']
L=14.4*np.pi

def check_archive(path,out):
    out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        status=json.loads(z.read('status.json'))
        assert status['completed']==status['common_profiles']==42 and status['errors']==0
        replay=pd.read_csv(z.open('replay_vs_original_HDF5.csv'))
        assert len(replay)==12 and (replay.status=='COMPARED').all()
        inventory=pd.read_csv(z.open('inventory.csv'))
        assert len(inventory)==42 and (inventory.status=='OK').all()
        rows=[]
        for sel in ['minima','common_times']:
            s=pd.read_csv(z.open(sel+'/summary.csv'))
            a=pd.read_csv(z.open(sel+'/amplitude_localization.csv'))
            b=pd.read_csv(z.open(sel+'/distance_localization.csv'))
            p=pd.read_csv(z.open(sel+'/profiles.csv'))
            assert len(s)==42 and len(a)==42*9 and len(b)==42*7
            if sel=='common_times': assert np.max(abs(s.tau-s.target_tau))<1e-12
            table=s.merge(a[np.isclose(a.level,.2)][K+['pl_area_fraction','pl_residual_fraction']],on=K,validate='one_to_one').merge(b[np.isclose(b.radius,.4)][K+['pl_area_fraction','pl_residual_fraction']],on=K,suffixes=('_amp','_rad'),validate='one_to_one').set_index(K)
            for key,g in p.groupby(K):
                j,n,nu,d=key; g=g.sort_values('index'); assert np.array_equal(g['index'],np.arange(n))
                u=g.u.to_numpy(); assert np.isfinite(u).all()
                t=table.loc[key]; x=2*np.pi*np.arange(n)/n
                a1=np.mean(u*np.exp(-1j*x)); ref=np.cos(x+np.angle(a1)); e=u-ref
                D=np.sqrt(2*np.mean(e**2)); H=2*np.mean((u-u.mean())**2)-4*abs(a1)**2
                e5=4*abs(np.mean(u*np.exp(-5j*x)))**2/H
                nxt=np.roll(e,-1); norm=np.sum((e**2+e*nxt+nxt**2)/3)
                # Integrate the squared linear residual over a clipped segment of each cell.
                v=np.roll(u,-1); du=v-u; good=du!=0
                lo=np.zeros(n); hi=np.ones(n)
                aa=(-.2-u[good])/du[good]; bb=(.2-u[good])/du[good]
                lo[good]=np.clip(np.minimum(aa,bb),0,1); hi[good]=np.clip(np.maximum(aa,bb),0,1)
                hi[~good & (abs(u)>.2)]=0
                width=np.maximum(hi-lo,0); el=e+lo*(nxt-e); er=e+hi*(nxt-e)
                val=np.sum(width*(el**2+el*er+er**2)/3)
                # Independent fixed-radius integration: split periodic intervals at cell endpoints.
                roots=[i-u[i]/du[i] for i in range(n) if u[i]*v[i]<0]
                for i in np.where(u==0)[0]:
                    if u[(i-1)%n]*u[(i+1)%n]<0: roots.append(float(i))
                rr=.4/(L/n); intervals=[]
                for r in roots:
                    for q in (r-n,r,r+n):
                        l=max(0,q-rr); h=min(n,q+rr)
                        if h>l: intervals.append((l,h))
                merged=[]
                for l,h in sorted(intervals):
                    if merged and l<=merged[-1][1]: merged[-1]=(merged[-1][0],max(h,merged[-1][1]))
                    else: merged.append((l,h))
                dist=0.; area=0.
                for l,h in merged:
                    area+=h-l
                    for i in range(int(np.floor(l)),int(np.ceil(h))):
                        a0=max(l,i)-i; b0=min(h,i+1)-i
                        if b0<=a0:continue
                        yl=e[i]+a0*(nxt[i]-e[i]); yr=e[i]+b0*(nxt[i]-e[i]);dist+=(b0-a0)*(yl**2+yl*yr+yr**2)/3
                errs=[abs(D-t.D),abs(H-t.H),abs(e5-t.e5_over_H),abs(np.sqrt(2*norm/n)-t.pl_D),abs(width.sum()/n-t.pl_area_fraction_amp),abs(val/norm-t.pl_residual_fraction_amp),abs(area/n-t.pl_area_fraction_rad),abs(dist/norm-t.pl_residual_fraction_rad),np.max(abs(ref-g.aligned_initial.to_numpy()))]
                assert max(errs)<1e-9,(sel,key,errs)
                rows.append(dict(selection=sel,j=j,N=n,nu=nu,divisor=d,tau=t.tau,D=D,r=2*abs(a1),H=H,e5_over_H=e5,n_roots=len(roots),pl_D=np.sqrt(2*norm/n),area_amp=width.sum()/n,fraction_amp=val/norm,area_rad=area/n,fraction_rad=dist/norm,residual_total=2*norm/n,residual_amp=2*val/n,residual_outside_amp=2*(norm-val)/n,residual_rad=2*dist/n,max_secant=t.max_secant,max_cell_jump=t.max_cell_jump,max_check_defect=max(errs)))
        d=pd.DataFrame(rows).sort_values(['selection','nu','j','N','divisor'])
        d.to_csv(out/'profiles_recomputed.csv',index=False)
        d=d[(d.selection=='minima')&(d.N==1800)&~((d.nu==0)&(d.divisor==2))]
        d.to_csv(out/'finest_returns.csv',index=False)
        metrics=dict(profiles_recomputed=84,max_check_defect=float(pd.read_csv(out/'profiles_recomputed.csv').max_check_defect.max()),max_replay_L2=float(replay.L2_normalized.max()),max_replay_Linf=float(replay.Linf.max()),max_catalog_D_defect=float(inventory.field_D_max_defect.max()))
        (out/'audit_status.json').write_text(json.dumps(metrics,indent=2)+'\n')
        print(metrics)
        for metric,label,filename in [('fraction_amp','Residual fraction in |u| ≤ 0.2','fraction_amplitude'),('fraction_rad','Residual fraction within distance 0.4 of a crossing','fraction_radius')]:
            fig,ax=plt.subplots(figsize=(6.4,4.2));
            for nu,g in d.groupby('nu'):
                g=g.sort_values('j'); ax.plot(g.j,100*g[metric],marker='o',label=f'ν = {nu:g}')
            ax.set(xlabel='Return index',ylabel=label+' (%)',xticks=[1,2,3,4]);ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(out/(filename+'.png'),dpi=180);plt.close(fig)
        g=d[d.nu==0].sort_values('j');fig,ax=plt.subplots(figsize=(6.4,4.2));
        for key,label in [('residual_total','Total'),('residual_amp','Inside |u| ≤ 0.2'),('residual_outside_amp','Outside |u| ≤ 0.2'),('residual_rad','Within distance 0.4')]:ax.semilogy(g.j,g[key],marker='o',label=label)
        ax.set(xlabel='Return index',ylabel='Squared residual normalized by L/2',xticks=[1,2,3,4]);ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(out/'absolute_residual.png',dpi=180);plt.close(fig)

if __name__=='__main__':check_archive(sys.argv[1],Path(sys.argv[2]) if len(sys.argv)>2 else Path('audit_output'))
