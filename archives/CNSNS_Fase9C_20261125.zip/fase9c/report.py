"""Audit complete or partial runs. Compare only common, exact output times.
Large fields stay on Picasso; export numerical diagnostics and audit records.
"""
import argparse,csv,json,itertools,math,zipfile
from pathlib import Path
import numpy as np
import h5py
from .tangent import NAMES,rms,even,odd,subspace_log_gain
from .run import metadata
LN10=np.log(10.)

def write_csv(path,rows,fields=None):
    if fields is None:fields=list(dict.fromkeys(k for r in rows for k in r)) or ['empty']
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def load_case(row,root):
    meta=metadata(row);folder=Path(root)/meta['case'];pieces=[];audits=[];error='';last=-1.
    for f in sorted(folder.glob('seg*.h5')):
        af=f.with_suffix('.audit.json')
        try:
            with h5py.File(f,'r') as h:
                assert json.loads(h.attrs['meta'])==meta,'metadata mismatch'
                if not af.exists():raise ValueError('missing segment audit')
                a=json.loads(af.read_text());assert a['meta']==meta
                assert h.attrs['status']==a['status']
                assert a['accepted']==round((a['last_tau']-a['start'])*meta['K'])
                assert a['max_scaled_residual']<=1+1e-10 and a['max_tangent_backward_error']<=1e-10
                x={g:{k:d[:] for k,d in h[g].items()} for g in ('trace','field')}
                for g in x:
                    t=x[g]['tau'];assert len(t)>0 and np.all(np.diff(t)>0)
                    assert all(len(v)==len(t) and np.all(np.isfinite(v)) for v in x[g].values())
                assert abs(x['field']['tau'][-1]-a['last_tau'])<1e-12
                if pieces:
                    assert abs(last-x['field']['tau'][0])<1e-12
                    for k in ('u','W','logs'):
                        if k in x['field']:assert np.array_equal(pieces[-1]['field'][k][-1],x['field'][k][0]),'checkpoint mismatch'
                else:assert x['field']['tau'][0]==0.
                last=a['last_tau'];pieces.append(x);audits.append(a)
                if a['status']!='COMPLETED':error=a.get('failure') or 'failed';break
        except Exception as e:error=str(e);break
    if not pieces:return dict(meta=meta,status='MISSING_OR_INVALID',last_tau=0.,error=error or 'no valid segments',audits=[])
    data={g:{k:np.concatenate([x[g][k] if i==0 else x[g][k][1:] for i,x in enumerate(pieces)],axis=0) for k in pieces[0][g]} for g in ('trace','field')}
    complete=not error and abs(last-meta['tau_end'])<1e-12
    return dict(meta=meta,status='COMPLETED' if complete else 'PARTIAL',last_tau=last,error=error,audits=audits,**data)

def common(a,b):
    # All regular field samples at j/100; never match an off-grid failure by rounding.
    def keys(x):
        t=x['tau'];i=np.where(abs(t*100-np.round(t*100))<1e-8)[0];return np.round(t[i]*100).astype(int),i
    ka,ia=keys(a);kb,ib=keys(b);key,i,j=np.intersect1d(ka,kb,return_indices=True);return key/100,ia[i],ib[j]

def invrow(c):
    a=c['audits'];m=c['meta'];r=dict(**m,status=c['status'],last_tau=c['last_tau'],error=c['error'],segments=len(a))
    for k in ('max_scaled_residual','max_stage_odd_defect','max_tangent_backward_error','max_relative_mean_leak','max_absolute_I_change','max_absolute_mean'):
        r[k]=max((v[k] for v in a),default=None)
    r['accepted']=sum(v['accepted'] for v in a);r['seconds']=sum(v['seconds'] for v in a)
    if a and m['kind']=='tangent':
        for j,name in enumerate(NAMES):r['peak_log10_G_'+name]=max(v['peak_log_gain'][j] for v in a)/LN10
    return r

def same(a,b,exclude):return all(a[k]==b[k] for k in ('p','M','N','K','nu','method','strict','kind','eps') if k not in exclude)

def compare_tangent(a,b,kind):
    A,B=a['field'],b['field'];ma,mb=a['meta'],b['meta'];ta,i,j=common(A,B)
    if mb['N']%ma['N']:return []
    stride=mb['N']//ma['N'];rows=[]
    for t,ii,jj in zip(ta,i,j):
        row=dict(comparison=kind,case_a=ma['case'],case_b=mb['case'],tau=t,base_L2=float(rms(A['u'][ii]-B['u'][jj,::stride])*np.sqrt(2)),S8_log10_gain_delta=(subspace_log_gain(B['W'][jj],B['logs'][jj])-subspace_log_gain(A['W'][ii],A['logs'][ii]))/LN10)
        # Grid probe changes with N; it is not a fixed perturbation, so omit it.
        for k,name in enumerate(NAMES[:-1]):
            x=A['W'][ii,:,k];y=B['W'][jj,::stride,k];la=A['logs'][ii,k];lb=B['logs'][jj,k];s=max(la,lb);x=x*np.exp(la-s);y=y*np.exp(lb-s)
            row[name+'_log10_gain_delta']=(lb-la)/LN10
            row[name+'_relative_vector_difference']=float(rms(x-y)/max(rms(x),rms(y),1e-300))
        rows.append(row)
    return rows

def finite_comparison(tan,nl,noise):
    m=nl['meta'];ep=m['eps'];A=tan['field'];B=nl['field'];ta,i,j=common(A,B);rows=[]
    noise_by_tau={} if noise is None else {round(t*100):u for t,u in zip(noise['field']['tau'],noise['field']['u']) if abs(t*100-round(t*100))<1e-8}
    for t,ii,jj in zip(ta,i,j):
        u=B['u'][jj];v=even(u)[:len(u)//2];vnorm=rms(v);la=A['logs'][ii,0];gain=rms(v)/(abs(ep)/np.sqrt(2));lg=np.log(gain) if gain>0 else -np.inf
        # Relative comparison in a common scale; use signed normalized perturbation.
        s=max(la,lg);x=A['W'][ii,:,0]*np.exp(la-s);y=(v/vnorm*np.sign(ep)*np.exp(lg-s)) if vnorm>0 else np.zeros_like(v)
        refnoise=noise_by_tau.get(round(t*100));noiseamp=float(rms(even(refnoise))) if refnoise is not None else None
        rows.append(dict(tangent=tan['meta']['case'],nonlinear=m['case'],eps=ep,tau=t,log10_G_tangent=la/LN10,log10_G_nonlinear=lg/LN10,relative_vector_difference=float(rms(x-y)/max(rms(x),rms(y),1e-300)),even_rms=float(vnorm),unperturbed_even_rms=noiseamp,noise_to_signal=(noiseamp/max(vnorm,1e-300) if noiseamp is not None else None),odd_base_L2=float(rms(odd(u)-A['u'][ii])*np.sqrt(2)),D_full=float(np.sqrt(2)*rms(u-A['u'][ii]))))
    return rows

def replay_comparison(c,root):
    if c is None:return []
    A=c['field'];rows=[]
    for f in sorted(Path(root).glob('seg*.h5')):
        try:
            with h5py.File(f,'r') as h:
                if h.attrs['status']!='COMPLETED':continue
                cfg=json.loads(h.attrs['config_json']);assert cfg['N']==c['meta']['N'] and cfg['steps_per_tau']==c['meta']['K']
                assert cfg['case']=='s7.2_N1800_d4'
                B={'tau':h['t'][:]/c['meta']['T'],'u':h['u'][:]};ta,i,j=common(A,B)
                for t,ii,jj in zip(ta,i,j):rows.append(dict(source=str(f),tau=t,normalized_L2=float(np.sqrt(2)*rms(A['u'][ii]-B['u'][jj]))))
        except Exception as e:rows.append(dict(source=str(f),error=str(e)))
    return rows

def analyze(manifest,root,out,refroot='fase9b/results/new/s7.2_N1800_d4'):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    with open(manifest) as f:rows=list(csv.DictReader(f))
    cases=[load_case(r,root) for r in rows];good=[c for c in cases if 'field'in c];tans=[c for c in good if c['meta']['kind']=='tangent'];nls=[c for c in good if c['meta']['kind']=='nonlinear']
    write_csv(out/'inventory.csv',[invrow(c) for c in cases]);tr=[];summary=[]
    for c in good:
        m=c['meta'];T=c['trace'];name=m['case'];is_tan=m['kind']=='tangent'
        for i,t in enumerate(T['tau']):
            r=dict(case=name,tau=t,D=T['D'][i],even_rms=T['even_rms'][i],I_relative=T['I_relative'][i],mean=T['mean'][i])
            if is_tan:r.update({f'log10_G_{s}':v/LN10 for s,v in zip(NAMES,T['log_gain'][i])});r['log10_G_S8']=T['log_subspace_gain'][i]/LN10
            elif m['eps']!=0:r['log10_G_nonlinear']=np.log10(max(T['even_rms'][i]*np.sqrt(2)/abs(m['eps']),1e-300))
            tr.append(r)
        if is_tan:
            for t in (.02,.10,.25,.5,1.,1.25,2.,2.25,3.,3.25,4.,4.25):
                ii=np.flatnonzero(abs(T['tau']-t)<1e-11)
                if len(ii)!=1:continue
                i=ii[0];r=dict(case=name,tau=t,N=m['N'],p=m['p'],M=m['M'],K=m['K'],nu=m['nu'],method=m['method'],strict=m['strict'],log10_G_S8=T['log_subspace_gain'][i]/LN10)
                for s,v in zip(NAMES,T['log_gain'][i]):r['log10_G_'+s]=v/LN10;r['gamma_tau_'+s]=v/t;r['gamma_physical_'+s]=v/(t*m['T'])
                summary.append(r)
    write_csv(out/'gain_traces.csv',tr);write_csv(out/'gain_at_times.csv',summary)
    from scipy.signal import find_peaks
    events=[];local=[]
    for c in tans:
        m=c['meta'];T=c['trace'];F=c['field'];ids,props=find_peaks(-T['D'],prominence=.03)
        for j,(i,prom) in enumerate(((i,q) for i,q in zip(ids,props['prominences']) if T['tau'][i]>=.2),1):
            r=dict(case=m['case'],j=j,tau=T['tau'][i],D=T['D'][i],prominence=prom,log10_G_S8=T['log_subspace_gain'][i]/LN10)
            r.update({f'log10_G_{s}':v/LN10 for s,v in zip(NAMES,T['log_gain'][i])});events.append(r)
        for t,u,W,lg in zip(F['tau'],F['u'],F['W'],F['logs']):
            # Output vector of the optimal input *within the 8-dimensional subspace* at this time.
            q=lg[:8];scale=max(q);scaled=W[:,:8]*np.exp(q-scale);left,sv,right=np.linalg.svd(scaled,full_matrices=False)
            mask=abs(u[:m['N']//2]);n=2*np.arange(W.shape[0]//2+1)
            for name,v in [('cos2',W[:,0]),('near_zeros',W[:,-2]),('grid_probe',W[:,-1]),('S8_output',left[:,0]*np.sqrt(len(left)))]:
                power=abs(np.fft.rfft(v,norm='forward'))**2;power*=2;power[0]/=2
                if len(v)%2==0:power[-1]/=2
                local.append(dict(case=m['case'],tau=t,probe=name,small_amplitude_domain=float(np.mean(mask<=.2)),fraction_abs_u_le_0p1=float(np.sum(v[mask<=.1]**2)/np.sum(v*v)),fraction_abs_u_le_0p2=float(np.sum(v[mask<=.2]**2)/np.sum(v*v)),fraction_modes_gt20=float(power[n>20].sum()/power.sum()),fraction_modes_ge_Nover4=float(power[n>=m['N']/4].sum()/power.sum())))
    write_csv(out/'return_gains.csv',events);write_csv(out/'tangent_localization.csv',local)
    pairs=[]
    for a,b in itertools.combinations(tans,2):
        ma,mb=a['meta'],b['meta'];kind=None
        for k,tag in [('N','space'),('K','time'),('method','integrator'),('nu','regularization'),('strict','newton')]:
            if ma[k]!=mb[k] and same(ma,mb,{k}):kind=tag;break
        if kind is None:continue
        if ma['N']>mb['N'] or (ma['N']==mb['N'] and ma['K']>mb['K']):a,b=b,a
        pairs+=compare_tangent(a,b,kind)
    write_csv(out/'tangent_comparisons.csv',pairs)
    fd=[]
    for n in nls:
        if n['meta']['eps']==0:continue
        tan=next((t for t in tans if same(t['meta'],n['meta'],{'eps','kind'})),None)
        noise=next((z for z in nls if z['meta']['eps']==0 and same(z['meta'],n['meta'],{'eps'})),None)
        if tan is not None:fd+=finite_comparison(tan,n,noise)
    write_csv(out/'nonlinear_comparisons.csv',fd)
    sym=[]
    for a in nls:
        if a['meta']['eps']<=0:continue
        b=next((b for b in nls if b['meta']['eps']==-a['meta']['eps'] and same(a['meta'],b['meta'],{'eps'})),None)
        if b is None:continue
        A,B=a['field'],b['field'];ta,i,j=common(A,B)
        for t,ii,jj in zip(ta,i,j):sym.append(dict(plus=a['meta']['case'],minus=b['meta']['case'],tau=t,normalized_symmetry_difference=float(np.sqrt(2)*rms(B['u'][jj]+np.roll(A['u'][ii],a['meta']['N']//2)))))
    write_csv(out/'paired_symmetry.csv',sym)
    ref=next((c for c in tans if c['meta']['p']==2.25 and c['meta']['M']==4 and c['meta']['N']==1800 and c['meta']['K']==12800 and c['meta']['nu']==0 and c['meta']['method']=='radau' and not c['meta']['strict']),None)
    replay=replay_comparison(ref,refroot);write_csv(out/'replay_9b.csv',replay)
    status=dict(expected=len(rows),complete=sum(c['status']=='COMPLETED' for c in cases),partial=sum(c['status']=='PARTIAL' for c in cases),missing_or_invalid=sum(c['status']=='MISSING_OR_INVALID' for c in cases),valid_tangent=len(tans),valid_nonlinear=len(nls),fd_comparisons=len(set(r['nonlinear'] for r in fd)),replay_samples=sum('normalized_L2'in r for r in replay),scientific_convergence_certified=False)
    (out/'status.json').write_text(json.dumps(status,indent=2)+'\n');return status

def figures(out):
    import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
    out=Path(out);inv=list(csv.DictReader(open(out/'inventory.csv')));tr=list(csv.DictReader(open(out/'gain_traces.csv')))
    for p,M,fig in [(2.25,4,'central'),(2.,8,'M8')]:
        f,axs=plt.subplots(2,2,figsize=(10,7),sharex=True);count=0
        for m in inv:
            if float(m['p'])!=p or float(m['M'])!=M or m['kind']!='tangent' or float(m['nu'])!=0 or m['method']!='radau' or int(m['strict']):continue
            t=[r for r in tr if r['case']==m['case']];
            if not t:continue
            count+=1;x=[float(r['tau']) for r in t]
            for ax,key,label in zip(axs.flat,['cos2','S8','near_zeros','grid_probe'],['cosine 2','8-mode subspace','near-zero probe','mesh-dependent probe']):
                ax.plot(x,[float(r['log10_G_'+key]) for r in t],label=f"N={m['N']}, K={m['K']}");ax.set_title(label);ax.set_ylabel('log10 gain');ax.grid(alpha=.2);ax.set_xlabel('tau')
        if count:axs[0,0].legend(fontsize=7);f.tight_layout();f.savefig(out/(fig+'_gains.png'),dpi=180)
        plt.close(f)

def main():
    a=argparse.ArgumentParser();a.add_argument('--manifest',default='fase9c/campaign.csv');a.add_argument('--root',default='fase9c/results/cases');a.add_argument('--out',default='fase9c/results/report');a.add_argument('--zip',default='fase9c/Fase9C_CNSNS_resultados_20261125.zip');a.add_argument('--refroot',default='fase9b/results/new/s7.2_N1800_d4');args=a.parse_args()
    status=analyze(args.manifest,args.root,args.out,args.refroot);figures(args.out)
    dest=Path(args.zip);dest.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.write(args.manifest,'campaign.csv')
        for f in sorted(Path(args.out).glob('*')):
            if f.is_file():z.write(f,'report/'+f.name)
        for f in sorted(Path(args.root).glob('*/*.audit.json')):z.write(f,'audits/'+str(f.relative_to(args.root)))
        for f in sorted(Path('fase9c/logs').glob('*')):
            if f.is_file():z.write(f,'logs/'+f.name)
        for f in sorted(Path('fase9c/jobs').glob('*JOBID.txt')):z.write(f,'jobs/'+f.name)
    with zipfile.ZipFile(dest) as z:assert z.testzip() is None
    print('FASE9C_ANALISIS_'+('COMPLETO' if status['complete']==status['expected'] else 'PARCIAL'),json.dumps(status),flush=True);print('FASE9C_PAQUETE_OK',dest,flush=True)
if __name__=='__main__':main()
