# CNSNS — Fase 9C (25 noviembre 2026)

## Objetivo y alcance

Medir la amplificación transversal de tiempo finito en Z, sin confundirla con inestabilidad asintótica o ill-posedness de la PDE. Se diferencia la ecuación implícita de etapa de Radau IIA5 en la trayectoria proyectada, sin aplicar la proyección impar al vector tangente. No se interpola la trayectoria entre snapshots. Se repite la base desde tau=0 porque las etapas internas no están guardadas en los HDF5 anteriores. AVF proporciona un segundo integrador; su conservación del funcional no implica ausencia de error de fase ni conservación de volumen.

Código original de fase 2 comprobado por SHA256 (`SOURCE_BASE.sha256`). Se reutiliza sin modificar `absk_radau/model.py` y `absk_radau/radau_mass.py`. El AVF adapta la media de flujo del suplemento revisado (controls/avf_control.py); se usa un nuevo Newton disperso y su tangente analítica, no se presume reproducir bit a bit ese control previo.

## Diseño: 42 tareas, todas simultáneas si Slurm concede recursos

- 7 tangentes centrales sin nu: N=450,900,1800,3600; K=12800 (tau=4.25); K=25600 en N=900,1800 hasta 4.25 y en N=3600 hasta 1.25.
- 6 tangentes centrales regularizadas: nu=0.00025, 0.001, 0.004 a N=900,1800, K=12800, tau=4.25. Control de sensibilidad, no refinamiento temporal completo de estas tres regularizaciones.
- 4 tangentes centrales AVF: N=450,900,1800 a K=12800; N=1800 a K=25600; tau=4.25. Los fallos previos de AVF en N=900 justifican conservar también los prefijos.
- 5 tangentes Z,p=2,M=8: N=1000,2000,4000, K=27200; N=2000,4000 K=54400. tau=1.25. Todos los refinamientos desde cero.
- 19 no lineales sin proyección: cuatro combinaciones de caso/malla a epsilon=0, 10^-8, 10^-7, 10^-6; una pareja de signo negativo en central N=1800 y dos controles K=25600. epsilon es la razón RMS inicial de la perturbación y del coseno, dirección cos2 de RMS unidad.
- 1 tangente Radau con tolerancia Newton cien veces más estricta, N=1800, K=12800, tau=1.25.

`--array=1-42` sin throttle. Nunca M<N<999. K=pasos por travesía; dt=T_cross/K. Cada tarea solicita un CPU, 12 GB y 2 días. Todos los cálculos se ejecutan con Slurm, Python 3.14.3, threads BLAS=1. No se cambia paso, ni nu, ni tolerancia al fallar. Se usan alternativas de predictor y de número de iteraciones a la misma tolerancia. Se conservan los bloques completos e incompletos por separado. No relanzar automáticamente los fallos.

## Diagnósticos

Se propagan ocho direcciones Fourier ortonormales (cos/sin n=2,4,6,8), una dirección localizada suave `exp[-(cos(theta)/0.12)^2]` de media retirada, y una sonda de malla `n=2 floor(N/8)`, ambas de RMS unidad. La sonda de malla no es una dirección fija al refinar. Se conservan logaritmos naturales de ganancias por columna y el máximo restringido al subespacio de ocho modos (S8), no el máximo sobre todo el espacio. Los logaritmos de las salidas tabuladas son base 10; gamma usa log natural y se expresa tanto en tau como en tiempo físico. Los campos y las direcciones normalizadas se guardan cada 0.01 tau y los escalares cada 0.0025. Se exporta también el pico por paso de cada dirección. El informe mide simetría de las etapas, defecto de media, error hacia atrás de la resolución lineal, residuo Newton e invariante.

El análisis no lineal compara la parte par del campo (dividida por epsilon y RMS inicial) con la tangente, incluyendo diferencias vectoriales y nivel de ruido de la corrida epsilon=0. La pareja ± comprueba la equivariancia. No se resta la fuga de simetría sin justificación. El ensayo de ruido numérico no estima por sí solo una tasa de crecimiento.

Los campos se comparan a tiempos comunes exactos, restringiendo la malla fina a los nodos gruesos (solo mallas anidadas). `tangent_localization.csv` mide fracciones discretas de norma cuadrática de las direcciones finales en regiones de amplitud pequeña y bandas de Fourier; es un diagnóstico de nodos, distinto del interpolante de 9A. Los retornos se detectan como mínimos muestreados con prominencia 0.03 y tau>=0.2, siguiendo 9B; no se obliga a un mínimo dentro de una ventana entera. `replay_9b.csv` compara la base central N=1800,K=12800 con los HDF5 de 9B existentes en los tiempos comunes; si el HDF5 no existe, se registra la ausencia de comparación. No se sustituyen trayectorias por los resultados de otra ejecución.

## Ejecución

En la raíz de CNSNS_Fase2_Radau_Python_20261117, extraer el ZIP. `bash fase9c/submit.sh` comprueba ambos manifiestos y lanza verificación, array y análisis dependiente `afterany` (incluye prefijos válidos). JOBID limpios en fase9c/jobs/. `squeue -l`; `sacct -j <JOBID>`. No relanzar si existen identificadores de esta campaña.

Salida: `fase9c/Fase9C_CNSNS_resultados_20261125.zip`. Incluye `campaign.csv`, tablas de inventario, ganancias temporales, ganancias en mínimos, comparaciones entre mallas/métodos/pasos, localización de perturbaciones, comparación no lineal, pareja simétrica, replay, auditorías, registros y figuras. Los HDF5 completos permanecen en Picasso. No se modifica ningún archivo de fases anteriores. El informe nunca certifica automáticamente convergencia científica.

## Validación local

`python -m unittest discover -s fase9c/tests -v` y `python -m fase9c.local_pilots --indices 1 2 3 4 5 6 7 8 --summarize` desde la raíz. Los pilotos adjuntos son integraciones reales cortas, no resultados de las trayectorias largas: tau=0.02 para el caso central, tau=0.01 para M=8. No repetir en la misma carpeta si se desea cambiar la configuración. Sus HDF5 y auditorías acompañan al paquete. Ver INFORME_FASE9C.md.
