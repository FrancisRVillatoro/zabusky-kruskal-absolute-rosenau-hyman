import csv,tempfile,unittest,json
from pathlib import Path
import numpy as np
from scipy.sparse.linalg import splu
from absk_radau.model import PeriodicAbsK,make_initial_data
from absk_radau.radau_mass import A_R
from fase9c.tangent import *
from fase9c.run import run,metadata
from fase9c.report import analyze,load_case
from fase9c.design import make

class Tests(unittest.TestCase):
    def setUp(self):
        self.model=PeriodicAbsK(80,2*np.pi*7.2,2.25);self.half=half_model(self.model);self.u=odd(make_initial_data(self.model));self.W,_=seeds(self.model);self.dt=.003
    def test_seed_basis(self):
        self.assertLess(np.max(abs(self.W.mean(axis=0))),1e-14)
        np.testing.assert_allclose(self.W[:,:8].T@self.W[:,:8]/len(self.W),np.eye(8),atol=1e-13)
    def test_restriction(self):
        for a,b in [(self.model.mass,self.half.mass),(self.model.K,self.half.K),(self.model.Q2,self.half.Q2)]:
            v=self.W[:,0];np.testing.assert_allclose((a@np.tile(v,2))[:len(v)],b@v,rtol=1e-10,atol=1e-11)
    def test_commutes_and_trace(self):
        J=self.model.jac(self.u);v=np.tile(self.W[:,0],2);np.testing.assert_allclose(J@v,even(J@v),atol=1e-12)
        A=self.half._mass_lu.solve(jac_weight(self.half,self.model.p*abs(self.u[:self.half.n])**(self.model.p-1)).toarray());self.assertLess(abs(np.trace(A)),1e-12)
    def test_radau_centered_fd(self):
        u,d,_,s=advance_radau(radau_variants(self.model,True,True),self.u,self.dt);X,defect,back=tangent_radau(self.half,s,self.W,self.dt)
        sol=radau_variants(self.model,False,True);v=np.tile(self.W[:,0],2);e=1e-5
        fd=(advance_radau(sol,self.u+e*v,self.dt)[0]-advance_radau(sol,self.u-e*v,self.dt)[0])/(2*e)
        self.assertLess(rms(fd-np.tile(X[:,0],2)),2e-8);self.assertLess(back,1e-12)
    def test_radau_full_stage_solve(self):
        sol=radau_variants(self.model,True,True);u,d,_,s=advance_radau(sol,self.u,self.dt)
        X,_,_=tangent_radau(self.half,s,self.W,self.dt);full=np.tile(self.W,(2,1));rhs=np.tile(self.model.mass@full,(3,1));ref=splu(sol[0][1].stage_jacobian(s,self.dt)).solve(rhs)[2*self.model.n:]
        np.testing.assert_allclose(np.tile(X,(2,1)),ref,atol=1e-11,rtol=1e-11)
    def test_avf_centered_fd_and_I(self):
        sol=AVF(self.model,True,True);u,d,_,s=sol.step(self.u,self.dt);X,_,back=tangent_avf(self.half,self.u,s,self.W,self.dt,sol.flux)
        other=AVF(self.model,False,True);v=np.tile(self.W[:,0],2);e=1e-5;fd=(other.step(self.u+e*v,self.dt)[0]-other.step(self.u-e*v,self.dt)[0])/(2*e)
        self.assertLess(rms(fd-np.tile(X[:,0],2)),2e-8);self.assertLess(back,1e-12);self.assertLess(abs(self.model.lp_invariant(u)/self.model.lp_invariant(self.u)-1),1e-11)
    def test_unprojected_pair(self):
        v=np.tile(self.W[:,0],2)*1e-6;sol=radau_variants(self.model,False,True);a=advance_radau(sol,self.u+v,self.dt)[0];b=advance_radau(sol,self.u-v,self.dt)[0];np.testing.assert_allclose(b,-np.roll(a,len(a)//2),atol=1e-12)
    def test_norm_tracking_and_gain(self):
        z=np.zeros(10);X=self.W*np.arange(1,11);Y,l,leak=update(self.W,X,z);np.testing.assert_allclose(np.exp(l),np.arange(1,11),atol=1e-14);np.testing.assert_allclose(Y,self.W,atol=1e-14);self.assertAlmostEqual(np.exp(subspace_log_gain(Y,l)),8.)
    def test_campaign(self):
        r=make();self.assertEqual(len(r),42);self.assertEqual(len(set(v['case'] for v in r)),len(r));self.assertTrue(all(x['K']%400==0 and x['N']%2==0 for x in r))
    def test_runner_report_real(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t);root=path/'cases';base=dict(p=2.25,M=4,N=80,K=400,tau_end=.02,nu=0.,method='radau',kind='tangent',eps=0.,strict=1)
            rows=[dict(index=1,case='tan',**base),dict(index=2,case='fine',**(base|dict(N=160))),dict(index=3,case='noise',**(base|dict(kind='nonlinear'))),dict(index=4,case='plus',**(base|dict(kind='nonlinear',eps=1e-6))),dict(index=5,case='minus',**(base|dict(kind='nonlinear',eps=-1e-6))),dict(index=6,case='missing',**base)]
            for r in rows[:-1]:run(r,root)
            run(rows[0],root)  # exact existing complete segment, no overwrite
            man=path/'manifest.csv'
            with man.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            stat=analyze(man,root,path/'report',path/'no_ref');self.assertEqual(stat['complete'],5);self.assertEqual(stat['missing_or_invalid'],1);self.assertEqual(stat['fd_comparisons'],2)
            fd=list(csv.DictReader(open(path/'report/nonlinear_comparisons.csv')));self.assertGreater(len(fd),0);self.assertLess(max(float(x['relative_vector_difference']) for x in fd),2e-4)
            sym=list(csv.DictReader(open(path/'report/paired_symmetry.csv')));self.assertLess(max(float(x['normalized_symmetry_difference']) for x in sym),1e-10)
if __name__=='__main__':unittest.main()
