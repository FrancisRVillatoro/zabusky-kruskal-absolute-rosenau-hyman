"""Replay the base and propagate its discrete transverse tangent, or integrate
an unprojected finite perturbation. Fixed time grid; no replacement of failures.
HDF5 per block, with the full accepted checkpoint and separate sample cadences.
"""
import argparse,csv,json,time,traceback
from pathlib import Path
import numpy as np
import h5py
from absk_radau.model import PeriodicAbsK,make_initial_data
from absk_radau.radau_mass import NewtonFailure
from .tangent import (odd,even,rms,seeds,NAMES,half_model,radau_variants,
                      advance_radau,tangent_radau,tangent_avf,AVF,update,subspace_log_gain)


def metadata(row):
    meta={k:row[k] for k in ('case','method','kind')}
    meta.update({k:float(row[k]) for k in ('p','M','tau_end','nu','eps')})
    meta.update({k:int(row[k]) for k in ('N','K','strict')})
    meta['L']=2*np.pi*(meta['M']*meta['p']/(meta['p']-1))
    meta['T']=meta['L']*2*meta['p']/(meta['p']+1);meta['dt']=meta['T']/meta['K']
    meta['project_base']=meta['kind']=='tangent';meta['epsilon_definition']='initial perturbation RMS / initial cosine RMS'
    return meta


def drec(u):
    c=np.fft.rfft(u,norm='forward');e=4*abs(c)**2;e[[0,-1]]*=.5
    return float(np.sqrt((2*abs(c[1])-1)**2+e[0]+e[2:].sum()))


def create_dataset(h,name,shape):
    # A single snapshot per chunk; no buffering of long fields in memory.
    return h.create_dataset(name,shape=(0,)+shape,maxshape=(None,)+shape,dtype='f8',chunks=(1,)+shape if shape else (256,),compression='gzip',compression_opts=1)


def append(h,group,values):
    for k,v in values.items():
        d=h[group+'/'+k];n=len(d);d.resize(n+1,axis=0);d[n]=v


def initial(meta,model):
    u=odd(make_initial_data(model,'Z',1.));W,high=seeds(model)
    if meta['kind']=='nonlinear':u=u+meta['eps']*rms(u)*np.tile(W[:,0],2)
    return u,W,np.zeros(W.shape[1]),high


def run_segment(meta,model,half,variants,avf,folder,index,k0,k1,u,W,logs,high):
    K=meta['K'];dt=meta['dt'];tangent=meta['kind']=='tangent'
    out=folder/f'seg{index:02d}.h5';audit=folder/f'seg{index:02d}.audit.json'
    if out.exists() or audit.exists():
        if not (out.exists() and audit.exists()):raise FileExistsError('partial existing output, preserve: '+str(out))
        with h5py.File(out,'r') as h:
            au=json.loads(audit.read_text())
            if h.attrs['status']!='COMPLETED' or au['status']!='COMPLETED' or json.loads(h.attrs['meta'])!=meta or int(h.attrs['k0'])!=k0 or int(h.attrs['last_step'])!=k1:raise ValueError('existing segment is partial or incompatible: '+str(out))
            if not np.array_equal(h['field/u'][0],u):raise ValueError('base checkpoint mismatch')
            if tangent and (not np.array_equal(h['field/W'][0],W) or not np.array_equal(h['field/logs'][0],logs)):raise ValueError('tangent checkpoint mismatch')
            return h['field/u'][-1],h['field/W'][-1] if tangent else W,h['field/logs'][-1] if tangent else logs
    beg=time.perf_counter();I0=model.lp_invariant(odd(make_initial_data(model,'Z',1.)));u0norm=1/np.sqrt(2.)
    # The same sampling grids across all K in the manifest (1/400, 1/100).
    if K%400:raise ValueError('K must be multiple of 400')
    scalar_stride=K//400; field_stride=K//100
    if k0%field_stride or k1%field_stride:raise ValueError('segment endpoint off common field grid')
    peak=logs.copy();max_res=max_stage=max_back=max_leak=max_I=max_mass=0.;fallback={};last=k0;failure=None
    print('FASE9C_SEG_START',meta['case'],index,k0/K,k1/K,flush=True)
    with h5py.File(out,'x') as h:
        h.attrs['status']='INCOMPLETE';h.attrs['meta']=json.dumps(meta,sort_keys=True);h.attrs['k0']=k0;h.attrs['k1']=k1;h.attrs['high_mode']=high
        h.attrs['seed_names']=json.dumps(NAMES)
        for group,shapes in [('trace',{'tau':(),'D':(),'even_rms':(),'I_relative':(),'mean':(),'log_gain':(len(NAMES),),'log_subspace_gain':()}),('field',{'tau':(),'u':(model.n,)})]:
            g=h.create_group(group)
            if group=='trace' and not tangent:shapes={k:v for k,v in shapes.items() if k not in ('log_gain','log_subspace_gain')}
            if group=='field' and tangent:shapes.update(W=(half.n,len(NAMES)),logs=(len(NAMES),))
            for name,shape in shapes.items():create_dataset(g,name,shape)
        def save(k,field=False):
            t=k/K
            v=dict(tau=t,D=drec(u),even_rms=float(rms(even(u))),I_relative=model.lp_invariant(u)/I0-1,mean=float(np.mean(u)))
            if tangent:v.update(log_gain=logs,log_subspace_gain=subspace_log_gain(W,logs))
            append(h,'trace',v)
            if field:
                v=dict(tau=t,u=u)
                if tangent:v.update(W=W,logs=logs)
                append(h,'field',v)
                h.attrs['last_step']=k;h.flush()
        save(k0,True);last_trace=last_field=k0
        try:
            for k in range(k0+1,k1+1):
                if meta['method']=='radau':
                    un,diag,name,stages=advance_radau(variants,u,dt)
                    if tangent:X,defect,back=tangent_radau(half,stages,W,dt)
                else:
                    un,diag,name,y=avf.step(u,dt)
                    if tangent:X,defect,back=tangent_avf(half,u,y,W,dt,avf.flux)
                if not np.all(np.isfinite(un)):raise NewtonFailure('nonfinite base')
                if tangent:
                    W,logs,leak=update(W,X,logs)
                    if not np.all(np.isfinite(logs)):raise NewtonFailure('nonfinite log gain')
                    peak=np.maximum(peak,logs);max_stage=max(max_stage,defect);max_back=max(max_back,back);max_leak=max(max_leak,leak)
                u=un;last=k;fallback[name]=fallback.get(name,0)+1;max_res=max(max_res,diag.norm_residual)
                max_I=max(max_I,abs(model.lp_invariant(u)/I0-1));max_mass=max(max_mass,abs(np.mean(u)))
                if k%scalar_stride==0 or k==k1:
                    is_field=k%field_stride==0 or k==k1;save(k,is_field);last_trace=k
                    if is_field:last_field=k
            h.attrs['status']='COMPLETED'
        except BaseException as exc:
            failure=repr(exc)
            # Preserve the last successful state; off-grid sample must not be paired by rounding.
            if last>last_trace:save(last,True)
            elif last>last_field:
                v=dict(tau=last/K,u=u)
                if tangent:v.update(W=W,logs=logs)
                append(h,'field',v)
            h.attrs['status']='FAILED';h.attrs['failure']=failure
            traceback.print_exc()
        finally:
            h.attrs['last_step']=last;h.flush()
    au=dict(status='COMPLETED' if failure is None else 'FAILED',meta=meta,segment=index,start=k0/K,end=k1/K,last_tau=last/K,accepted=last-k0,max_scaled_residual=max_res,max_stage_odd_defect=max_stage,max_tangent_backward_error=max_back,max_relative_mean_leak=max_leak,max_absolute_I_change=max_I,max_absolute_mean=max_mass,fallback=fallback,peak_log_gain=peak.tolist() if tangent else None,seconds=time.perf_counter()-beg,failure=failure)
    audit.write_text(json.dumps(au,indent=2,allow_nan=False)+'\n')
    if failure is not None:raise NewtonFailure(f'FASE9C_FIXED_DT_UNRESOLVED {meta["case"]} tau={last/K} {failure}')
    print('FASE9C_SEG_OK',meta['case'],index,last/K,flush=True)
    return u,W,logs


def run(row,root='fase9c/results/cases'):
    meta=metadata(row);model=PeriodicAbsK(meta['N'],meta['L'],meta['p'],meta['nu']);half=half_model(model)
    tangent=meta['kind']=='tangent';strict=bool(meta['strict']);variants=radau_variants(model,tangent,strict) if meta['method']=='radau' else None
    avf=AVF(model,tangent,strict) if meta['method']=='avf' else None
    folder=Path(root)/meta['case'];folder.mkdir(parents=True,exist_ok=True)
    u,W,logs,high=initial(meta,model);K=meta['K'];end=round(meta['tau_end']*K)
    bounds=[0]+[round(x*K) for x in (1.25,2.25,3.25,4.25) if x<meta['tau_end']]+[end]
    for i,(k0,k1) in enumerate(zip(bounds,bounds[1:]),1):u,W,logs=run_segment(meta,model,half,variants,avf,folder,i,k0,k1,u,W,logs,high)
    print('FASE9C_CASE_OK',meta['case'],flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);p.add_argument('--manifest',default='fase9c/campaign.csv');p.add_argument('--out',default='fase9c/results/cases');a=p.parse_args()
    rows=list(csv.DictReader(open(a.manifest)));assert 1<=a.index<=len(rows);run(rows[a.index-1],a.out)
if __name__=='__main__':main()
