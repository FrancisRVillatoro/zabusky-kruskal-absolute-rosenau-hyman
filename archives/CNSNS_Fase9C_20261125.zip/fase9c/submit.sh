#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
sha256sum -c MANIFEST_FASE9C.sha256
sha256sum -c fase9c/SOURCE_BASE.sha256
mkdir -p fase9c/{logs,jobs,results/cases}
if compgen -G 'fase9c/jobs/*JOBID.txt' >/dev/null; then echo 'Existen JOBID de una campaña previa; no duplicar.' >&2; exit 1; fi
for f in fase9c/slurm/*.slurm; do bash -n "$f"; done
submit(){ local label=$1 raw job; shift; raw=$(sbatch "$@"); printf '%s\n' "$raw" >&2; job=$(printf '%s\n' "$raw" | sed -E $'s/\x1B\\[[0-9;]*[[:alpha:]]//g' | sed -nE 's/^.*Submitted batch job ([0-9]+).*$/\1/p' | tail -1); [[ $job =~ ^[0-9]+$ ]] || { echo 'No se pudo extraer JOBID' >&2; return 1; }; printf '%s\n' "$job" > "fase9c/jobs/${label}_JOBID.txt"; printf '%s' "$job"; }
v=$(submit VERIFY fase9c/slurm/verify.slurm)
m=$(submit MAIN --dependency=afterok:$v --kill-on-invalid-dep=yes fase9c/slurm/main.slurm)
r=$(submit REPORT --dependency=afterany:$m fase9c/slurm/report.slurm)
printf 'FASE9C_LANZADA verify=%s main=%s report=%s\n' "$v" "$m" "$r"
squeue -l
