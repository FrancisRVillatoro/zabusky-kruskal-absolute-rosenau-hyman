"""Real, short integrations, for software verification only."""
import csv,json,argparse
from pathlib import Path
import numpy as np
import h5py
from .run import run

def cases():
    rows=[]
    for p,M,K,ns in [(2.25,4,12800,(450,900,1800,3600)),(2.,8,27200,(2000,4000))]:
        for n in ns:rows.append(dict(case=f'pilot_p{p:g}_M{M}_N{n}_K{K}',p=p,M=M,N=n,K=K,tau_end=(.01 if p==2. else .02),nu=0.,method='radau',kind='tangent',eps=0.,strict=0))
    for n in (450,1800):rows.append(dict(case=f'pilot_AVF_N{n}',p=2.25,M=4,N=n,K=12800,tau_end=.02,nu=0.,method='avf',kind='tangent',eps=0.,strict=0))
    return rows

def main():
    a=argparse.ArgumentParser();a.add_argument('--indices',type=int,nargs='*',default=[]);a.add_argument('--summarize',action='store_true');args=a.parse_args();rows=cases();root=Path('fase9c/results_local/pilots')
    for i in args.indices:run(rows[i-1],root)
    if args.summarize:
        res=[]
        for r in rows:
            folder=root/r['case'];audit=folder/'seg01.audit.json'
            if not audit.exists():continue
            au=json.loads(audit.read_text())
            with h5py.File(folder/'seg01.h5','r') as h:
                gain=np.exp(h['trace/log_gain'][-1]);opt=np.exp(h['trace/log_subspace_gain'][-1])
            res.append(dict(case=r['case'],N=r['N'],p=r['p'],M=r['M'],nu=r['nu'],method=r['method'],K=r['K'],status=au['status'],tau=au['last_tau'],G_cos2=gain[0],G_local=gain[-2],G_mesh=gain[-1],G_S8=opt,max_stage_odd_defect=au['max_stage_odd_defect'],max_backward=au['max_tangent_backward_error'],max_I=au['max_absolute_I_change'],seconds=au['seconds']))
        with open('fase9c/results_local/pilots.csv','w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(res[0]));w.writeheader();w.writerows(res)
        print('summarized',len(res))
if __name__=='__main__':main()
