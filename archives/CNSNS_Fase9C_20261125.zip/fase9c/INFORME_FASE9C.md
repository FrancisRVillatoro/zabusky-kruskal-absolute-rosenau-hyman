# Fase 9C — estado previo a Picasso

Se ha implementado la diferenciación de las ecuaciones implícitas convergidas, no la diferenciación de una interpolación temporal. Para Radau se capturan las etapas aceptadas del código original. Para AVF se diferencian las dos entradas de la media de flujo. La reducción a N/2 nodos representa exactamente la restricción transversal en aritmética exacta, con monitor de simetría y media en coma flotante. La prueba algebraica de traza nula en el inviscido establece det Phi=1 en el sector par de media cero de la EDO exacta, no estabilidad ni conservación de volumen de los métodos discretos.

## Resultados ejecutados localmente

Diez tests (ver results_local/tests.txt), incluyendo comparación con el bloque completo de 3N, diferencias finitas centradas para Radau y AVF, invariantes, equivariancia, continuación/reutilización y postproceso con una tarea ausente. La comparación de un paso (N=80, dt=.003, p=2.25, epsilon=1e-5 absoluto en la prueba) da errores RMS 5.92e-10 (Radau) y 1.00e-9 (AVF); error hacia atrás inferior a 4e-16. El error es una comparación finita, no una cota de error global.

Ocho integraciones cortas reales en las resoluciones de producción; todas completadas. `results_local/pilots.csv` contiene sus cifras y los HDF5 correspondientes. En el caso central nu=0, tau=.02, K=12800, Radau da G_cos2=1.03478,1.05877,1.07143,1.28374 para N=450,900,1800,3600. G_near_zeros=1.10342,1.15377,1.26953,1.91392. G_S8=1.54110,1.66202,1.67242,2.53990. No se ha establecido convergencia ni crecimiento a tiempo largo. En N=1800 AVF da G_cos2=1.05681 y G_S8=1.61336 en la misma ventana corta. Para la sonda dependiente de malla en N=450 y 1800, Radau da 0.07027 y 0.000978; AVF 1.14741 y 1.00451. Estos resultados ilustran el filtro del integrador, no certifican que AVF resuelva las frecuencias rígidas. Para p=2,M=8 a tau=.01, N=2000,4000: G_cos2=1.09350,1.08524; G_near_zeros=1.84735,1.78317; G_S8=1.33703,1.30866. No extrapolar a tau=1.

## Criterios de interpretación al recibir datos de Picasso

1. Verificar cobertura temporal, estabilidad de la base, auditorías y replay frente a 9B. No interpretar un fracaso de Newton como inestabilidad física.
2. Comparar ganancias de direcciones fijas y vectores completos entre N y K; el refinamiento de K empieza en tau=0. Una tendencia en la sonda de malla no es por sí sola divergencia para un dato fijo.
3. Contrastar Radau con AVF, que elimina la deriva del funcional inviscido pero no todo error numérico. En la campaña regularizada se estudia sensibilidad espacial a nu fijo, sin afirmar validación temporal tardía.
4. Comparar perturbaciones epsilon y -epsilon con la tangente antes de la salida del régimen lineal. Cuando la perturbación amplificada ya no es pequeña o el ruido de la corrida epsilon=0 es comparable, el cociente de diferencias deja de ser una estimación fiable del propagador.
5. Reportar tasas finitas (log G / t) y no tasas asintóticas. Si no se obtiene estabilización espacial/temporal, describir sensibilidad, no demostrar ill-posedness.

La fase 9C está implementada y probada localmente. Las 42 trayectorias largas y su auditoría están pendientes de Picasso. No se debe insertar una conclusión sobre crecimiento transversal hasta disponer de esas salidas.
