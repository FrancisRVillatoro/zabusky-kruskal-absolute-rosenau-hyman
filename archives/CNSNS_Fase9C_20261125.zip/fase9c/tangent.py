"""Tangent maps of the actual implicit time steps, restricted to the even sector.
Base orbit is odd under half-period translation. Tangent is NOT differentiated
through the odd projection. Half-grid operators represent the periodic even sector.
"""
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu
from scipy.special import binom
from absk_radau.model import PeriodicAbsK
from absk_radau.radau_mass import MassRadau5, NewtonOptions, NewtonFailure, A_R, StepData


def odd(u): return (u-np.roll(u,len(u)//2,axis=0))/2

def even(u): return (u+np.roll(u,len(u)//2,axis=0))/2

def rms(v): return np.sqrt(np.mean(np.abs(v)**2,axis=0))

def normalize(v):
    v=np.asarray(v,float); v=v-v.mean(axis=0)
    norms=rms(v)
    if not np.all(np.isfinite(norms)) or np.any(norms<=0): raise ValueError('degenerate tangent seed')
    return v/norms

class CapturedRadau(MassRadau5):
    """Original integrator; capture last evaluated stages, including accepted residual."""
    def stage_residual(self,u,stages,dt):
        r=super().stage_residual(u,stages,dt)
        self.last_stages=stages.copy()
        return r


def radau_variants(model,project=True,strict=False):
    a,r=(1e-13,1e-11) if strict else (1e-11,1e-9)
    return [(name,CapturedRadau(model,NewtonOptions(atol=a,rtol=r,max_iter=it,line_search_backtracks=ls,predictor=pred),project_half=project)) for name,it,ls,pred in [('original',12,10,'euler'),('extended_euler',32,22,'euler'),('extended_constant',32,22,'constant')]]


def advance_radau(variants,u,dt):
    errors=[]
    for name,solver in variants:
        try:
            un,d=solver.step(u,dt)
            return un,d,name,solver.last_stages
        except NewtonFailure as e: errors.append(name+': '+str(e))
    raise NewtonFailure('; '.join(errors))


def half_model(model):
    if model.n%2 or model.n<32: raise ValueError('even N>=32 required')
    return PeriodicAbsK(model.n//2,model.L/2,model.p,model.nu,model.frame_speed,model.regularization)


def jac_weight(model,w):
    return (-(model.K @ sparse.diags(w,format='csr'))+model.linear).tocsr()


def tangent_radau(half,stages,W,dt):
    """Differentiate the stage equations. W: n/2 by number of columns."""
    n=half.n; w=half.p*np.abs(stages)**(half.p-1)
    defect=float(np.max(np.abs(stages[:,:n]+stages[:,n:])))
    if defect>1e-7*(1+np.max(np.abs(stages))): raise NewtonFailure(f'base stages not odd: {defect:.4g}')
    weights=(w[:,:n]+w[:,n:])/2  # exact restriction on symmetric stages
    J=[jac_weight(half,a) for a in weights]
    M=half.mass
    blocks=[[(M-dt*A_R[i,j]*J[j]) if i==j else -dt*A_R[i,j]*J[j] for j in range(3)] for i in range(3)]
    Jblk=sparse.bmat(blocks,format='csc')
    rhs=np.tile(M@W,(3,1)); X=splu(Jblk).solve(rhs)
    # Normwise backward error rather than absolute residual of stiff matrix.
    normJ=float(np.max(np.asarray(abs(Jblk).sum(axis=1))))
    residual=np.max(np.abs(Jblk@X-rhs),axis=0)
    scale=normJ*np.max(np.abs(X),axis=0)+np.max(np.abs(rhs),axis=0)
    backward=float(np.max(residual/np.maximum(scale,np.finfo(float).tiny)))
    if not np.isfinite(backward) or backward>1e-10: raise NewtonFailure(f'tangent linear solve backward error {backward}')
    return X[2*n:],defect,backward


class MeanFlux:
    """AVF discrete gradient; stable divided difference and derivative w.r.t y.
    Adapted from controls/avf_control.py of the revised CNSNS supplement.
    Reversing x,y gives the derivative w.r.t x (symmetric mean flux).
    """
    def __init__(self,p):
        self.p=p; k=np.arange(11)
        self.mean_coef=binom(p,k)/(k+1)
        self.derivative_coef=p*binom(p-1,k)/(k+2)
    def evaluate(self,x,y,derivative=False):
        delta=y-x; close=(np.abs(delta)<=.05*np.abs(x))&(x!=0); flat=(x==0)&(y==0); other=~(close|flat)
        g=np.zeros_like(x); power=self.p+1; xo,yo,do=x[other],y[other],delta[other]
        g[other]=(np.abs(yo)**power-np.abs(xo)**power)/(power*do)
        xc=x[close]; q=delta[close]/xc; axp=np.abs(xc)**(self.p-1)
        g[close]=axp*xc*np.polynomial.polynomial.polyval(q,self.mean_coef)
        if not derivative:return g
        dg=np.zeros_like(x); dg[other]=(np.abs(yo)**(self.p-1)*yo-g[other])/do
        dg[close]=axp*np.polynomial.polynomial.polyval(q,self.derivative_coef)
        return g,dg


class AVF:
    def __init__(self,model,project=True,strict=False):
        if model.nu!=0 or model.frame_speed!=0:raise ValueError('AVF only inviscid laboratory frame')
        self.model=model;self.project=project;self.flux=MeanFlux(model.p)
        self.atol,self.rtol=(1e-13,1e-11) if strict else (1e-11,1e-9)
    def res(self,x,y,g):return self.model.mass@(y-x)+self.dt*(self.model.K@g)
    def scaled(self,r,x,y):return float(rms(r/(self.atol+self.rtol*np.maximum(abs(x),abs(y)))))
    def step(self,x,dt):
        self.dt=dt;errors=[]
        for name in ('constant','euler'):
            y=x.copy() if name=='constant' else x+dt*self.model.velocity(x)
            damping=0
            try:
                for it in range(33):
                    g,dy=self.flux.evaluate(x,y,True); R=self.res(x,y,g); err=self.scaled(R,x,y)
                    if not np.isfinite(err):raise NewtonFailure('nonfinite AVF residual')
                    if err<=1:
                        return (odd(y) if self.project else y),StepData(it,it,err,damping),name,y.copy()
                    if it==32:raise NewtonFailure(f'AVF Newton exhausted {err}')
                    J=self.model.mass+dt*self.model.K@sparse.diags(dy)
                    delta=splu(J.tocsc()).solve(-R)
                    for j in range(23):
                        candidate=y+2.**(-j)*delta
                        if self.scaled(self.res(x,candidate,self.flux.evaluate(x,candidate)),x,candidate)<err:
                            y=candidate;damping+=j;break
                    else:raise NewtonFailure(f'AVF line search failed {err}')
            except (NewtonFailure,RuntimeError) as e:errors.append(name+': '+str(e))
        raise NewtonFailure('; '.join(errors))


def tangent_avf(half,x,y,W,dt,flux):
    n=half.n; defect=float(np.max(np.abs(y[:n]+y[n:])))
    if defect>1e-7*(1+np.max(np.abs(y))):raise NewtonFailure(f'AVF base not odd: {defect}')
    _,dy=flux.evaluate(x,y,True);_,dx=flux.evaluate(y,x,True)
    dx=(dx[:n]+dx[n:])/2;dy=(dy[:n]+dy[n:])/2
    M=half.mass;K=half.K
    J=(M+dt*K@sparse.diags(dy)).tocsc();rhs=(M-dt*K@sparse.diags(dx))@W
    X=splu(J).solve(rhs);nr=float(np.max(np.asarray(abs(J).sum(axis=1))))
    backward=float(np.max(np.max(abs(J@X-rhs),axis=0)/np.maximum(nr*np.max(abs(X),axis=0)+np.max(abs(rhs),axis=0),np.finfo(float).tiny)))
    if not np.isfinite(backward) or backward>1e-10:raise NewtonFailure(f'AVF tangent residual {backward}')
    return X,defect,backward


NAMES=['cos2','sin2','cos4','sin4','cos6','sin6','cos8','sin8','near_zeros','grid_probe']

def seeds(model):
    """Unit RMS, mean zero. First eight orthonormal, fixed physical harmonics."""
    t=2*np.pi*model.x[:model.n//2]/model.L
    cols=[]
    for n in (2,4,6,8):cols.extend([np.cos(n*t),np.sin(n*t)])
    high=2*(model.n//8)
    if high<=8:high=10
    if high>=model.n/2:raise ValueError('too few nodes for distinct mesh probe')
    cols.extend([np.exp(-(np.cos(t)/.12)**2),np.cos(high*t)])
    return normalize(np.column_stack(cols)),high


def update(W,X,logs):
    # Exact tangent mean is zero; remove only roundoff, measure it before removal.
    m=X.mean(axis=0); scale=rms(X)
    if not np.all(np.isfinite(scale)) or np.any(scale==0):raise NewtonFailure('zero/nonfinite tangent')
    leak=float(np.max(abs(m)/scale))
    if leak>1e-7:raise NewtonFailure(f'tangent mean leakage {leak}')
    X=X-m; norms=rms(X)
    if np.any(norms<=0):raise NewtonFailure('tangent vanished')
    return X/norms,logs+np.log(norms),leak


def subspace_log_gain(W,logs,count=8):
    z=logs[:count]; m=np.max(z); scaled=W[:,:count]*np.exp(z-m)
    return float(m+np.log(np.linalg.svd(scaled/np.sqrt(len(W)),compute_uv=False)[0]))
