import csv
from pathlib import Path

def make():
    rows=[]
    def add(p,M,N,K,end,nu=0.,method='radau',kind='tangent',eps=0.,strict=False):
        tag=f'p{p:g}_M{M:g}_N{N}_K{K}_nu{nu:g}_{method}_{kind}'
        if kind=='nonlinear':tag+=f'_eps{eps:+.0e}'
        if strict:tag+='_strict'
        rows.append(dict(index=len(rows)+1,case=tag,p=p,M=M,N=N,K=K,tau_end=end,nu=nu,method=method,kind=kind,eps=eps,strict=int(strict)))
    # Central orbit, common temporal grid and full refinements from t=0.
    for n in (450,900,1800,3600):add(2.25,4,n,12800,4.25)
    for n in (900,1800):add(2.25,4,n,25600,4.25)
    add(2.25,4,3600,25600,1.25)
    for nu in (.00025,.001,.004):
        for n in (900,1800):add(2.25,4,n,12800,4.25,nu)
    # Independent, invariant-preserving time integrator; partial runs retained.
    for n in (450,900,1800):add(2.25,4,n,12800,4.25,method='avf')
    add(2.25,4,1800,25600,4.25,method='avf')
    # Sensitive larger-domain case, steps from t=0; 1.25 is original comparison interval.
    for n in (1000,2000,4000):add(2.,8,n,27200,1.25)
    for n in (2000,4000):add(2.,8,n,54400,1.25)
    # Real unprojected trajectories, same time step and cosine-2 direction.
    for p,M,K,end,ns in [(2.25,4,12800,4.25,(900,1800)),(2.,8,27200,1.25,(2000,4000))]:
        for n in ns:
            for eps in (0.,1e-8,1e-7,1e-6):add(p,M,n,K,end,kind='nonlinear',eps=eps)
    # Opposite perturbation for symmetry check; additional time-refined nonlinear pair.
    add(2.25,4,1800,12800,4.25,kind='nonlinear',eps=-1e-6)
    for eps in (0.,1e-6):add(2.25,4,1800,25600,4.25,kind='nonlinear',eps=eps)
    # Algebraic tolerance check at first return; don't change step or initial datum.
    add(2.25,4,1800,12800,1.25,strict=True)
    return rows
if __name__=='__main__':
    rows=make();p=Path('fase9c/campaign.csv')
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(len(rows),'cases',sum(r['kind']=='tangent' for r in rows),'tangent')
