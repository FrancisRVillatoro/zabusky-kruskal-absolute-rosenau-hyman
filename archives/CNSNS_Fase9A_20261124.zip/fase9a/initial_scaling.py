"""Instantaneous velocities, no time integration; production Pade operator."""
import argparse,csv,json,hashlib,time
from pathlib import Path
import numpy as np
from scipy.special import beta
from absk_radau.model import PeriodicAbsK
P_VALUES=(1.75,2.,2.125,2.25,2.375,2.49,2.5,2.625,2.75,3.)
PHASES=(0.,.25,.5,.75)
LENGTH=2*np.pi*7.2
LD=np.longdouble

def norm(a,h): return float(np.sqrt(h*np.sum(np.asarray(a,dtype=LD)**2)))

def shift_sin(n,alpha):
    j=np.arange(n//2,dtype=LD)-LD(alpha)
    a=np.sin(2*np.arccos(LD(-1))*j/n)
    return np.concatenate([a,-a])

def mass_fft(v):
    n=len(v); c=np.cos(2*np.pi*np.arange(n//2+1)/n)
    return np.fft.irfft(np.fft.rfft(np.asarray(v,float))/((64+52*c+4*c*c)/120),n=n)

def stencil(g,h):
    # Same B,C, evaluated in extended precision to diagnose cancellation.
    h=LD(h); d1=np.roll(g,-1)-np.roll(g,1); d2=np.roll(g,-2)-np.roll(g,2)
    return (d2+10*d1)/(24*h),(d2-2*d1)/(2*h**3)

def continuum_norm(p,L):
    if p<=2.5: return np.nan
    k=2*np.pi/L; a=1-(3*p-2)*k*k; b=(p-1)*(p-2)*k*k
    def I(m,n): return beta((m+1)/2,(n+1)/2)/2
    return float(np.sqrt(4*p*p*k*(a*a*I(2*p-2,2)+2*a*b*I(2*p-4,4)+b*b*I(2*p-6,6))))

def lattice(p,alpha,m=32768):
    # Approximation to infinite-lattice inverse; correct leading algebraic tail.
    j=np.arange(-m,m,dtype=LD)-LD(alpha)
    def g(z): return np.sign(z)*np.abs(z)**LD(p)
    d=(g(j+2)-g(j-2)-2*(g(j+1)-g(j-1)))/2
    v=mass_fft(d); c=p*(p-1)*(p-2)
    tail=2*c*c*m**(2*p-5)/(5-2*p) if p<2.5 else np.nan
    return float(np.linalg.norm(v[m-8:m+9])),float(np.sqrt(np.dot(v,v)+tail))

def run(out,ns,ps=P_VALUES,phases=PHASES):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    rows=[]; k=2*np.pi/LENGTH; t0=time.time()
    latt={(p,a):lattice(p,a) for p in ps if p<2.5 for a in phases}
    for n in ns:
        model=PeriodicAbsK(n,LENGTH,2.) # matrices independent of p
        h=model.dx; idx=np.r_[np.arange(-8,9)%n,np.arange(n//2-8,n//2+9)%n]
        for alpha in phases:
            U=shift_sin(n,alpha)
            for family,p in [('Z',p) for p in ps]+[('P',2.)]:
                model.p=p
                u=U if family=='Z' else (1+U)/2
                uf=np.asarray(u,float); v=model.velocity(uf)
                g=np.sign(u)*np.abs(u)**LD(p); b,c=stencil(g,h)
                vr=-model._mass_lu.solve(np.asarray(b+c,float)); cv=-model._mass_lu.solve(np.asarray(c,float))
                nr=norm(vr,h); core=norm(vr[idx],h) if family=='Z' else np.nan; amp=k**p
                lc,lt=latt.get((p,alpha),(np.nan,np.nan)) if family=='Z' else (np.nan,np.nan)
                exact=continuum_norm(p,LENGTH) if family=='Z' else np.sqrt(LENGTH/2*((.5*k*(1-k*k))**2+(.125*2*k*(1-4*k*k))**2))
                rows.append(dict(family=family,N=n,h=h,p=p,alpha=alpha,velocity_L2=norm(v,h),velocity_L2_extended=nr,
                    dispersive_L2_extended=norm(cv,h),core17_per_zero_L2=core,rel_float64_vs_extended=norm(v-vr,h)/nr,
                    scaled_global=nr*h**(2.5-p),scaled_core=core*h**(2.5-p),
                    lattice_global_prediction=np.sqrt(2)*amp*lt,lattice_core_prediction=np.sqrt(2)*amp*lc,
                    critical_log_slope=4*(p*(p-1)*(p-2)*amp)**2 if p==2.5 else np.nan,continuum_L2=exact))
        print('FASE9A_ESCALA N',n,flush=True)
        del model
    by={(r['family'],r['p'],r['alpha'],r['N']):r for r in rows}
    for r in rows:
        r.update(observed_global_growth=np.nan,observed_core_growth=np.nan,increment_squared_per_log2=np.nan,increment_scaled_coefficient_squared=np.nan)
        z=by.get((r['family'],r['p'],r['alpha'],r['N']//2))
        if z:
            a,b=r['velocity_L2_extended'],z['velocity_L2_extended']; r['observed_global_growth']=np.log2(a/b)
            r['observed_core_growth']=np.log2(r['core17_per_zero_L2']/z['core17_per_zero_L2'])
            r['increment_squared_per_log2']=(a*a-b*b)/np.log(2)
            if r['p']<2.5 and r['family']=='Z': r['increment_scaled_coefficient_squared']=(a*a-b*b)*r['h']**(5-2*r['p'])/(1-2**(2*r['p']-5))
    with (out/'initial_scaling.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (out/'initial_scaling_meta.json').write_text(json.dumps(dict(L=LENGTH,N=list(ns),p=list(ps),alpha=list(phases),rows=len(rows),wall_seconds=time.time()-t0,
        model_sha256=hashlib.sha256(Path(__import__('absk_radau.model',fromlist=['']).__file__).read_bytes()).hexdigest(),numpy=np.__version__,longdouble_eps=float(np.finfo(LD).eps)),indent=2)+'\n')
    return rows

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',required=True);ap.add_argument('--min-power',type=int,default=8);ap.add_argument('--max-power',type=int,default=16);a=ap.parse_args()
    run(a.out,[2**q for q in range(a.min_power,a.max_power+1)])
if __name__=='__main__':main()
