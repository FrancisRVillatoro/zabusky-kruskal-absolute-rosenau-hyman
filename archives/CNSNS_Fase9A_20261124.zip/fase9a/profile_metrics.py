"""Native-node and periodic piecewise-linear diagnostics; no continuum inference."""
from __future__ import annotations
import csv
from pathlib import Path
import numpy as np
LEVELS=(.025,.05,.1,.15,.2,.25,.3,.4,.5)
RADII=(.025,.05,.1,.2,.4,.8,1.6)

def read_csv(path):
    with open(path,newline='',encoding='utf8') as f:return list(csv.DictReader(f))

def write_csv(path,rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if not rows: path.write_text('');return
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in rows for k in row)));w.writeheader();w.writerows(rows)

def roots(u):
    """Strict sign changes, including isolated exact zero with opposite neighbours.
    Flat zero cells are a separate ambiguity and not called simple roots."""
    u=np.asarray(u);n=len(u);v=np.roll(u,-1);d=v-u
    out=[]
    for i in np.flatnonzero(((u<0)&(v>0))|((u>0)&(v<0))):
        out.append((float(i-u[i]/d[i]),int(np.sign(d[i])),int(i),float(abs(d[i]))))
    for i in np.flatnonzero(u==0):
        left,right=u[(i-1)%n],u[(i+1)%n]
        if left*right<0:
            # exact-root cell slope uses max of the adjacent increments; distinguish in output
            j=(i-1)%n if abs(left)>=abs(right) else i
            out.append((float(i),int(np.sign(right)),int(j),float(max(abs(left),abs(right)))))
    return sorted(out),int(np.count_nonzero((u==0)&(v==0)))

def merge(intervals,n):
    """Merge intervals in [0,N]; join endpoints periodically."""
    z=[]
    for a,b in sorted(intervals):
        if b-a<=1e-13:continue
        if z and a<=z[-1][1]+1e-11:z[-1]=(z[-1][0],max(z[-1][1],b))
        else:z.append((a,b))
    if len(z)>1 and z[0][0]<=1e-11 and z[-1][1]>=n-1e-11:
        z=[(z[-1][0],z[0][1]+n)]+z[1:-1]
    return z

def amp_segments(u,a):
    n=len(u);du=np.roll(u,-1)-u
    l=np.zeros(n);r=np.ones(n);nz=du!=0
    q=(-a-u[nz])/du[nz];s=(a-u[nz])/du[nz]
    l[nz]=np.maximum(0,np.minimum(q,s));r[nz]=np.minimum(1,np.maximum(q,s))
    r[(~nz)&(np.abs(u)>a)]=0
    i=np.flatnonzero(r>l)
    return merge([(float(j+l[j]),float(j+r[j])) for j in i],n)

def distance_segments(zs,r,n):
    z=[]
    if r>=n/2:return [(0.,float(n))] if zs else []
    for q in zs:
        a,b=q-r,q+r
        if a<0:z.extend([(0.,b),(a+n,float(n))])
        elif b>n:z.extend([(a,float(n)),(0.,b-n)])
        else:z.append((a,b))
    return merge(z,n)

def integrate_segments(e,segs):
    """Exactly integrate squared piecewise-linear e in grid units."""
    n=len(e);total=0.
    for a,b in segs:
        for i in range(int(np.floor(a)),int(np.ceil(b))):
            l=max(a,i)-i;r=min(b,i+1)-i
            if r<=l:continue
            x=e[i%n];dx=e[(i+1)%n]-x
            el=x+l*dx;er=x+r*dx
            total+=(r-l)*(el*el+el*er+er*er)/3
    return float(total)

def fractions(e,mask,segments):
    n=len(e);den=np.dot(e,e);de=np.roll(e,-1)
    denpl=np.sum(e*e+e*de+de*de)/3
    return dict(node_area_fraction=float(np.mean(mask)),node_residual_fraction=float(np.dot(e[mask],e[mask])/den) if den else np.nan,
        pl_area_fraction=sum(b-a for a,b in segments)/n,pl_residual_fraction=integrate_segments(e,segments)/denpl if denpl else np.nan)

def circ_delta(x,z,n):return (x-z+n/2)%n-n/2

def measure(u,L,meta):
    n=len(u);h=L/n;u=np.asarray(u,float)
    if n<16 or not np.isfinite(u).all():raise ValueError('bad field')
    hat=np.fft.rfft(u)/n;phi=float(np.angle(hat[1]));r=2*abs(hat[1]);ref=np.cos(2*np.pi*np.arange(n)/n+phi);e=u-ref
    H=2*(np.mean(u*u)-np.mean(u)**2)-r*r
    D=float(np.sqrt(2*np.mean(e*e)));z,flat=roots(u);zs=[a[0] for a in z]
    rzero=[((np.pi/2-phi)/(2*np.pi)*n)%n,((3*np.pi/2-phi)/(2*np.pi)*n)%n]
    crosses=[];layers=[];loc=[];dist=[]
    for q,s,i,d in z:
        dref=min((circ_delta(q,c,n) for c in rzero),key=abs)
        crosses.append(dict(**meta,root_x=q*h,orientation=s,cell=i,cell_jump=d,secant_abs=d/h,offset_from_nearest_reference_zero=dref*h))
    for a in LEVELS:
        segs=amp_segments(u,a);root_segs=[];counts=[]
        for lo,hi in segs:
            inside=[q for q in zs if any(lo-1e-10<=q+m*n<=hi+1e-10 for m in (-1,0,1))]
            if inside:
                root_segs.append((lo,hi));counts.append(len(inside))
                layers.append(dict(**meta,level=a,start_x=(lo%n)*h,width=(hi-lo)*h,width_over_h=hi-lo,n_roots=len(inside)))
        zfrac=fractions(e,np.abs(u)<a,segs)
        loc.append(dict(**meta,level=a,**zfrac,n_crossing_components=len(root_segs),
            crossing_component_total_width=sum(hi-lo for lo,hi in root_segs)*h,
            crossing_component_max_width=max((hi-lo for lo,hi in root_segs),default=np.nan)*h,
            max_roots_in_component=max(counts,default=0),
            pl_residual_fraction_crossing_components=integrate_segments(e,root_segs)/integrate_segments(e,[(0.,float(n))]) if np.dot(e,e)>0 else np.nan))
    for radius in RADII:
        mask=np.zeros(n,dtype=bool)
        for q in zs:mask|=np.abs(circ_delta(np.arange(n),q,n))*h<radius
        dist.append(dict(**meta,radius=radius,**fractions(e,mask,distance_segments(zs,radius/h,n))))
    clusters=[]
    for c in rzero:
        vals=[circ_delta(q,c,n) for q in zs if abs(circ_delta(q,c,n))<=n/4]
        clusters.append((len(vals),(max(vals)-min(vals))*h if vals else np.nan))
    summary=dict(**meta,h=h,D=D,r=r,H=H,e5_over_H=(4*abs(hat[5])**2/H if H>1e-15 else np.nan),
        n_roots=len(z),flat_zero_cells=flat,max_secant=max((d/h for q,s,i,d in z),default=np.nan),
        max_cell_jump=max((d for q,s,i,d in z),default=np.nan),max_cluster_span=max(x[1] for x in clusters),
        max_roots_per_ref_lobe=max(x[0] for x in clusters),pl_D=np.sqrt(2*integrate_segments(e,[(0.,float(n))])/n))
    return summary,crosses,layers,loc,dist,ref,e

class Report:
    def __init__(self):self.tables={name:[] for name in ('summary','crossings','layers','amplitude_localization','distance_localization','profiles')}
    def add(self,u,L,meta,expected_D=None):
        s,c,l,a,d,ref,e=measure(u,L,meta)
        if expected_D is not None and abs(s['D']-expected_D)>1e-9:raise ValueError('D mismatch '+str(meta))
        for name,val in zip(('summary','crossings','layers','amplitude_localization','distance_localization'),([s],c,l,a,d)):self.tables[name].extend(val)
        self.tables['profiles'].extend(dict(**meta,index=i,x=i*L/len(u),u=float(v),aligned_initial=float(ref[i]),residual=float(e[i])) for i,v in enumerate(u))
        return s
    def save(self,out):
        for name,rows in self.tables.items():write_csv(Path(out)/(name+'.csv'),rows)

def archive_audit(profiles,provenance,out,L):
    prov={(int(r['j']),int(r['N'])):r for r in read_csv(provenance)};groups={}
    for r in read_csv(profiles):groups.setdefault((int(r['j']),int(r['N'])),[]).append(r)
    rep=Report()
    for (j,n),rows in sorted(groups.items()):
        p=prov[j,n];rows.sort(key=lambda r:int(r['index']))
        if len(rows)!=n or [int(r['index']) for r in rows]!=list(range(n)):raise ValueError('invalid profile indices')
        u=np.array([float(r['u']) for r in rows]);tau=float(p['tau'])
        if any(abs(float(r['tau'])-tau)>1e-12 for r in rows):raise ValueError('time mismatch')
        meta=dict(j=j,N=n,nu=0.,divisor=4 if j==4 and n==1800 else 1,tau=tau,selection='archived minimum',origin=p['origin'])
        s=rep.add(u,L,meta,float(p['D']))
    rep.save(out)
    return rep
