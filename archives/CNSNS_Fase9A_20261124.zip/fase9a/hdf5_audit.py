"""Read-only postprocessing of actual completed production files on Picasso."""
import argparse,json,hashlib,traceback
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import h5py,numpy as np
from .profile_metrics import Report,read_csv,write_csv
from .initial_scaling import LENGTH
TICKS=12800
TC=LENGTH*2*2.25/3.25

def file_hash(path):
    d=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1048576),b''):d.update(block)
    return d.hexdigest()

def read_run(root,row):
    path=root/row['path']; n=int(row['N']);j=int(row['j']);nu=float(row['nu']);div=int(row['divisor'])
    with h5py.File(path,'r') as f:
        c=json.loads(f.attrs['config_json'])
        if f.attrs.get('status')!='COMPLETED':raise ValueError('not COMPLETED')
        assert int(f.attrs['n_cells'])==n and abs(float(f.attrs['period'])-LENGTH)<1e-10
        assert float(f.attrs['amplitude'])==1 and c['phase']==row['phase'] and int(c['N'])==n
        assert c['family']=='Z' and c['project_half'] is True and c['p']==2.25 and c['M']==4 and c['nu']==nu
        assert abs(c['dt']*3200*div-TC)<1e-9 and abs(c['T_cross']-TC)<1e-9
        if nu:
            assert c['run_id']==row['run_id'] and c['kind']==row['mode'] and c['regularization']=='fourth_order' and not c['strict']
        else:
            assert c['phase3_run_id']==row['run_id'] and c['mode']==row['mode']
        tau=f['t'][:]/TC; ticks=np.rint(tau*TICKS).astype(int)
        assert np.max(np.abs(ticks/TICKS-tau))<1e-9 and np.all(np.diff(ticks)>0)
        assert abs(tau[0]-float(row['start']))<1e-9 and abs(tau[-1]-float(row['end']))<1e-9
        U=f['u'][:];d=f['diagnostics'][:]
        assert U.shape==(len(tau),n) and d.shape==(len(tau),10) and np.isfinite(U).all()
        assert np.isfinite(d[:,5]).all()
        # Recompute exact discrete translation distance without a cancellation-prone difference of norms.
        phase=np.angle(np.fft.rfft(U,axis=1)[:,1]);ref=np.cos(2*np.pi*np.arange(n)/n+phase[:,None]);D=np.sqrt(2*np.mean((U-ref)**2,axis=1))
        defect=float(np.max(np.abs(D-d[:,5])));assert defect<1e-9
    lo,hi=((.92,1.12) if nu else (.94,1.10)) if j==1 else (j-.2,j+.2)
    ix=np.where((ticks/TICKS>=lo-1e-11)&(ticks/TICKS<=hi+1e-11))[0]
    # Include neighbours as in phase4 catalogue, but never select a window endpoint.
    candidates=[i for i in ix[1:-1] if D[i]<=D[i-1] and D[i]<=D[i+1] and (D[i]<D[i-1] or D[i]<D[i+1])]
    if not candidates:raise ValueError('no interior minimum')
    best=min(candidates,key=lambda i:D[i]); archived_tick=round(float(row['tau'])*TICKS)
    if ticks[best]!=archived_tick or abs(D[best]-float(row['D']))>1e-8:
        raise ValueError(f'catalog mismatch: selected {ticks[best]/TICKS} {D[best]} versus {row["tau"]} {row["D"]}')
    return dict(ticks=ticks,U=U,D=D,best=best,candidates=candidates,defect=defect,hash=file_hash(path))

def audit(root,out,catalog):
    root=Path(root);out=Path(out);out.mkdir(parents=True,exist_ok=False)
    rep=Report();common=Report();inventory=[]; candidates=[]; groups={};problems=[]
    for row in read_csv(catalog):
        j,n,nu,div=int(row['j']),int(row['N']),float(row['nu']),int(row['divisor'])
        meta=dict(j=j,N=n,nu=nu,divisor=div,origin='production HDF5',source=row['path'])
        try:
            v=read_run(root,row);best=v['best'];t=v['ticks'][best]/TICKS
            s=rep.add(v['U'][best],LENGTH,dict(**meta,tau=t,selection='individual minimum'),float(row['D']))
            inventory.append(dict(**meta,status='OK',tau=t,D=s['D'],n_samples=len(v['ticks']),n_local_minima=len(v['candidates']),field_D_max_defect=v['defect'],sha256=v['hash']))
            for i in v['candidates']:candidates.append(dict(**meta,tau=v['ticks'][i]/TICKS,D=v['D'][i],selected=i==best))
            groups.setdefault((j,nu,div),[]).append((meta,v))
        except Exception as e:
            problems.append(dict(**meta,error=repr(e),traceback=traceback.format_exc()));inventory.append(dict(**meta,status='ERROR',error=repr(e)))
    # Compare actual fields against earlier archived/replayed fields at identical times.
    archive={}
    old=Path(catalog).parent/'refinement_profiles.csv'
    if old.is_file():
        for row in read_csv(old):archive.setdefault((int(row['j']),int(row['N'])),[]).append(row)
    replay=[]
    for group,runs in groups.items():
        j,nu,div=group
        if nu:continue
        for m,v in runs:
            n=m['N'];rows=archive.get((j,n))
            if not rows or div!=(4 if j==4 and n==1800 else 1):continue
            rows.sort(key=lambda r:int(r['index']));k=round(float(rows[0]['tau'])*TICKS)
            if k not in v['ticks']:
                replay.append(dict(**m,status='TIME_NOT_SAVED',tau=k/TICKS));continue
            u=v['U'][np.searchsorted(v['ticks'],k)];old_u=np.array([float(r['u']) for r in rows]);e=u-old_u
            replay.append(dict(**m,status='COMPARED',tau=k/TICKS,L2_normalized=float(np.sqrt(2*np.mean(e*e))),Linf=float(np.max(np.abs(e)))))
    write_csv(out/'replay_vs_original_HDF5.csv',replay)
    # Common times within each grid-refinement group. No interpolation of fields in time.
    for group,runs in groups.items():
        if len(runs)<2:continue
        target=max(runs,key=lambda r:r[0]['N'])[1]; ktarget=target['ticks'][target['best']]
        ticks=set.intersection(*(set(v['ticks']) for m,v in runs));k=min(ticks,key=lambda q:(abs(q-ktarget),q))
        for m,v in runs:
            i=np.searchsorted(v['ticks'],k)
            common.add(v['U'][i],LENGTH,dict(**m,tau=k/TICKS,selection='nearest common time to finest minimum',target_tau=ktarget/TICKS),v['D'][i])
    rep.save(out/'minima');common.save(out/'common_times');write_csv(out/'inventory.csv',inventory);write_csv(out/'local_minima.csv',candidates);write_csv(out/'problems.csv',problems)
    status=dict(expected=len(inventory),completed=sum(r['status']=='OK' for r in inventory),common_profiles=len(common.tables['summary']),errors=len(problems),replay_profiles_compared=sum(r['status']=='COMPARED' for r in replay))
    (out/'status.json').write_text(json.dumps(status,indent=2)+'\n');return status

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',default='.');p.add_argument('--out',required=True);p.add_argument('--catalog',default='fase9a/input/catalog.csv');p.add_argument('--zip',required=True);a=p.parse_args()
    s=audit(a.root,a.out,a.catalog)
    with ZipFile(a.zip,'w',ZIP_DEFLATED,compresslevel=6) as z:
        for path in sorted(Path(a.out).rglob('*')):
            if path.is_file():z.write(path,path.relative_to(a.out))
        z.write(a.catalog,'catalog.csv')
    print('FASE9A_HDF5_'+('OK' if s['errors']==0 else 'PARCIAL'),json.dumps(s),a.zip,flush=True)
    return int(s['errors']!=0)
if __name__=='__main__':raise SystemExit(main())
