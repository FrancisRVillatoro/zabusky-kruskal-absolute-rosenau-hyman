"""Reproduce the Phase 9A figures from the measured CSVs, without new integrations."""
import argparse,csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .profile_metrics import read_csv

def plot(root):
    root=Path(root);out=root/'figures';out.mkdir(parents=True,exist_ok=True)
    r=read_csv(root/'initial_scaling.csv');z=[a for a in r if a['family']=='Z'];ps=sorted({float(a['p']) for a in z});nmax=max(int(a['N']) for a in z)
    def select(p,alpha):return sorted([a for a in z if float(a['p'])==p and float(a['alpha'])==alpha],key=lambda a:int(a['N']))
    def arr(a,key):return np.array([float(x[key]) for x in a])
    fig,axes=plt.subplots(1,2,figsize=(9.3,3.6),layout='constrained')
    for p,m in [(2.,'o'),(2.25,'s'),(2.375,'^'),(2.5,'D'),(2.75,'v'),(3.,'x')]:
        a=select(p,.25);axes[0].loglog(arr(a,'N'),arr(a,'velocity_L2_extended'),marker=m,ms=3,label=f'$p={p:g}$')
    axes[0].set(xlabel='$N$',ylabel=r'$\|F_h(U_0)\|_{2,h}$',title='Global initial velocity');axes[0].legend(fontsize=8,ncol=2);axes[0].grid(alpha=.2)
    vals=[];lo=[];hi=[]
    for p in ps:
        q=[float(a['observed_core_growth']) for a in z if int(a['N'])==nmax and float(a['p'])==p];v=np.mean(q);vals.append(v);lo.append(v-min(q));hi.append(max(q)-v)
    axes[1].plot(ps,2.5-np.array(ps),'--',lw=1.4,label=r'$5/2-p$')
    axes[1].errorbar(ps,vals,yerr=[lo,hi],fmt='o',ms=4,label='Measured, 4 offsets')
    axes[1].axhline(0,color='.5',lw=.7);axes[1].set(xlabel='$p$',ylabel='Doubling exponent (local norm)',title='17 nodes around each zero');axes[1].legend(fontsize=8);axes[1].grid(alpha=.2)
    for ext in ('pdf','png'):fig.savefig(out/f'initial_velocity.{ext}',dpi=200);plt.close(fig) if ext=='png' else None
    fig,axes=plt.subplots(1,2,figsize=(9.3,3.5),layout='constrained')
    for a,m in [(0.,'o'),(.25,'s'),(.5,'^'),(.75,'x')]:
        q=select(2.25,a)[1:];axes[0].semilogx(arr(q,'N'),arr(q,'increment_scaled_coefficient_squared'),marker=m,ms=3,label=fr'$\alpha={a:g}$')
        axes[0].axhline(float(q[-1]['lattice_global_prediction'])**2,color=axes[0].lines[-1].get_color(),ls=':',lw=1)
        q=select(2.5,a)[1:];axes[1].semilogx(arr(q,'N'),arr(q,'increment_squared_per_log2'),marker=m,ms=3,label=fr'$\alpha={a:g}$')
    axes[0].set(xlabel='$N$',ylabel=r'$h^{1/2}(\|F_h\|^2-\|F_{2h}\|^2)/(1-2^{-1/2})$',title='$p=9/4$: subcritical coefficient');axes[0].legend(fontsize=8,ncol=2);axes[0].grid(alpha=.2)
    pred=float(select(2.5,0.)[-1]['critical_log_slope']);axes[1].axhline(pred,color='black',ls=':',label='Predicted');axes[1].set(xlabel='$N$',ylabel=r'$(\|F_h\|^2-\|F_{2h}\|^2)/\log 2$',title='$p=5/2$: logarithmic coefficient');axes[1].legend(fontsize=8);axes[1].grid(alpha=.2)
    for ext in ('pdf','png'):fig.savefig(out/f'initial_velocity_coefficients.{ext}',dpi=200);plt.close(fig) if ext=='png' else None
    a=read_csv(root/'archive_profiles/amplitude_localization.csv');b=read_csv(root/'archive_profiles/distance_localization.csv');fig,axes=plt.subplots(1,2,figsize=(9.3,3.6),layout='constrained')
    for j,m in [(1,'o'),(2,'s'),(3,'^'),(4,'D')]:
        q=[x for x in a if int(x['j'])==j and int(x['N'])==1800];axes[0].plot(arr(q,'pl_area_fraction'),arr(q,'pl_residual_fraction'),marker=m,ms=3,label=f'Return {j}');
        q=[x for x in b if int(x['j'])==j and int(x['N'])==1800];axes[1].semilogx(arr(q,'radius'),arr(q,'pl_residual_fraction'),marker=m,ms=3,label=f'Return {j}')
    axes[0].plot([0,1],[0,1],':',color='.5',label='Uniform residual');axes[0].set(xlim=(0,.5),ylim=(0,1.02),xlabel=r'Fraction of period with $|u|\leq a$',ylabel='Fraction of squared residual',title='Amplitude-selected region');axes[0].legend(fontsize=8);axes[0].grid(alpha=.2)
    axes[1].set(xlabel='Distance to nearest crossing',ylabel='Fraction of squared residual',ylim=(0,1.02),title='Fixed physical neighbourhoods');axes[1].legend(fontsize=8);axes[1].grid(alpha=.2)
    for ext in ('pdf','png'):fig.savefig(out/f'return_localization.{ext}',dpi=200);plt.close(fig) if ext=='png' else None
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='fase9a/results_local');a=p.parse_args();plot(a.root)
