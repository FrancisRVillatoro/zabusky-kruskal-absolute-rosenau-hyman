#!/bin/bash
#SBATCH --job-name=absK9A
#SBATCH --partition=cpu_parti
#SBATCH --constraint=cpu
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G
#SBATCH --time=01:00:00
#SBATCH --output=fase9a/logs/post_%j.out
#SBATCH --error=fase9a/logs/post_%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR}"
PY=/mnt/home/soft/python/programs/x86_64_sles156/3.14.3/bin/python3
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONNOUSERSITE=1
"$PY" -m fase9a.hdf5_audit --root . --out "fase9a/results_picasso_${SLURM_JOB_ID}" --zip "fase9a/Fase9A_HDF5_${SLURM_JOB_ID}.zip"
