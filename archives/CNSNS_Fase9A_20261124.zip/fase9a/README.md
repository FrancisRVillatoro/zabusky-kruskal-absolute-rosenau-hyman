# Fase 9A — 24 de noviembre de 2026

## Estado
Demostración y campaña instantánea local completadas. Auditoría de 12 perfiles archivados completada (tres perfiles exportados originalmente de Picasso y nueve reproducciones locales de la revisión anterior). La lectura directa de 42 HDF5 originales de Picasso queda pendiente de ejecución por el autor. No se requiere ninguna integración nueva. No confundir la verificación del postproceso con la verificación de los HDF5 reales.

## Contenido
- `zero_scaling_CNSNS.tex`: proposición, prueba uniforme respecto a la traslación de malla, coeficiente de red subcrítico y coeficiente logarítmico crítico (LaTeX compilado en documento de prueba).
- `initial_scaling.py`: norma global y en 17 nodos por cero, 396 evaluaciones del operador real, 9 mallas, 10 p, 4 offsets para Z, más P p=2. L fijo de 45.23893421169302. La sinusoide es una traslación del coseno. Se usa `PeriodicAbsK.velocity` y además un cálculo de comprobación del mismo stencil en long double, con la misma LU de la masa en float64. Las estimaciones de pendientes y coeficientes se obtienen de este último para reducir cancelación de diferencias terceras. No se integra en tiempo.
- `reference_model/`: copia inalterada de `absk_radau/model.py` de fase 2, para reproducir localmente. No sobrescribe ningún solver de Picasso. SHA256 del operador en `results_local/initial_scaling_meta.json`.
- `input/refinement_profiles.csv`, `input/profile_provenance.csv`: copias del suplemento `CNSNS_revision_Claude.zip` -> `CNSNS_Suplemento.zip` -> `audit/results/`, con procedencia preservada. No son todos exportaciones directas de Picasso.
- `input/catalog.csv`: 15 perfiles inviscidos (fases 4 y 4B) y 27 regularizados (fase 6), con tiempo y distancia esperados de los ZIP de producción. No se incluye el bloque fallido N1800, divisor 1, j4.
- `profile_metrics.py`: medidas nodales y del interpolante lineal periódico de los campos. El residuo es la diferencia respecto al coseno alineado por la fase fundamental; se interpola linealmente también el residuo para las integrales PL. No se extrapolan discontinuidades ni se infieren ceros submalla del continuo. Se miden todas las componentes de |u|<=a que contienen cruces, sin elegir arbitrariamente el más abrupto. Los ceros aislados exactos con cambio de signo se cuentan una vez; mesetas nulas se señalan aparte.
- `results_local/`: CSV, figuras y pruebas. `archive_profiles/`: análisis completo de los 12 perfiles archivados. Las curvas de amplitud se evalúan en 9 umbrales, las de distancia en 7 radios físicos. Se distinguen las trayectorias con reinicio de paso del cuarto retorno.
- `hdf5_audit.py`: postproceso de solo lectura. Valida estado COMPLETED, configuración, horizonte, calendario, D recalculado de todos los campos, mínimo local seleccionado frente al catálogo; registra SHA256 de cada HDF5. Exporta todos los mínimos y su número, métricas de capas, localización y perfiles completos; compara asimismo campos al tiempo común más próximo al mínimo fino dentro de cada grupo (j,nu,divisor), y coteja los 12 perfiles archivados contra los HDF5 originales al mismo instante. No mezcla pasos temporalmente distintos en una comparación de malla. Si hay errores devuelve PARCIAL y un ZIP diagnóstico; no completa datos ausentes.
- `slurm/postprocess.slurm`: un trabajo, Python absoluto ya validado en Picasso; no lanza integraciones.

## Reproducción local
Desde la raíz del paquete con Python, NumPy, SciPy, h5py y Matplotlib:

```bash
export PYTHONPATH=fase9a/reference_model:.
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python -m unittest discover -s fase9a/tests -v
python -m fase9a.initial_scaling --out fase9a/results_local --max-power 16
python - <<'PY'
from fase9a.profile_metrics import archive_audit
from fase9a.initial_scaling import LENGTH
archive_audit('fase9a/input/refinement_profiles.csv','fase9a/input/profile_provenance.csv','fase9a/results_local/archive_profiles',LENGTH)
PY
python -m fase9a.figures
```

## Picasso
Descomprimir el ZIP en la raíz del proyecto ya existente. Ejecutar:

```bash
sha256sum -c MANIFEST_FASE9A.sha256
mkdir -p fase9a/logs
sbatch fase9a/slurm/postprocess.slurm
squeue -l
```

El directorio de salida `fase9a/results_picasso_JOBID/` y el ZIP `fase9a/Fase9A_HDF5_JOBID.zip` son específicos del trabajo. Los archivos de fases 3–6 no se modifican. El estado esperado es 42/42 y 12 cotejos con el archivo de perfiles; la ejecución sobre HDF5 auténticos no se ha realizado aún.

## Validación
Nueve pruebas locales correctas, entre ellas identidad del stencil y la masa, norma continua para p=3, predicción de red p=9/4, integración de máscaras periódicas y cruces exactos. Los doce perfiles archivados se procesaron por separado. La prueba end-to-end de 42 rutas usa ficheros HDF5 artificiales con metadatos y tiempos de catálogo, no resultados de la PDE, y comprueba que un archivo INCOMPLETE se rechaza. La prueba no verifica disponibilidad ni estado de los HDF5 en Picasso. Se ha comprobado la sintaxis del script Slurm y la compilación del texto matemático.
