import unittest,tempfile,json
from pathlib import Path
import numpy as np,h5py
from fase9a.initial_scaling import (shift_sin,stencil,mass_fft,continuum_norm,lattice,LENGTH,PeriodicAbsK,norm)
from fase9a.profile_metrics import (roots,amp_segments,distance_segments,integrate_segments,measure,read_csv)
from fase9a.hdf5_audit import read_run,audit,TC,TICKS

class Phase9ATests(unittest.TestCase):
    def test_production_operator(self):
        m=PeriodicAbsK(128,LENGTH,2.25);u=shift_sin(m.n,.25);g=np.sign(u)*abs(u)**np.longdouble(m.p);b,c=stencil(g,m.dx)
        self.assertLess(np.max(np.abs(-mass_fft(b+c)-m.velocity(np.asarray(u,float)))),1e-11)
        self.assertLess(np.max(np.abs(m.mass@mass_fft(np.asarray(g,float))-np.asarray(g,float))),1e-13)
    def test_mass_bounds(self):
        m=PeriodicAbsK(64,LENGTH,2.25);eig=np.linalg.eigvalsh(m.mass.toarray());self.assertAlmostEqual(eig.min(),2/15);self.assertAlmostEqual(eig.max(),1.)
    def test_p3_continuum_norm(self):
        m=PeriodicAbsK(1024,LENGTH,3.);v=m.velocity(np.asarray(shift_sin(1024,.25),float));self.assertLess(abs(norm(v,m.dx)-continuum_norm(3.,LENGTH)),1e-8)
    def test_lattice_core_p225(self):
        m=PeriodicAbsK(8192,LENGTH,2.25);u=shift_sin(m.n,.25);b,c=stencil(np.sign(u)*abs(u)**np.longdouble(m.p),m.dx);v=mass_fft(b+c)
        ids=np.r_[np.arange(-8,9)%m.n,np.arange(m.n//2-8,m.n//2+9)%m.n];pred=np.sqrt(2)*(2*np.pi/LENGTH)**m.p*lattice(m.p,.25)[0]
        self.assertLess(abs(norm(v[ids],m.dx)*m.dx**.25/pred-1),1e-4)
    def test_root_touch_vs_cross(self):
        z,flat=roots(np.array([0.,1.,2.,1.,0.,-1.,-2.,-1.]));self.assertEqual(len(z),2);self.assertEqual(flat,0)
        self.assertEqual(len(roots(np.array([0.,1.,1.,1.,0.,1.,1.,1.]))[0]),0)
    def test_periodic_band(self):
        s=amp_segments(np.array([0.,1.,0.,-1.]),.25);self.assertAlmostEqual(sum(b-a for a,b in s),1.)
        q=distance_segments([0.,2.],.25,4);self.assertAlmostEqual(sum(b-a for a,b in q),1.)
    def test_linear_integral(self):
        self.assertAlmostEqual(integrate_segments(np.array([0.,2.,0.]),[(.25,.75)]),(4/3)*(.75**3-.25**3));self.assertAlmostEqual(integrate_segments(np.ones(16),[(15.5,16.5)]),1.)
    def test_modal_measure(self):
        n=128;x=2*np.pi*np.arange(n)/n;u=.9*np.cos(x)+.1*np.cos(5*x);s,*_=measure(u,LENGTH,dict(j=1,N=n));self.assertAlmostEqual(s['D'],np.sqrt(.02));self.assertAlmostEqual(s['e5_over_H'],1.)
    def test_all_catalog_paths_synthetic(self):
        catalog=Path('fase9a/input/catalog.csv');rows=read_csv(catalog)
        self.assertEqual(len(rows),42)
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for r in rows:
                n=int(r['N']);nu=float(r['nu']);j=int(r['j']);div=int(r['divisor']);tau=float(r['tau']);D=float(r['D']);path=root/r['path'];path.parent.mkdir(parents=True,exist_ok=True)
                # Artificial fixture, not a simulated trajectory. Exact real catalogue times and distances.
                t0,t1=float(r['start']),float(r['end']);ts=np.array([t0,tau-1/3200,tau,tau+1/3200,t1]);ds=np.array([D+.2,D+.01,D,D+.01,D+.2]);u=(1+ds[:,None])*np.cos(2*np.pi*np.arange(n)/n)
                d=np.zeros((len(ts),10));d[:,5]=ds
                cfg=dict(phase=r['phase'],N=n,family='Z',project_half=True,p=2.25,M=4,nu=nu,dt=TC/3200/div,T_cross=TC,run_id=r['run_id'],kind=r['mode'],regularization='fourth_order',strict=False,phase3_run_id=r['run_id'],mode=r['mode'])
                with h5py.File(path,'w') as f:
                    f.attrs.update(status='COMPLETED',n_cells=n,period=LENGTH,amplitude=1.,config_json=json.dumps(cfg));f['t']=ts*TC;f['u']=u;f['diagnostics']=d
            s=audit(root,root/'report',catalog);self.assertEqual(s['completed'],42);self.assertEqual(s['errors'],0)
            r=rows[0];p=root/r['path']
            with h5py.File(p,'a') as f:f.attrs['status']='INCOMPLETE'
            with self.assertRaises(ValueError):read_run(root,r)

if __name__=='__main__':unittest.main()
