"""Phase 9A: instantaneous zero singularity and archived-field diagnostics."""
