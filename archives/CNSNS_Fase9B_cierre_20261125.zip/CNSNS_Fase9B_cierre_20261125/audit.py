"""Reproduce the closure audit from the original Picasso report ZIP (not HDF5).
Usage: python audit.py Fase9B_CNSNS_resultados_20261125.zip --out audit_output
Dependencies: numpy, scipy, pandas, matplotlib. No integration of PDE trajectories.
"""
import argparse, io, json, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import cumulative_simpson, cumulative_trapezoid, trapezoid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('zip'); ap.add_argument('--out',default='audit_output'); args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.zip) as z:
        assert z.testzip() is None
        read=lambda n: pd.read_csv(io.BytesIO(z.read(n)))
        load=lambda name: np.load(io.BytesIO(z.read(name)),allow_pickle=False)
        summary='results/report/summary/'
        ev=read(summary+'free_events.csv'); ms=read(summary+'mode_statistics.csv'); ex=read(summary+'exchange.csv'); fb=read('results/report/field_budget.csv'); rd=read('results/report/return_differences.csv')
        arch=read('results/archive/summary/exchange.csv'); inv=json.loads(z.read('results/report/status.json')); ai=json.loads(z.read('results/archive/status.json'))
        audits=[json.loads(z.read(n)) for n in z.namelist() if n.startswith('results/new/') and n.endswith('.audit.json')]
        checks=[]
        for name in z.namelist():
            if not name.endswith('.npz'):continue
            with load(name) as a:
                t=a['tau']; n=a['n']; c=a['c']; b=a['b']; k=np.flatnonzero(n==7)[0]; e7=4*abs(c[:,k])**2
                assert np.all(np.diff(t)>0) and np.isfinite(c).all() and np.isfinite(b).all()
                checks.append(dict(path=name,samples=len(t),tau_end=t[-1],D_identity_max=float(np.max(abs(a['D']**2-(a['r']-1)**2-a['H']))),r_identity_max=float(np.max(abs(a['r']-2*abs(c[:,0])))),mean_e7_decimated=float(trapezoid(e7,t)/(t[-1]-t[0])),max_e7_decimated=float(e7.max())))
        pd.DataFrame(checks).to_csv(out/'trace_checks.csv',index=False)
        near=[]
        for N in (900,1800):
            with load(f'results/report/plot_traces/s7_pade_null_N{N}_d2.npz') as a, load(f'results/report/plot_traces/s7.0_N{N}_d2.npz') as b:
                t=a['tau']; k=np.flatnonzero(a['n']==7)[0]; f=a['b'][:,k]; T=float(a['T']); tb=b['tau']; m=float(b['d'][k]); c=b['c'][:,k];
                A=-1j*T*(cumulative_simpson(f.real,x=t,initial=0)+1j*cumulative_simpson(f.imag,x=t,initial=0)); At=-1j*T*cumulative_trapezoid(f,t,initial=0)
                pred=trapezoid(4*abs(A)**2,t)/(t[-1]-t[0]); predt=trapezoid(4*abs(At)**2,t)/(t[-1]-t[0]); observed=trapezoid(4*abs(c-c[0])**2,tb)/(tb[-1]-tb[0])/m**2
                near.append(dict(N=N,m7=m,pred_simpson=pred,pred_trapezoid=predt,observed=observed,relative_difference=observed/pred-1))
        near=pd.DataFrame(near);near.to_csv(out/'null_coefficient_decimated.csv',index=False)
        finest=ev[(ev.N==1800)&(ev.dt_divisor==4)].copy();finest.to_csv(out/'four_lengths_fine_returns.csv',index=False)
        m7=ms[ms.n==7].copy();m7.to_csv(out/'mode7_statistics.csv',index=False)
        sel=ex[(ex.selection=='prominent_chronological')&(ex.n==5)].copy(); sel['uncancelled_fraction_of_gain']=sel.net/sel.gross_gain;sel.to_csv(out/'mode5_balances.csv',index=False)
        central=sel[sel.case=='s7.2_N1800_d4'];central.to_csv(out/'central_mode5_balance.csv',index=False)
        aa=arch[(arch.selection=='prominent_chronological')&(arch.n==5)&(arch.N==1800)];aa.to_csv(out/'archived_mode5_balance.csv',index=False)
        fb[fb.selection=='prominent_chronological'].to_csv(out/'chronological_field_budget.csv',index=False);rd[rd.selection=='prominent_chronological'].to_csv(out/'chronological_return_differences.csv',index=False)
        # Independent quadrature from reduced endpoint traces; not a reproduction of full-step balances.
        with load('results/report/plot_traces/s7.2_N1800_d4.npz') as a:
            t=a['tau'];k=np.flatnonzero(a['n']==5)[0];P=8*float(a['T'])*a['d'][k]*np.imag(np.conj(a['c'][:,k])*a['b'][:,k]); ts=[0]+finest[finest.nstar==7.2].tau.tolist(); rows=[]
            for j,(lo,hi) in enumerate(zip(ts[:-1],ts[1:]),1):
                x=np.r_[lo,t[(t>lo)&(t<hi)],hi];y=np.interp(x,t,P);rows.append(dict(j=j,start=lo,end=hi,gain=trapezoid(np.maximum(y,0),x),loss=trapezoid(np.maximum(-y,0),x),net=trapezoid(y,x)))
            pd.DataFrame(rows).to_csv(out/'central_balance_decimated_check.csv',index=False)
        x900=m7[m7.case=='s7.0_N900_d2'].mean_e.iloc[0];x1800=m7[m7.case=='s7.0_N1800_d2'].mean_e.iloc[0];rat=x900/x1800
        status=dict(expected=inv['expected'],complete=inv['complete'],archive_complete=ai['complete'],audit_completed=sum(a['status']=='COMPLETED' for a in audits),audit_failed=sum(a['status']=='FAILED' for a in audits),new_chronological_events=len(ev),archive_chronological_events=len(read('results/archive/summary/free_events.csv')),max_D_identity=max(x['D_identity_max'] for x in checks),mode7_mean_ratio_N900_over_N1800=rat,mode7_observed_order=float(np.log2(rat)),central_mode5_max_abs_balance_defect=float(central.defect.abs().max()),all_new_mode5_max_abs_balance_defect=float(sel.defect.abs().max()))
        (out/'audit_status.json').write_text(json.dumps(status,indent=2)+'\n')
        fig,ax=plt.subplots(figsize=(7,4.4),layout='constrained')
        for s,g in finest.groupby('nstar'):ax.plot(g.j,g.D,'o-',label=fr'$n_\ast={s:g}$')
        ax.set(xlabel='Chronological return',ylabel=r'$D_j$',xticks=[1,2,3,4]);ax.legend();ax.grid(alpha=.2);fig.savefig(out/'returns_by_length.png',dpi=200);plt.close(fig)
        fig,ax=plt.subplots(figsize=(7,4.4),layout='constrained');ax.plot(central.j,central.gross_gain,'o-',label='Integrated positive rate');ax.plot(central.j,central.gross_loss,'s--',label='Integrated negative rate (magnitude)');ax.set(xlabel='Chronological excursion',ylabel='Integrated mode-5 power rate',xticks=[1,2,3,4]);ax.legend();ax.grid(alpha=.2);fig.savefig(out/'mode5_exchange.png',dpi=200);plt.close(fig)
        fig,ax=plt.subplots(figsize=(7,4.4),layout='constrained');ax.loglog([900,1800],[x900,x1800],'o-',label='Padé at continuum null');ax.loglog([900,1800],[x900,x900/256],'s--',label=r'$N^{-8}$ reference');ax.set(xlabel='N',ylabel='Mean mode-7 power');ax.legend();ax.grid(alpha=.2);fig.savefig(out/'mode7_null_scaling.png',dpi=200);plt.close(fig)
        print(json.dumps(status,indent=2))
if __name__=='__main__':main()
