# CNSNS — Cierre científico de la fase 9B (25 noviembre 2026)

## Fuente y alcance de la auditoría

`Fase9B_CNSNS_resultados_20261125.zip`: integridad CRC comprobada; 13/14 trayectorias nuevas completas, 55/56 segmentos completos, 12/12 historias de archivo recuperadas (tres regularizadas N=450 solo hasta tau=1.25). Las nueve pruebas de Picasso pasaron. Se han auditado los 26 NPZ exportados y las tablas de diagnóstico; no están incluidos los HDF5 ni todas las muestras de cada paso de las trayectorias nuevas. La identidad modal se comprueba en los NPZ hasta 3.33e-16. Las cifras de mínimos y balances de alta cadencia proceden de las tablas de producción; la recomputación por cuadratura de los NPZ reducidos es un control independiente aproximado, no una reconstrucción exacta de todos los pasos.

La única trayectoria incompleta es s7.2_N1800_d2 (3832521_6), último estado aceptado tau=3.47359375; Newton falla en tau=3.47375. La trayectoria d4, desde tau=0, sí llega a 4.25. No repetir ni sustituir silenciosamente la trayectoria fallida.

## Longitud, nulo y mínimos cronológicos

Comparar `free_events.csv`, no mínimos seleccionados en ventanas centradas en enteros. En los cuatro casos N=1800, Delta tau=1/12800 desde cero, hay cuatro mínimos prominentes. El cuarto para nstar=6.8 ocurre en 3.59836 y no pertenece a la ventana [3.8,4.2].

| nstar | tau1 | tau4 | D1 | D2 | D3 | D4 | e5/H en cuarto |
|---|---:|---:|---:|---:|---:|---:|---:|
|6.8|0.948|3.598|0.04279|0.09104|0.21596|0.35824|0.8648|
|7.0|0.980|3.881|0.03984|0.08169|0.16009|0.35575|0.9200|
|7.2|1.009|4.033|0.04607|0.07775|0.12870|0.23833|0.9067|
|7.4|1.038|4.160|0.04246|0.07716|0.09022|0.19134|0.7581|

El nulo exacto Padé N=1800,d2 da D4=0.35574, frente a 0.35577 al usar la longitud del nulo continuo. El comportamiento al incrementar nstar desde 7 hasta 7.4 concuerda cualitativamente con la intervención sobre m7 en Galerkin. El caso 6.8 impide inferir una relación universal con |m7|. Variar L cambia todos los multiplicadores, no solo el séptimo. La cuarta distancia no es un criterio de optimalidad global. El caso central con paso uniforme refinado coincide con el previo de paso mixto en D4 (diferencia 0.00056). Todas las nuevas trayectorias están proyectadas a antisimetría de media onda.

## Potencia del modo siete

En el nulo continuo el multiplicador Padé residual escala como N^-4. Al duplicar N=900 a 1800, la potencia media e7 pasa de 5.08525e-17 a 1.99281e-19 (factor 255.18; exponente efectivo 7.995). En el nulo discreto los máximos son 7.69e-28 y 1.09e-25 respectivamente; domina el suelo de redondeo. El coeficiente de la ley cuadrática se ha calculado también desde la integral del flujo de la trayectoria con nulo discreto, sobre los NPZ reducidos. El cociente observado y la predicción por Simpson son 0.09003/0.09022 (N=900) y 0.09033/0.09040 (N=1800). La cuadratura trapezoidal también se incluye. Este test compara las dos longitudes extremadamente próximas a N fijo, no prueba uniformidad de un límite de la PDE. La potencia en otros nstar no sigue un único coeficiente universal.

## Cancelación de la potencia del quinto modo

Para la trayectoria central d4 se ha usado el balance d e5/d tau = 8 T m5 Im(conj(a5)*b5). Las integrales de las partes positiva y negativa de esta tasa no representan transferencias conservativas entre pares de modos.

| retorno | ganancia | pérdida | neto | e5 final |
|---|---:|---:|---:|---:|
|1|0.53795978|0.53780861|0.00015117|0.00015118|
|2|0.54251509|0.54119220|0.00132289|0.00147411|
|3|0.55595920|0.54699876|0.00896045|0.01043453|
|4|0.56290645|0.52398899|0.03891746|0.04935209|

El defecto absoluto máximo es 1.01e-7 en la trayectoria central y 1.39e-6 para todos los balances cronológicos nuevos del modo cinco. La fracción de la ganancia que no se cancela crece de aproximadamente 0.028% a 6.91%. La recomputación de los NPZ reducidos preserva la tendencia, pero es menos precisa para las diferencias pequeñas. El resultado concuerda con Galerkin de corte 51; no explica teóricamente el período ni demuestra una resonancia específica. El modo cinco domina H en los últimos mínimos de las cuatro longitudes examinadas.

## Regularización

En los archivos históricos N=1800, el incremento de e5 durante la cuarta excursión disminuye con nu: 0.03872, 0.03061, 0.01747, 0.00326. Para nu=0.004, la parte no lineal neta es 0.01297 y la contribución hiperviscosa es -0.00981. Se modifican tanto el balance no lineal como la disipación explícita. En los archivos antiguos la cuadratura es más gruesa: el defecto en nu=0 es 4.96e-4 y el cambio por decimación 4.73e-3 en la cuarta excursión; no usar estas tablas para atribuir con alta precisión las cancelaciones iniciales.

## Resolución y novedad

Los observables son más reproducibles que el campo. Para nstar=7.4, el cuarto mínimo cronológico cambia 0.00457 entre los pasos d2 y d4 en N=1800, pero la discrepancia máxima de los campos en los tiempos comunes de su ventana es 0.1146 (la ventana termina en el horizonte 4.25). El control espacial d2 da 0.0788. Para nstar=6.8 la comparación de campo en la cuarta ventana dispone solo de 40 muestras comunes, por la cadencia de salida adaptada a ventanas enteras. No hay convergencia fuerte demostrada ni estabilidad transversal general. La coincidencia de tiempos/depths no prueba convergencia de trayectorias.

La conservación del modo k=1 está ligada a los Casimires ya conocidos (Vodova, Nonlinearity 26, 757-762, 2013, DOI 10.1088/0951-7715/26/3/757). La recurrencia imperfecta y los modelos acoplados tienen precedentes en KdV (Watanabe, Ohishi y Tanaca, JPSJ 42, 1382-1390, 1977, DOI 10.1143/JPSJ.42.1382). La búsqueda focalizada también localiza un antecedente reciente de Hyman, arXiv:2610.17489 (octubre 2026), sobre supresión modal en radiación de colisiones y estructura de K(m,m); se consultó el resumen, no el texto integral. Debe contrastarse antes de la redacción final. No atribuir novedad a la existencia del nulo; destacar la ley de detuning en dimensión finita, el defecto N^-8 comprobado y los balances de recurrencia del modelo absoluto. No se garantiza prioridad absoluta.

## Decisión

9B se cierra como estudio de mecanismo numérico de tiempo finito. No repetir la tarea fallida. No se certifica convergencia continuum, uniformidad del detuning ni explicación analítica del período. La fase 9C debe centrarse en perturbaciones transversales y ecuación variacional. Los resultados completos de 9A y 9B se incorporarán al manuscrito después de esa fase, con una selección de figuras. Todos los futuros arrays de Picasso con N<999 se lanzarán sin limitación de concurrencia inferior a N, salvo petición expresa del usuario.

## Reproducción

`python audit.py Fase9B_CNSNS_resultados_20261125.zip --out audit_output`

Requiere NumPy, SciPy, pandas y Matplotlib. No ejecuta integraciones de la PDE. Las tablas y figuras adjuntas se han generado con ese programa. Los CSV de balances completos son selecciones de las tablas originales de Picasso; las comprobaciones NPZ se identifican como reducidas.
