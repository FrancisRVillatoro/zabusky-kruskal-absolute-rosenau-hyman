"""Modal identities for the signed cosine. Time variable tau=t/T_cross."""
import numpy as np
P=2.25

def crossing(nstar,p=P): return 2*np.pi*nstar*2*p/(p+1)
def pade_nstar_zero(N,n=7):
    theta=2*np.pi*n/N
    return N/(2*np.pi)*np.sqrt(24*np.sin(theta/2)**2/(5+np.cos(theta)))
def symbols(n,nstar,N=None):
    n=np.asarray(n,dtype=float); k=n/nstar
    if N is None: return k*(1-k*k),k**4
    h=2*np.pi*nstar/N; theta=2*np.pi*n/N
    mass=(66+52*np.cos(theta)+2*np.cos(2*theta))/120
    d=np.sin(theta)/h*((np.cos(theta)+5)/6-4*(np.sin(theta/2)/h)**2)/mass
    q=-4*np.sin(theta/2)**2/h**2*(1+np.sin(theta/2)**2/3)
    return d,q*q

def coeffs(u,p=P):
    return np.fft.rfft(u,norm='forward'),np.fft.rfft(abs(u)**(p-1)*u,norm='forward')
def powers(c): return 4*abs(c)**2

def rates(c,b,d,q4,T,nu):
    e=powers(c)
    transfer=8*T*d*np.imag(np.conj(c)*b)
    damp=-2*T*nu*q4*e
    return transfer,damp

def diagnostics(c):
    # Input positive odd coefficients, excluding zero/Nyquist.
    e=powers(c); r=2*abs(c[...,0]); H=np.sum(e[...,1:],axis=-1)
    return np.sqrt((r-1)**2+H),r,H

def from_field(u):
    c=np.fft.rfft(u,norm='forward'); e=4*abs(c)**2
    e[0]*=.5
    if len(u)%2==0:e[-1]*=.5
    r=2*abs(c[1]); H=e[2:].sum()
    return np.sqrt((r-1)**2+H+e[0]),r,H
