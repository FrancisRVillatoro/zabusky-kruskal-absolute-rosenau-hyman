"""Leading coefficient of finite-dimensional modal excitation near exact null."""
import argparse
from pathlib import Path
import numpy as np
from scipy.integrate import cumulative_trapezoid
from .analyze import write_csv

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',default='fase9b/results_local/galerkin');p.add_argument('--out',default='fase9b/results_local/summary/near_null.csv');a=p.parse_args();root=Path(a.input)
    with np.load(root/'L7.0_K21.npz') as z:
        t=z['tau'];k=np.flatnonzero(z['n']==7).item();A=-1j*float(z['T'])*cumulative_trapezoid(z['b'][:,k],t,initial=0)
    prediction=4*abs(A)**2;mean=float(np.trapezoid(prediction,t)/t[-1]);rows=[]
    for file in sorted(root.glob('near_*_K21.npz')):
        with np.load(file) as x:
            assert np.array_equal(x['tau'],t);m=x['d'][k];a7=x['c'][:,k]/m;e=4*abs(a7)**2
            rows.append(dict(case=file.stem,nstar=float(file.stem.split('_')[1]),multiplier=float(m),mean_e7_over_m7_squared=float(np.trapezoid(e,t)/t[-1]),predicted_mean=mean,rms_relative_amplitude_defect=float(np.sqrt(np.trapezoid(abs(a7-A)**2,t)/np.trapezoid(abs(A)**2,t))),max_relative_amplitude_defect=float(np.max(abs(a7-A))/np.max(abs(A)))))
    write_csv(Path(a.out),rows)
    print('NEAR_NULL_OK',len(rows),mean,flush=True)
if __name__=='__main__':main()
