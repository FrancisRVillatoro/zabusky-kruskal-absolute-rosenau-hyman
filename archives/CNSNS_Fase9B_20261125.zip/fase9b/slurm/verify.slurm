#!/bin/bash
#SBATCH --job-name=absK9Bver
#SBATCH --partition=cpu_parti
#SBATCH --constraint=cpu
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=00:30:00
#SBATCH --output=fase9b/logs/verify_%j.out
#SBATCH --error=fase9b/logs/verify_%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR}"
PY=/mnt/home/soft/python/programs/x86_64_sles156/3.14.3/bin/python3
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONNOUSERSITE=1
"$PY" -m unittest discover -s fase9b/tests -v
printf 'FASE9B_VERIFICACION_OK\n'
