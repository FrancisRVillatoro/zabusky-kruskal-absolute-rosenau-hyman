#!/bin/bash
#SBATCH --job-name=absK9Bmain
#SBATCH --partition=cpu_parti
#SBATCH --constraint=cpu
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=2-00:00:00
#SBATCH --array=1-14%8
#SBATCH --output=fase9b/logs/main_%A_%a.out
#SBATCH --error=fase9b/logs/main_%A_%a.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR}"
PY=/mnt/home/soft/python/programs/x86_64_sles156/3.14.3/bin/python3
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONNOUSERSITE=1
"$PY" -m fase9b.pade_run --index "${SLURM_ARRAY_TASK_ID}"
