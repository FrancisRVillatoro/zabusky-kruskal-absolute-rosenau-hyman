"""New full trajectories at fixed p, varying L; fixed step from tau=0.
Each segment stores all endpoint modal coefficients and fluxes (not stages).
Fields are saved on a common coarser grid. Source HDF5 files are never modified.
"""
import argparse,csv,json,time,hashlib,os
from pathlib import Path
import numpy as np
import h5py
from absk_radau.model import PeriodicAbsK,make_initial_data
from absk_radau.radau_mass import MassRadau5,NewtonOptions,NewtonFailure,RunStats
from absk_radau.io import H5Recorder
from .modal import P,crossing,coeffs,symbols,from_field
from .archive import MODES

SEGMENTS=((0.,1.25),(1.25,2.25),(2.25,3.25),(3.25,4.25))

def make_solvers(model):
    return [(name,MassRadau5(model,NewtonOptions(atol=1e-11,rtol=1e-9,max_iter=it,line_search_backtracks=ls,predictor=pred),project_half=True)) for name,it,ls,pred in [('original',12,10,'euler'),('extended_euler',32,22,'euler'),('extended_constant',32,22,'constant')]]

def metadata(row):
    return dict(case=row['case'],nstar=float(row['nstar']),N=int(row['N']),dt_divisor=int(row['dt_divisor']),nu_explicit=float(row['nu']),kind=row['kind'],p=P,project_half=True,origin='phase9b Padé/Radau IIA5',history='fixed step from tau=0')

def trace_values(u,n):
    c,b=coeffs(u);D,r,H=from_field(u)
    return c[n],b[n],D,r,H

def run_segment(row,out,seg,start,end,u,steps_per_tau):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);meta=metadata(row);N=meta['N'];nu=meta['nu_explicit'];s=meta['nstar'];tc=crossing(s);dt=tc/steps_per_tau
    model=PeriodicAbsK(N,2*np.pi*s,P,nu);variants=make_solvers(model);n=MODES[MODES<N//2];d,q=symbols(n,s,N)
    dest=out/f'seg{seg}.h5';trace=out/f'seg{seg}.npz';audit=out/f'seg{seg}.audit.json'
    k0=round(start*steps_per_tau);k1=round(end*steps_per_tau)
    if abs(k0/steps_per_tau-start)>1e-13 or abs(k1/steps_per_tau-end)>1e-13:raise ValueError('nonrepresentable segment')
    if dest.exists() or trace.exists() or audit.exists():
        if not (dest.exists() and trace.exists() and audit.exists()):raise FileExistsError('partial existing result, preserve and diagnose '+str(dest))
        au=json.loads(audit.read_text())
        if au['status']!='COMPLETED' or au['meta']!=meta or au['start']!=start or au['end']!=end or au['steps_per_tau']!=steps_per_tau:raise ValueError('existing output mismatch or failure '+str(dest))
        with h5py.File(dest,'r') as h:
            assert h.attrs['status']=='COMPLETED' and abs(h['t'][-1]/tc-end)<1e-12
            assert np.array_equal(h['u'][0],u), 'checkpoint mismatch'
            return h['u'][-1].copy()
    print('FASE9B_SEG_START',meta['case'],seg,N,s,dt,start,end,flush=True)
    cfg=dict(**meta,segment=seg,dt=dt,steps_per_tau=steps_per_tau,T_cross=tc,tau_start=start,tau_end=end)
    record=H5Recorder(dest,model,cfg,'Z',1.);stats=RunStats(mode='fixed_9B');fallback={name:0 for name,_ in variants}
    t=[];cc=[];bb=[];D=[];r=[];H=[];beg=time.perf_counter();failure=None;exc=None
    def save_modal(k,y):
        c,b,dd,rr,hh=trace_values(y,n);t.append(k/steps_per_tau);cc.append(c);bb.append(b);D.append(dd);r.append(rr);H.append(hh)
    try:
        record(k0*dt,u,stats);save_modal(k0,u)
        for k in range(k0+1,k1+1):
            errors=[]
            for name,solver in variants:
                try:un,diag=solver.step(u,dt);break
                except NewtonFailure as error:errors.append(f'{name}: {error}')
            else:raise NewtonFailure(f'fixed step unresolved tau={k/steps_per_tau}: {errors}')
            u=un;fallback[name]+=1;stats.add_step(diag,dt);stats.final_time=k*dt
            record.on_step(k*dt,dt,diag,'accepted',float('nan'));save_modal(k,u)
            # common output at 1/200 tau, and 1/1600 near the four windows
            if k==k1 or k%max(1,steps_per_tau//200)==0 or (abs(k/steps_per_tau-round(k/steps_per_tau))<=.2000001 and k%max(1,steps_per_tau//1600)==0):record(k*dt,u,stats)
        record.finish(stats)
    except BaseException as error:
        exc=error;failure=repr(error);record.fail(error)
    finally:
        # Endpoint trace includes all successfully accepted steps, even on failure.
        if t:np.savez_compressed(trace,tau=t,c=cc,b=bb,n=n,d=d,q4=q,T=tc,nu=nu,D=D,r=r,H=H,meta=json.dumps(meta))
        au=dict(status='COMPLETED' if failure is None else 'FAILED',meta=meta,start=start,end=end,steps_per_tau=steps_per_tau,dt=dt,accepted=stats.accepted,last_tau=t[-1] if t else start,max_residual=stats.max_scaled_residual,fallback=fallback,seconds=time.perf_counter()-beg,failure=failure)
        audit.write_text(json.dumps(au,indent=2)+'\n')
    if exc is not None:raise exc
    assert stats.accepted==k1-k0 and stats.max_scaled_residual<=1+1e-10
    print('FASE9B_SEG_OK',meta['case'],seg,stats.accepted,flush=True);return u

def run(row,root='fase9b/results/new',tau_end=4.25,base_steps=3200):
    m=metadata(row);N=m['N'];model=PeriodicAbsK(N,2*np.pi*m['nstar'],P,m['nu_explicit']);u=make_solvers(model)[0][1].project(make_initial_data(model,'Z',1.));kpt=base_steps*m['dt_divisor']
    for seg,(a,b) in enumerate(SEGMENTS,1):
        if a>=tau_end:break
        u=run_segment(row,Path(root)/row['case'],seg,a,min(b,tau_end),u,kpt)
    print('FASE9B_CASE_OK',row['case'],flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);p.add_argument('--manifest',default='fase9b/pade_cases.csv');p.add_argument('--out',default='fase9b/results/new');a=p.parse_args()
    rows=list(csv.DictReader(open(a.manifest)));assert 1<=a.index<=len(rows);run(rows[a.index-1],a.out)
if __name__=='__main__':main()
