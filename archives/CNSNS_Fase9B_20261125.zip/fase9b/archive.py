"""Read-only flux budget from completed production HDF5s (phases 3,4,4B,6).
No new integration, no fabricated high-cadence output.  The endpoint quadrature
is tested on a decimated grid; its defect includes time integration effects.
"""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import h5py
from .modal import crossing,symbols,coeffs,from_field
from .analyze import summarize,write_csv

MODES=np.arange(1,64,2)

def file_data(path,N,nu,nstar=7.2):
    with h5py.File(path,'r') as h:
        if h.attrs['status']!='COMPLETED':raise ValueError(f'not completed: {path}')
        assert int(h.attrs['n_cells'])==N and np.isclose(h.attrs['period'],2*np.pi*nstar,rtol=0,atol=1e-10)
        assert np.isclose(float(h.attrs['nu']),nu,rtol=0,atol=1e-13) and np.isclose(float(h.attrs['p']),2.25)
        t=h['t'][:]/crossing(nstar);u=h['u'][:]
        assert len(t)==len(u) and u.shape[1]==N and np.all(np.diff(t)>0) and np.all(np.isfinite(u))
        return t,u

def seam(t,u,s,v):
    assert abs(t[-1]-s[0])<2e-10
    err=float(np.sqrt(2*np.mean((u[-1]-v[0])**2)))
    if err>1e-10:raise ValueError(f'checkpoint mismatch: {err}')
    return np.r_[t,s[1:]],np.vstack((u,v[1:])),err

def sources(root,N,nu):
    root=Path(root); paths=[]
    if nu==0:
        role={450:'space_low',900:'space_mid',1800:'space_high'}[N];name=f'Z_p225_M4__{role}.h5'
        for loc in ['combined_fixed','rescue_fixed','main']:
            path=root/'fase3/results'/loc/name
            if not path.exists():continue
            with h5py.File(path,'r') as h:
                if h.attrs['status']=='COMPLETED':break
        else:raise FileNotFoundError(name)
        paths.append(path)
        paths.append(root/f'fase4/results/zoom1/Z_p225_M4_N{N}_zoom1.h5')
        for j in [2,3]:paths.append(root/f'fase4/results/long/Z_p225_M4_N{N}_seg{j}.h5')
        if N==450:paths.append(root/f'fase4/results/long/Z_p225_M4_N450_seg4.h5')
        else:paths.append(root/f'fase4b/results/dt_divisor_4/Z_p225_M4_N{N}_seg4_dtdiv4.h5')
    else:
        tag={.004:'0p004',.001:'0p001',.00025:'0p00025'}[nu];name=f'Z_p225_M4_nu{tag}_N{N}_d1'
        paths.append(root/f'fase6/results/short/{name}.h5')
        if N!=450:
            for j in [2,3,4]:paths.append(root/f'fase6/results/long/{name}_seg{j}.h5')
    return paths

def history(root,N,nu):
    paths=sources(root,N,nu);t,u=file_data(paths[0],N,nu);seams=[]
    if nu==0:
        s,v=file_data(paths[1],N,nu)
        # Replay zoom starts at saved phase-3 state; check every shared time.
        idx=[]
        for i,a in enumerate(t):
            if s[0]-1e-11<=a<=s[-1]+1e-11:
                j=int(np.argmin(abs(s-a)))
                if abs(s[j]-a)<1e-10:idx.append(float(np.sqrt(2*np.mean((u[i]-v[j])**2))))
        if not idx or max(idx)>1e-8:raise ValueError('zoom replay mismatch '+str(idx))
        seams.append(max(idx));left=t<s[0]-1e-11;right=t>s[-1]+1e-11
        t=np.r_[t[left],s,t[right]];u=np.vstack((u[left],v,u[right]));rest=paths[2:]
    else:rest=paths[1:]
    for path in rest:
        s,v=file_data(path,N,nu);t,u,err=seam(t,u,s,v);seams.append(err)
    if abs(t[0])>1e-11 or not np.all(np.diff(t)>0):raise ValueError('bad time history')
    return t,u,paths,seams

def from_history(t,u,N,nu,nstar,meta):
    n=MODES[MODES<N//2];c=[];b=[];D=[];r=[];H=[]
    for v in u:
        a,g=coeffs(v);c.append(a[n]);b.append(g[n]);dd,rr,hh=from_field(v);D.append(dd);r.append(rr);H.append(hh)
    d,q=symbols(n,nstar,N)
    return dict(tau=t,c=np.array(c),b=np.array(b),n=n,d=d,q4=q,T=crossing(nstar),nu=nu,D=np.array(D),r=np.array(r),H=np.array(H),meta=json.dumps(meta))

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',default='.');p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out);data=out/'traces';data.mkdir(parents=True,exist_ok=True);errors=[];expected=[];inv=[]
    for nu in [0.,.00025,.001,.004]:
        for N in [450,900,1800]:
            name=f'archive_nu{nu:.5f}_N{N}';expected.append(name)
            try:
                t,u,paths,seams=history(a.root,N,nu);meta=dict(nstar=7.2,N=N,nu_explicit=nu,origin='production HDF5',history='phase3/4/4B mixed dt' if nu==0 else 'phase6 fixed dt',max_seam=max(seams,default=0),tau_end=float(t[-1]))
                x=from_history(t,u,N,nu,7.2,meta);np.savez_compressed(data/(name+'.npz'),**x)
                inv.append(dict(case=name,**meta,snapshots=len(t),max_output_gap=float(np.max(np.diff(t))),files=';'.join(map(str,paths))))
            except Exception as exc:errors.append(dict(case=name,error=repr(exc)))
    write_csv(out/'inventory.csv',inv);write_csv(out/'errors.csv',errors);summarize(list(data.glob('*.npz')),out/'summary',expected)
    (out/'status.json').write_text(json.dumps(dict(expected=len(expected),complete=len(inv),errors=errors),indent=2)+'\n')
    print('FASE9B_ARCHIVE',len(inv),len(expected),errors,flush=True)
if __name__=='__main__':main()
