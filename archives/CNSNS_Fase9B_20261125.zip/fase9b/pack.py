"""Pack results and summaries, not bulk HDF5/full-step new traces."""
import argparse,zipfile,json
from pathlib import Path

def main():
    a=argparse.ArgumentParser();a.add_argument('--out',default='fase9b/Fase9B_CNSNS_resultados_20261125.zip');p=a.parse_args();root=Path('fase9b');dest=Path(p.out)
    if dest.exists():raise FileExistsError(dest)
    with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for base in [root/'results/archive',root/'results/report',root/'logs',root/'jobs']:
            if not base.exists():continue
            for f in sorted(base.rglob('*')):
                if f.is_file() and not (base.name=='report' and 'traces' in f.relative_to(base).parts):z.write(f,f.relative_to(root))
        for f in sorted((root/'results/new').glob('*/seg*.audit.json')):z.write(f,f.relative_to(root))
        for f in [root/'pade_cases.csv',root/'README.md']:z.write(f,f.name)
    with zipfile.ZipFile(dest) as z:assert z.testzip() is None
    print('FASE9B_PAQUETE_OK',dest,flush=True)
if __name__=='__main__':main()
