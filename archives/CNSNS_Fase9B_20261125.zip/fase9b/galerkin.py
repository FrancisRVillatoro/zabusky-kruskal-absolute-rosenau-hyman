"""Independent odd-mode Galerkin controls; finite trapezoidal flux quadrature."""
import argparse,csv,json,time
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from .modal import crossing,symbols,diagnostics,P

def solve(nstar,cutoff,quad,rtol,tau_end=4.25,probe='none',sample=3200):
    n=np.arange(1,cutoff+1,2); T=crossing(nstar); d,q=symbols(n,nstar)
    if probe!='none':
        mode,fac=probe.split(':'); d[n==int(mode)]*=float(fac)
    v=np.zeros(quad//2+1,complex)
    def flux(c):
        v[n]=c
        u=np.fft.irfft(v,n=quad,norm='forward')
        return np.fft.rfft(np.abs(u)**(P-1)*u,norm='forward')[n]
    def rhs(t,c):return -1j*T*d*flux(c)
    c0=np.zeros(len(n),complex);c0[0]=.5
    t=np.arange(round(tau_end*sample)+1)/sample
    start=time.perf_counter()
    sol=solve_ivp(rhs,(0,tau_end),c0,method='DOP853',rtol=rtol,atol=rtol*.005,t_eval=t)
    if not sol.success or len(sol.t)!=len(t):raise RuntimeError(sol.message)
    c=sol.y.T.copy(); b=np.stack([flux(x) for x in c]);
    v2=np.zeros((81,quad//2+1),complex);v2[:,n]=c[np.linspace(0,len(t)-1,81,dtype=int)]
    u=np.fft.irfft(v2,n=quad,norm='forward',axis=1)
    I=np.mean(abs(u)**(P+1),axis=1)
    D,r,H=diagnostics(c)
    return dict(tau=t,c=c,b=b,n=n,d=d,q4=q,T=T,nu=0.,D=D,r=r,H=H,meta=json.dumps(dict(nstar=nstar,cutoff=cutoff,quad=quad,rtol=rtol,probe=probe,nfev=sol.nfev,rel_I_drift=float(np.max(abs(I/I[0]-1))),seconds=time.perf_counter()-start)))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--case',required=True);ap.add_argument('--out',default='fase9b/results_local/galerkin');ap.add_argument('--manifest',default='fase9b/galerkin_cases.csv');a=ap.parse_args()
    with open(a.manifest) as f:r=next(r for r in csv.DictReader(f) if r['case']==a.case)
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True);path=out/(a.case+'.npz')
    if path.exists():raise FileExistsError(path)
    x=solve(float(r['nstar']),int(r['cutoff']),int(r['quad']),float(r['rtol']),float(r['tau_end']),r['probe'])
    np.savez_compressed(path,**x);print('GALERKIN_OK',a.case,x['meta'],flush=True)
if __name__=='__main__':main()
