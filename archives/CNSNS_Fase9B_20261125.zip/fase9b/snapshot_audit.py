"""Independent Fourier analysis of all-node snapshots exported from Picasso in 9A."""
import argparse,zipfile,csv
from pathlib import Path
import numpy as np
from .modal import coeffs,symbols,crossing,powers,rates
from .analyze import write_csv

def run(src,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(src) as z:
        for selection in ('minima','common_times'):
            rows={}
            with z.open(selection+'/profiles.csv') as f:
                import io
                for r in csv.DictReader(io.TextIOWrapper(f)):
                    key=(int(r['j']),int(r['N']),float(r['nu']),int(r['divisor']),float(r['tau']),r['source'])
                    rows.setdefault(key,[]).append((int(r['index']),float(r['x']),float(r['u']),float(r['aligned_initial']),float(r['residual'])))
            loc=[];flux=[]
            for (j,N,nu,div,tau,source),rr in sorted(rows.items()):
                a=np.array(sorted(rr));assert len(a)==N and np.all(a[:,0]==np.arange(N))
                x,u,ref,res=a[:,1:].T;assert np.max(abs(u-ref-res))<1e-12
                L=2*np.pi*7.2;assert np.allclose(x,np.arange(N)*L/N,rtol=1e-11,atol=1e-11)
                c,b=coeffs(u);modes=np.array([1,3,5,7,9,11,13,15,21]);d,q=symbols(modes,7.2,N);T=crossing(7.2)
                tr,dis=rates(c[modes],b[modes],d,q,T,nu);e=powers(c[modes]);h=4*np.sum(abs(c[2:-1])**2)+2*abs(c[-1])**2
                base=dict(j=j,N=N,nu=nu,divisor=div,tau=tau,source=source)
                for k,n in enumerate(modes):flux.append(dict(**base,n=n,e=e[k],H=h,share=e[k]/h if n>1 and h>0 else '',flux_abs=abs(b[n]),phase_flux=np.angle(np.conj(c[n])*b[n]),transfer_tau=tr[k],dissipation_tau=dis[k],d=d[k]))
                # Periodic distance to linear-interpolated numerical zeros.
                xp=np.r_[x,L];up=np.r_[u,u[0]];cross=np.flatnonzero(up[:-1]*up[1:]<0)
                roots=np.r_[x[u==0],xp[cross]-up[cross]*(xp[cross+1]-xp[cross])/(up[cross+1]-up[cross])];
                dist=np.min(abs((x[:,None]-roots+L/2)%L-L/2),axis=1) if len(roots) else np.full(N,np.inf)
                for kind,levels,mask_values in [('amplitude',[.05,.1,.2,.3],abs(u)),('radius',[.1,.2,.4,.8],dist)]:
                    for level in levels:
                        mask=mask_values<=level
                        near=np.fft.rfft(res*mask,norm='forward');far=np.fft.rfft(res*~mask,norm='forward')
                        for n in [3,5,7,9]:
                            A=near[n];B=far[n];total=4*abs(A+B)**2
                            loc.append(dict(**base,mask=kind,level=level,n=n,mask_fraction=mask.mean(),near_power=4*abs(A)**2,far_power=4*abs(B)**2,cross_power=8*np.real(np.conj(A)*B),total_power=total,near_signed_share=4*np.real(np.conj(A+B)*A)/total if total>1e-25 else '',far_signed_share=4*np.real(np.conj(A+B)*B)/total if total>1e-25 else ''))
            write_csv(out/f'{selection}_transfer.csv',flux);write_csv(out/f'{selection}_modal_localization.csv',loc)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--out',required=True);a=p.parse_args();run(a.source,a.out)
