"""Preserve full-trace SHA256 and small plotting traces; exact tables use full traces."""
import argparse,hashlib
from pathlib import Path
import numpy as np
from .analyze import catalog,free_catalog,write_csv

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',default='fase9b/results_local/galerkin');p.add_argument('--out',default='fase9b/results_local/plot_traces');a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True);rows=[]
    for path in sorted(Path(a.input).glob('*.npz')):
        with np.load(path,allow_pickle=False) as f:x={k:f[k] for k in f.files}
        h=hashlib.sha256(path.read_bytes()).hexdigest();idx=np.unique(np.r_[np.arange(0,len(x['tau']),16),len(x['tau'])-1,[i for _,i,_ in catalog(x) if i is not None],[i for i,_ in free_catalog(x)]]).astype(int)
        rows.append(dict(case=path.stem,sha256_full_trace=h,full_rows=len(x['tau']),plot_rows=len(idx)))
        for key in ['tau','c','b','D','r','H']:x[key]=x[key][idx]
        np.savez_compressed(out/path.name,**x)
    write_csv(out/'full_trace_inventory.csv',rows)
if __name__=='__main__':main()
