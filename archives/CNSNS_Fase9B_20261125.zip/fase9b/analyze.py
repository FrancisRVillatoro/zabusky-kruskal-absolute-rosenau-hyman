"""Report sampled minima, exact modal identities, net and gross power exchange.
No interpolation used to manufacture missing return events. Positive/negative
integrals use trapezoidal quadrature and are checked against endpoint changes.
"""
import argparse,csv,json
from pathlib import Path
import numpy as np
from scipy.signal import find_peaks
from .modal import powers,rates

MODES=(1,3,5,7,9,11,13,15,21)

def write_csv(p,rows):
    if not rows:return
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with open(p,'w',newline='') as f:w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)

def catalog(x):
    t=x['tau']; D=x['D']; out=[]
    # A common window around j, deliberately wider than central-case production.
    for j in range(1,5):
        ids=np.flatnonzero((t>=j-.20)&(t<=j+.20))
        if len(ids)<3 or t[ids[-1]]<j+.20-0.0013:out.append((j,None,0));continue
        cand=ids[find_peaks(-D[ids])[0]]
        out.append((j,int(cand[np.argmin(D[cand])]) if len(cand) else None,len(cand)))
    return out

def free_catalog(x):
    ids,props=find_peaks(-x['D'],prominence=.03)
    return [(int(i),float(prom)) for i,prom in zip(ids,props['prominences']) if x['tau'][i]>=.2]

def budgets(x,i0,i1):
    t=x['tau'][i0:i1+1];c=x['c'][i0:i1+1];b=x['b'][i0:i1+1];e=powers(c)
    tr,di=rates(c,b,x['d'],x['q4'],float(x['T']),float(x['nu']))
    idx=np.unique(np.r_[np.arange(0,len(t),2),len(t)-1]);
    net=np.trapezoid(tr,t,axis=0); dis=np.trapezoid(di,t,axis=0)
    gain=np.trapezoid(np.maximum(tr,0),t,axis=0); loss=np.trapezoid(np.maximum(-tr,0),t,axis=0)
    coarse=np.trapezoid((tr+di)[idx],t[idx],axis=0)
    delta=e[-1]-e[0]; residual=delta-net-dis
    phase=np.angle(np.conj(c)*b)
    return dict(delta=delta,net=net,dissipation=dis,gross_gain=gain,gross_loss=loss,
        defect=residual,quadrature_change=net+dis-coarse,
        flux_L1=np.trapezoid(abs(b),t,axis=0),
        abs_phase_factor_integral=np.trapezoid(abs(c)*abs(b),t,axis=0),
        amplitude_mean=np.trapezoid(abs(c),t,axis=0)/(t[-1]-t[0]))

def summarize(files,out,expected=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    ev=[];bd=[];free=[];stats=[];ph=[]
    for path in sorted(files):
        with np.load(path,allow_pickle=False) as f:x={k:f[k] for k in f.files}
        t=x['tau'];D=x['D'];H=x['H'];c=x['c'];n=x['n'];e=powers(c)
        name=path.stem;meta=json.loads(str(x['meta']));base=dict(meta);base['case']=name
        if len(t)<2 or np.any(np.diff(t)<=0) or not np.all(np.isfinite(c)):raise ValueError(path)
        avg=np.trapezoid(e,t,axis=0)/(t[-1]-t[0]); maxe=np.max(e,axis=0)
        for m in MODES:
            k=np.flatnonzero(n==m)
            if len(k):
                k=k.item();bound=float(x['T'])*abs(x['d'][k])*np.concatenate(([0.],np.cumsum(np.diff(t)*(abs(x['b'][:-1,k])+abs(x['b'][1:,k]))/2)))
                stats.append(dict(**base,n=m,multiplier=x['d'][k],mean_e=avg[k],max_e=maxe[k],final_e=e[-1,k],max_abs_a=float(np.max(abs(c[:,k]))),max_amp_bound_violation_sampled=float(np.max(abs(c[:,k]-c[0,k])-bound)) if float(x['nu'])==0 else ''))
        prev=0;previous_j=0
        for j,i,nn in catalog(x):
            row=dict(**base,j=j,n_min=nn,tau='',D='',r='',H='',e5_over_H='',dominant_among_stored_odds='')
            if i is not None:
                row.update(tau=t[i],D=D[i],r=x['r'][i],H=H[i],dominant_among_stored_odds=int(n[1+np.argmax(e[i,1:])]))
                for m in MODES:
                    pos=np.flatnonzero(n==m)
                    if len(pos):row[f'e{m}']=e[i,pos.item()];row[f'e{m}_over_H']=e[i,pos.item()]/H[i] if m>1 and H[i]>0 else ''
                if i>prev and previous_j==j-1:
                    b=budgets(x,prev,i)
                    for k,m in enumerate(n):
                        if m not in MODES:continue
                        q=dict(**base,selection='integer_window',j=j,n=int(m),start_tau=t[prev],end_tau=t[i],e_start=e[prev,k],e_end=e[i,k],multiplier=x['d'][k],nu=float(x['nu']))
                        q.update({key:val[k] for key,val in b.items()});bd.append(q)
                prev=i;previous_j=j
            ev.append(row)
        # No assumption of return spacing: list all prominent minima separately.
        prev_free=0
        for j,(i,prom) in enumerate(free_catalog(x),1):
            row=dict(**base,j=j,tau=t[i],D=D[i],prominence=prom,H=H[i],r=x['r'][i],dominant_among_stored_odds=int(n[1+np.argmax(e[i,1:])]))
            for m in MODES:
                pos=np.flatnonzero(n==m)
                if len(pos):row[f'e{m}']=e[i,pos.item()];row[f'e{m}_over_H']=e[i,pos.item()]/H[i] if m>1 and H[i]>0 else ''
            free.append(row)
            b=budgets(x,prev_free,i)
            for k,m in enumerate(n):
                if m not in MODES:continue
                q=dict(**base,selection='prominent_chronological',j=j,n=int(m),start_tau=t[prev_free],end_tau=t[i],e_start=e[prev_free,k],e_end=e[i,k],multiplier=x['d'][k],nu=float(x['nu']))
                q.update({key:val[k] for key,val in b.items()});bd.append(q)
            prev_free=i
        # Phase-coherence comparison on normalized excursion times, robust at vanishing mode amplitude.
        events=[(j,i) for j,i,_ in catalog(x) if i is not None]
        pts=[(0,0)]+events
        last=None;zgrid=np.linspace(0,1,401)
        fund=c[:,0];rot=np.ones(len(fund),complex);good=abs(fund)>1e-10;rot[good]=np.conj(fund[good])/abs(fund[good]); aligned=2*c*rot[:,None]**n[None,:]
        aligned[~good]=np.nan
        for (ja,a),(jb,b) in zip(pts[:-1],pts[1:]):
            if jb!=ja+1 or not np.all(good[a:b+1]):last=None;continue
            z=(t[a:b+1]-t[a])/(t[b]-t[a]);cur=np.stack([np.interp(zgrid,z,w.real)+1j*np.interp(zgrid,z,w.imag) for w in aligned[a:b+1].T],axis=1)
            if last is not None:
                radial=np.trapezoid((abs(cur)-abs(last))**2,zgrid,axis=0); full=np.trapezoid(abs(cur-last)**2,zgrid,axis=0)
                for k,m in enumerate(n):
                    if m in [3,5,7,9,11]:ph.append(dict(**base,j=jb,n=int(m),rms_complex_change=np.sqrt(full[k]),radial_part=radial[k],angular_part=max(0.,full[k]-radial[k]),angular_share=max(0.,full[k]-radial[k])/full[k] if full[k]>0 else 0.))
            last=cur
    for name,rows in [('events',ev),('exchange',bd),('free_events',free),('mode_statistics',stats),('phase_coherence',ph)]:write_csv(out/(name+'.csv'),rows)
    got={p.stem for p in files};missing=sorted(set(expected or [])-got)
    (out/'status.json').write_text(json.dumps(dict(completed=len(got),missing=missing,events=len(ev),exchange_rows=len(bd)),indent=2)+'\n')
    return ev

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',default='fase9b/results_local/galerkin');ap.add_argument('--out',default='fase9b/results_local/summary');ap.add_argument('--manifest');a=ap.parse_args()
    expected=None
    if a.manifest:
        with open(a.manifest) as f:expected=[r['case'] for r in csv.DictReader(f)]
    summarize(list(Path(a.input).glob('*.npz')),a.out,expected)
if __name__=='__main__':main()
