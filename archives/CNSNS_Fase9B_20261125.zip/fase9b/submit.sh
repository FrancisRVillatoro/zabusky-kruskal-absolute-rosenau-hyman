#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
sha256sum -c MANIFEST_FASE9B.sha256
mkdir -p fase9b/{logs,jobs,results/new}
if compgen -G 'fase9b/jobs/*JOBID.txt' >/dev/null; then echo 'Existen JOBID de una campaña previa; no duplicar.' >&2; exit 1; fi
for f in fase9b/slurm/*.slurm; do bash -n "$f"; done
submit(){ local label=$1 raw job; shift; raw=$(sbatch "$@"); printf '%s\n' "$raw" >&2; job=$(printf '%s\n' "$raw" | sed -E $'s/\x1B\\[[0-9;]*[[:alpha:]]//g' | sed -nE 's/^.*Submitted batch job ([0-9]+).*$/\1/p' | tail -1); [[ $job =~ ^[0-9]+$ ]] || { echo 'No se pudo extraer JOBID' >&2; return 1; }; printf '%s\n' "$job" > "fase9b/jobs/${label}_JOBID.txt"; printf '%s' "$job"; }
v=$(submit VERIFY fase9b/slurm/verify.slurm)
a=$(submit ARCHIVE --dependency=afterany:$v fase9b/slurm/archive.slurm)
m=$(submit MAIN --dependency=afterok:$v --kill-on-invalid-dep=yes fase9b/slurm/main.slurm)
r=$(submit REPORT --dependency=afterany:$a:$m fase9b/slurm/report.slurm)
printf 'FASE9B_LANZADA verify=%s archive=%s main=%s report=%s\n' "$v" "$a" "$m" "$r"
squeue -l
