"""Aggregate new runs and preserve failed/partial outcomes. No source writes."""
import argparse,csv,json,zipfile
from pathlib import Path
import numpy as np
import h5py
from .analyze import summarize,write_csv,catalog,free_catalog
from .pade_run import metadata,SEGMENTS
from .archive import seam,file_data
from .modal import crossing

def combine(folder,row):
    parts=[];audits=[];m=metadata(row);fields=[]
    for seg,(a,b) in enumerate(SEGMENTS,1):
        trace=folder/f'seg{seg}.npz';audit=folder/f'seg{seg}.audit.json';hfile=folder/f'seg{seg}.h5'
        if not trace.exists() or not audit.exists() or not hfile.exists():break
        au=json.loads(audit.read_text());assert au['meta']==m and au['start']==a and au['end']==b
        with np.load(trace,allow_pickle=False) as f:x={k:f[k] for k in f.files}
        assert json.loads(str(x['meta']))==m and x['tau'][0]==a
        assert au['accepted']==len(x['tau'])-1 and au['max_residual']<=1+1e-10
        if parts:
            assert abs(parts[-1]['tau'][-1]-x['tau'][0])<1e-12
            assert np.max(abs(parts[-1]['c'][-1]-x['c'][0]))<1e-12
        parts.append(x);audits.append(au)
        if au['status']!='COMPLETED':break
        assert abs(x['tau'][-1]-b)<1e-12
        fields.append(file_data(hfile,m['N'],m['nu_explicit'],m['nstar']))
    if not parts:return None,audits,None
    x=parts[0].copy()
    for key in ['tau','c','b','D','r','H']:x[key]=np.concatenate([p[key][int(i>0):] for i,p in enumerate(parts)],axis=0)
    field=None
    if fields:
        t,u=fields[0]
        for s,v in fields[1:]:t,u,_=seam(t,u,s,v)
        field=(t,u)
    return x,audits,field

def compare(t,u,s,v,n1,n2):
    # Fields at common stored times, without phase fitting or interpolation.
    assert n2%n1==0
    keys={round(float(a),11):i for i,a in enumerate(s)};pairs=[(i,keys[round(float(a),11)]) for i,a in enumerate(t) if round(float(a),11) in keys]
    if not pairs:return np.array([]),np.array([])
    i,j=np.array(pairs).T;return t[i],np.sqrt(2*np.mean((u[i]-v[j,::n2//n1])**2,axis=1))

def report(root,out,manifest):
    root=Path(root);out=Path(out);out.mkdir(parents=True,exist_ok=True);traces=out/'traces';traces.mkdir(exist_ok=True);rows=list(csv.DictReader(open(manifest)));inv=[];fields={};data={};issues=[]
    for row in rows:
        name=row['case']
        try:
            x,au,field=combine(root/name,row)
            if x is None:inv.append(dict(case=name,status='MISSING',tau_end=0));continue
            complete=len(au)==4 and all(a['status']=='COMPLETED' for a in au)
            inv.append(dict(case=name,status='COMPLETE' if complete else 'PARTIAL',tau_end=x['tau'][-1],segments=len(au),accepted=sum(a['accepted'] for a in au),max_residual=max(a['max_residual'] for a in au),failure=au[-1]['failure']))
            if len(x['tau'])>=2:np.savez_compressed(traces/(name+'.npz'),**x);data[name]=x
            if field is not None:fields[name]=field
        except Exception as exc:issues.append(dict(case=name,error=repr(exc)));inv.append(dict(case=name,status='AUDIT_FAILED',tau_end=''))
    write_csv(out/'inventory.csv',inv);write_csv(out/'issues.csv',issues);summarize(list(traces.glob('*.npz')),out/'summary',[r['case'] for r in rows])
    cmp=[];events=[];byname={r['case']:r for r in rows}
    for s in [6.8,7.,7.2,7.4]:
        for kind,a,b in [('space',f's{s:.1f}_N900_d2',f's{s:.1f}_N1800_d2'),('time',f's{s:.1f}_N1800_d2',f's{s:.1f}_N1800_d4')]:
            if a not in data or b not in data:continue
            xa,xb=data[a],data[b]
            for (j,ia,_),(_,ib,_) in zip(catalog(xa),catalog(xb)):
                if ia is not None and ib is not None:
                    events.append(dict(nstar=s,comparison=kind,selection='integer_window',j=j,case1=a,case2=b,abs_delta_D=abs(xa['D'][ia]-xb['D'][ib]),abs_delta_tau=abs(xa['tau'][ia]-xb['tau'][ib])))
            fa,fb=free_catalog(xa),free_catalog(xb)
            matched=[]
            for j,((ia,_),(ib,_)) in enumerate(zip(fa,fb),1):
                if abs(xa['tau'][ia]-xb['tau'][ib])>.15:continue
                events.append(dict(nstar=s,comparison=kind,selection='prominent_chronological',j=j,case1=a,case2=b,abs_delta_D=abs(xa['D'][ia]-xb['D'][ib]),abs_delta_tau=abs(xa['tau'][ia]-xb['tau'][ib])))
                matched.append((j,float(xb['tau'][ib])))
            if a not in fields or b not in fields:continue
            ta,ua=fields[a];tb,ub=fields[b];t,err=compare(ta,ua,tb,ub,int(byname[a]['N']),int(byname[b]['N']))
            for selection,j,center,radius in [("integer_window",j,float(j),.2) for j in range(1,5)]+[("prominent_chronological",j,center,.1) for j,center in matched]:
                w=(t>=center-radius)&(t<=center+radius)
                if w.any():cmp.append(dict(nstar=s,comparison=kind,selection=selection,j=j,center=center,radius=radius,case1=a,case2=b,max_L2=float(err[w].max()),rms_L2=float(np.sqrt(np.mean(err[w]**2))),coverage_start=float(t[w][0]),coverage_end=float(t[w][-1]),samples=int(w.sum())))
    write_csv(out/'field_budget.csv',cmp);write_csv(out/'return_differences.csv',events)
    status=dict(expected=len(rows),complete=sum(x['status']=='COMPLETE' for x in inv),inventory=inv,errors=issues)
    (out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print('FASE9B_REPORT',status['complete'],status['expected'],flush=True)
    # Condensed trace for plotting. Full endpoint traces stay on Picasso.
    small=out/'plot_traces';small.mkdir(exist_ok=True)
    for name,x in data.items():
        idx=np.unique(np.r_[np.arange(0,len(x['tau']),max(1,int(byname[name]['dt_divisor'])*8)),len(x['tau'])-1,[i for _,i,_ in catalog(x) if i is not None],[i for i,_ in free_catalog(x)]]).astype(int)
        y=x.copy()
        for key in ['tau','c','b','D','r','H']:y[key]=x[key][idx]
        np.savez_compressed(small/(name+'.npz'),**y)
    return status

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',default='fase9b/results/new');p.add_argument('--out',required=True);p.add_argument('--manifest',default='fase9b/pade_cases.csv');a=p.parse_args();report(a.root,a.out,a.manifest)
if __name__=='__main__':main()
