"""Plots directly from summary CSVs and condensed traces (no generated images)."""
from pathlib import Path
import argparse,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def read(p):return list(csv.DictReader(open(p)))
def select(rows,**kw):return [r for r in rows if all(r[k]==str(v) for k,v in kw.items())]
def main():
    p=argparse.ArgumentParser();p.add_argument('--root',default='fase9b/results_local');a=p.parse_args();root=Path(a.root);out=root/'figures';out.mkdir(exist_ok=True)
    ev=read(root/'summary/events.csv');free=read(root/'summary/free_events.csv');bd=read(root/'summary/exchange.csv');near=read(root/'summary/near_null.csv')
    fig,ax=plt.subplots(figsize=(7,4.3))
    for k in [7,11,21,35,51]:
        rr=select(ev,case=f'central_K{k}');ax.plot([int(r['j']) for r in rr],[float(r['D']) for r in rr],'-o',label=f'Galerkin n≤{k}')
    ax.plot([1,2,3,4],[.046030569,.077838723,.127966133,.237769165],'k--s',label='Padé–Radau N=1800');ax.set(xlabel='Return index',ylabel='Sampled recurrence distance',xticks=[1,2,3,4]);ax.legend(fontsize=8,ncol=2);ax.grid(alpha=.2);fig.tight_layout();fig.savefig(out/'cutoff_ladder.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4.3))
    for label,case in [('Unmodified','central_K35'),('m7 = 0','central_K35_freeze7'),('m7 × 4','central_K35_boost7'),('m5 = 0','central_K35_freeze5')]:
        with np.load(root/'plot_traces'/f'{case}.npz') as z:ax.plot(z['tau'],z['D'],label=label,lw=1.3)
    ax.set(xlabel='Normalized time τ',ylabel='Recurrence distance');ax.legend(fontsize=8,ncol=2);ax.grid(alpha=.2);fig.tight_layout();fig.savefig(out/'interventions.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.5,4.2))
    for s in [6.8,7.,7.2,7.4]:
        case='central_K35' if s==7.2 else f'L{s:.1f}_K35';rr=select(free,case=case);ax.plot([float(r['tau']) for r in rr],[float(r['D']) for r in rr],'-o',label=f'L/(2π)={s:g}')
    ax.set(xlabel='Normalized time of prominent minimum',ylabel='Recurrence distance');ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(out/'length_detuning.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.5,4.2));s=np.array([float(r['nstar']) for r in near]);y=np.array([float(r['mean_e7_over_m7_squared']) for r in near]);pred=float(near[0]['predicted_mean']);ax.plot(s,y,'o-',label='Computed ratio');ax.axhline(pred,ls='--',color='k',label='Null-trajectory prediction');ax.set(xlabel='L/(2π)',ylabel='Time mean of e7 / m7²');ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(out/'quadratic_null_law.png',dpi=180);plt.close(fig)
    rr=select(bd,case='central_K51',n=5,selection='integer_window');j=np.array([int(r['j']) for r in rr]);gain=np.array([float(r['gross_gain']) for r in rr]);loss=np.array([float(r['gross_loss']) for r in rr]);delta=np.array([float(r['delta']) for r in rr]);
    fig,ax=plt.subplots(figsize=(6.5,4.2));ax.bar(j-.17,gain,.34,label='Integrated positive rate');ax.bar(j+.17,loss,.34,label='Integrated negative rate (magnitude)');ax.plot(j,delta,'ko--',label='Net change of e5');ax.set(xlabel='Excursion ending at return j',ylabel='Normalized modal power',xticks=j);ax.legend(fontsize=8);ax.grid(axis='y',alpha=.2);fig.tight_layout();fig.savefig(out/'fifth_exchange.png',dpi=180);plt.close(fig)
    rows=read(root/'snapshot_audit/minima_modal_localization.csv');fig,ax=plt.subplots(figsize=(6.5,4.2))
    for mask,level in [('amplitude',.2),('radius',.4)]:
        rr=[r for r in rows if r['N']=='1800' and float(r['nu'])==0 and r['n']=='5' and r['mask']==mask and float(r['level'])==level and (r['j']!='4' or r['divisor']=='4')];rr.sort(key=lambda r:int(r['j']));ax.plot([int(r['j']) for r in rr],[100*float(r['far_signed_share']) for r in rr],'-o',label='|u|>0.2' if mask=='amplitude' else 'Distance from zeros >0.4')
    ax.set(xlabel='Return index',ylabel='Signed far-field share of fifth-mode power (%)',xticks=[1,2,3,4]);ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(out/'fifth_spatial_localization.png',dpi=180);plt.close(fig)
if __name__=='__main__':main()
