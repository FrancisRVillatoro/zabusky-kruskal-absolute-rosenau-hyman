# Fase 9B — resultados locales y campaña de contraste

## Estado

39/39 integraciones Galerkin completadas, 84 perfiles de producción auditados directamente (9A), 9/9 tests y prueba corta completa Radau con N=900/1800 y reinicios. No se han ejecutado los 14 nuevos trabajos de Picasso. No es todavía un cierre científico del mecanismo en el operador completo.

## 1. Resultados analíticos

El modo inicialmente vacío satisface la cota de excitación proporcional a |m_n| con m_n=k_n(1-k_n²). En el nulo exacto se congela. El nulo de Padé satisface nstar_h=n[1−(2πn/N)^4/480+O(N^−6)] y no coincide exactamente con nstar=n. Para n=7, los valores en N=900,1800 son 6.999999916816048 y 6.999999994801373. En nstar=7, los multiplicadores discretos son 2.3767e−8 y 1.4853e−9. En el límite de longitud hacia el nulo a corte fijo, la amplitud dividida por m_7 tiende a la integral del flujo de la trayectoria con m_7=0; por tanto la potencia es cuadrática en m_7 con coeficiente dependiente del tiempo. Véase la prueba LaTeX. La conservación modal exacta en el nulo no es una afirmación de novedad bibliográfica: está relacionada con las conocidas leyes integrales ponderadas por seno/coseno; la aportación aquí es el control explícito de detuning para la discretización y el caso estudiado.

## 2. Galerkin y detuning

Corte 51: D=(0.046253,0.081921,0.133351,0.248494), tau=(1.012188,2.023125,3.028125,4.035000), fracciones e5/H=(0.060976,0.228100,0.621412,0.910843). Padé N=1800: D=(0.046031,0.077839,0.127966,0.237769), con historia temporal mixta documentada. Corte 7: (0.105664,0.298227,0.369117,0.099324). Cortes sucesivos no prueban convergencia. La duplicación de cuadratura a corte 43 cambia D(tau) a lo sumo 1.16e−5 y campo normalizado 2.24e−4 en toda la serie muestreada; a corte 21, endurecer tolerancia de 1e−9 a 1e−11 a cuadratura 1024 cambia D a lo sumo 8.6e−9 y campo 1.06e−7. La deriva máxima relativa del funcional (81 muestras por caso) entre los 39 casos es inferior a 2e−6. No se estudia uniformidad al aumentar corte.

La prueba a corte 21 del coeficiente de potencia media <e7>/m7² predice 0.0831362409 usando solo el flujo del caso nstar=7. Para nstar=6.999 y 7.001 se obtiene 0.0829786233 y 0.0832972798 (desviación ~0.2%). Los errores RMS relativos en la amplitud compleja reescalada son 2.37% y 2.37%, frente a 23–24% para ±0.01. Es una ley de detuning a tiempo finito y corte fijo, no una afirmación sobre el límite continuo.

El barrido geométrico a corte 35 da los cuatro mínimos prominentes de la tabla siguiente (no confundir con j±0.2):

| nstar | D1 | D2 | D3 | D4 | tau4 |
|---|---:|---:|---:|---:|---:|
|6.8|.03910|.09021|.21602|.35542|3.59781|
|7|.03972|.08346|.16309|.36139|3.87688|
|7.2|.04907|.08202|.12901|.26393|4.02188|
|7.4|.04758|.09033|.11596|.17959|4.19125|

La tendencia de D4 al alejarse hacia nstar>7 es sugerente pero no es un mínimo universal ni una curva convergida. El cuarto mínimo de nstar=6.8 no cae en la ventana j±0.2; el mínimo de esa ventana D≈0.98 no es la cuarta recurrencia prominente. Los resultados del corte 21 y 35 difieren de manera significativa en algunas longitudes. Por ejemplo, D4 para nstar=7.4 pasa de .12925 a .17959. Se requiere contraste completo.

## 3. Intervenciones y balance

Con geometría fija nstar=7.2 y corte 35, D4=.26393 (original), .44349 (m7=0) y .12023 (4m7); el mismo efecto aparece a corte 21 (.26244, .43099, .08660). Congelar m5 produce tres retornos prominentes de distancias .00967,.00681,.00894, con periodo ≈1.148. Estas son EDO modificadas que preservan la estructura antisimétrica pero no son soluciones de la PDE; no demuestran una transferencia directa 7→5. El cambio de periodo y de amplitud de otros modos impide interpretar los experimentos como simple eliminación de un término de la distancia.

En corte 51, el quinto modo tiene ganancias/pérdidas integradas por excursión:

| j | ganancia | pérdida | diferencia e5 | e5 final |
|---|---:|---:|---:|---:|
|1|.538204|.538073|.000130|.000130|
|2|.543687|.542287|.001400|.001531|
|3|.558976|.549500|.009476|.011007|
|4|.559164|.516407|.042758|.053765|

Defecto de balance absoluto para e5 <8e−8. Cambio al decimar cuadratura <4.4e−6. Las grandes ganancias son comparables, pero las pérdidas no las compensan tan bien: el residuo representa una cancelación progresivamente incompleta. No hay conservación global de las potencias cuadráticas; esta es una contabilidad del modo, no una transferencia triádica conservativa. Los datos originales N=1800 dan e5=(.000151,.001471,.010376,.049092), con tasa instantánea negativa en cada mínimo: −.010525,−.029521,−.039295,−.209574 por unidad tau. Se requiere integrar las tasas desde los HDF5 de producción para comprobar la interpretación fuera del Galerkin. Los datos de 9A contienen solo perfiles de evento y tiempos comunes, no historias completas.

En el corte 51, la comparación entre excursiones reparametrizadas en [0,1], en coordenadas invariantes por traslación z_n=2a_n exp(−in arg a_1), da para n=5 fracciones angulares del cambio cuadrático de 88.55%,70.79%,77.67% para los retornos 2,3,4. No prueba que el cambio angular sea la causa de la acumulación; los dos efectos están acoplados y el alineamiento presupone fundamental no nulo.

## 4. Vínculo con 9A

En los cuatro perfiles originales N=1800, se descompone el coeficiente del residuo de la onda respecto al coseno alineado en a5=A_near+A_far (DFT de la máscara). Definimos C_far=Re(conj(a5) A_far)/|a5|², una contribución firmada que asigna por mitades la interferencia; no es una energía espacial positiva. Para la región |u|>.2, C_far crece de 36.43% a 79.67%,89.56%,97.89%. Para distancia física a ceros >0.4, crece de 62.31% a 86.89%,95.27%,98.48%. Máscaras nodales sobre campos completos exportados, no una partición ortogonal ni una afirmación de causalidad. Esta prueba conecta la redistribución espacial observada en 9A con la deformación global en el quinto modo.

## 5. Pendiente y criterio editorial

14 nuevas trayectorias de Padé para cuatro longitudes, dos N, refinamiento temporal global (desde 0) y dos nulos discretos; 12 historias previas auditadas sin reintegrar. Se analizarán los mínimos, tasas de potencia, integrales, defectos, magnitudes del modo 7, discrepancias en el campo y sensibilidad temporal. La conclusión defendible antes de dichos datos es que el deterioro y la supresión modal se reproducen en varios modelos de Galerkin, que intervenir sobre m7 modifica sustancialmente el deterioro y que el residuo global está dominado por e5 en las trayectorias de producción. No se ha demostrado una resonancia, un periodo teórico de retorno, transferencia exclusiva 7→5 ni convergencia de la PDE. No interpretar una mejor recurrencia tras alterar m7 como una mejora de la ecuación original. La auditoría de prioridad de 9B frente a toda la bibliografía queda pendiente.
