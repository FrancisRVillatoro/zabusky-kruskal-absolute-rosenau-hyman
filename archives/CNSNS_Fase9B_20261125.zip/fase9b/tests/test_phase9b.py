import unittest,tempfile,csv,json
from pathlib import Path
import numpy as np
from fase9b.modal import symbols,crossing,pade_nstar_zero,coeffs,rates,from_field
from fase9b.analyze import budgets,catalog,summarize
from fase9b.galerkin import solve
from fase9b.pade_run import run_segment,make_solvers,metadata
from fase9b.archive import seam,from_history,file_data
from absk_radau.model import PeriodicAbsK,make_initial_data

class Tests(unittest.TestCase):
    def test_discrete_symbols(self):
        N=128;s=7.2;model=PeriodicAbsK(N,2*np.pi*s,2.25,.001)
        u=np.cos(2*np.pi*model.x/model.L)+.2*np.sin(7*2*np.pi*model.x/model.L)
        a,b=coeffs(u);n=np.arange(1,N//2);d,q=symbols(n,s,N)
        actual=np.fft.rfft(model.velocity(u),norm='forward')[n]
        expected=-1j*d*b[n]-.001*q*a[n]
        np.testing.assert_allclose(actual,expected,atol=5e-12,rtol=1e-10)
    def test_null(self):
        for N in (128,450,900,1800):
            s=pade_nstar_zero(N);self.assertLess(abs(symbols(7,s,N)[0]),1e-13)
            self.assertGreater(symbols(7,7,N)[0],0.)
    def test_power_rate(self):
        N=128;s=7.2;m=PeriodicAbsK(N,2*np.pi*s,2.25,.001);u=make_initial_data(m,'Z')+.07*np.sin(5*2*np.pi*m.x/m.L)
        a,b=coeffs(u);n=np.arange(1,15);d,q=symbols(n,s,N);tr,di=rates(a[n],b[n],d,q,crossing(s),m.nu)
        v=np.fft.rfft(m.velocity(u),norm='forward')[n]
        np.testing.assert_allclose(tr+di,8*crossing(s)*np.real(np.conj(a[n])*v),atol=1e-12)
    def test_diagnostic(self):
        theta=np.arange(128)*2*np.pi/128;u=.9*np.cos(theta+.2)+.3*np.cos(5*theta)+.05
        D,r,H=from_field(u);self.assertAlmostEqual(D**2,.1**2+.3**2+2*.05**2,places=13)
        self.assertAlmostEqual(H,.09,places=13)
    def test_galerkin_null(self):
        x=solve(7.,9,256,1e-10,.025,sample=3200);i=np.flatnonzero(x['n']==7).item()
        self.assertEqual(float(np.max(abs(x['c'][:,i]))),0.)
    def test_galerkin_balance(self):
        x=solve(7.2,9,256,1e-10,.05,sample=3200);b=budgets(x,0,len(x['tau'])-1)
        self.assertLess(float(np.max(abs(b['defect']))),1e-5)
    def test_seams(self):
        t=np.array([0.,1.]);u=np.array([[1.,0.],[2.,0.]])
        s=np.array([1.,2.]);v=np.array([[2.,0.],[3.,0.]])
        a,b,e=seam(t,u,s,v);self.assertEqual(e,0.);np.testing.assert_equal(a,[0,1,2]);self.assertEqual(len(b),3)
        with self.assertRaises(ValueError):seam(t,u,s,v+1)
    def test_radau_real_resume(self):
        row=dict(case='smoke',nstar=pade_nstar_zero(128),N=128,dt_divisor=2,nu=0.,kind='test');model=PeriodicAbsK(128,2*np.pi*float(row['nstar']),2.25)
        u=make_solvers(model)[0][1].project(make_initial_data(model,'Z'))
        with tempfile.TemporaryDirectory() as d:
            v=run_segment(row,d,1,0.,.00125,u,6400)
            w=run_segment(row,d,1,0.,.00125,u,6400);np.testing.assert_equal(v,w)
            run_segment(row,d,2,.00125,.0025,v,6400)
            t,x=file_data(Path(d)/'seg1.h5',128,0.,float(row['nstar']));self.assertAlmostEqual(t[-1],.00125)
            a=from_history(t,x,128,0.,float(row['nstar']),metadata(row));self.assertLess(np.max(abs(a['c'][:,3])),1e-11)
            with np.load(Path(d)/'seg1.npz') as tr:self.assertEqual(len(tr['tau']),9)
    def test_summary(self):
        x=solve(7.2,7,256,1e-9,.025,sample=3200)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a.npz';np.savez_compressed(p,**x);summarize([p],Path(d)/'report',['a','b'])
            s=json.loads((Path(d)/'report/status.json').read_text());self.assertEqual(s['missing'],['b'])

if __name__=='__main__':unittest.main()
