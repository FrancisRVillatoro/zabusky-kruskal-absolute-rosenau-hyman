"""Independent audit of the exported Phase 9C CSVs and segment JSONs.
Usage: python audit9c.py Fase9C_CNSNS_resultados_20261125.zip --out audit
No HDF5 or HPC runs required. This checks exported diagnostics, not tangent solves.
"""
import argparse, io, json, hashlib, zipfile
from pathlib import Path
import numpy as np
import pandas as pd


def main():
    pa=argparse.ArgumentParser();pa.add_argument('archive',type=Path);pa.add_argument('--out',type=Path,default=Path('audit'));a=pa.parse_args();o=a.out;o.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(a.archive) as z:
        assert z.testzip() is None
        def csv(name):return pd.read_csv(io.BytesIO(z.read(name)))
        ca=csv('campaign.csv');i=csv('report/inventory.csv');g=csv('report/gain_at_times.csv');t=csv('report/gain_traces.csv');r=csv('report/return_gains.csv');n=csv('report/nonlinear_comparisons.csv');c=csv('report/tangent_comparisons.csv');l=csv('report/tangent_localization.csv');re=csv('report/replay_9b.csv');sym=csv('report/paired_symmetry.csv');st=json.loads(z.read('report/status.json'))
        aud=[json.loads(z.read(x)) for x in z.namelist() if x.startswith('audits/') and x.endswith('.audit.json')]
        assert ca.case.is_unique and i.case.is_unique and set(ca.case)==set(i.case)
        assert len(ca)==42 and len(i)==42
        for row in i.itertuples():
            aa=sorted([v for v in aud if v['meta']['case']==row.case],key=lambda v:v['segment']);assert len(aa)==row.segments
            assert abs(aa[-1]['last_tau']-row.last_tau)<1e-12
            assert sum(v['accepted'] for v in aa)==row.accepted
            assert aa[0]['start']==0 and all(abs(b['start']-v['last_tau'])<1e-12 for v,b in zip(aa,aa[1:]))
            for v in aa:
                assert abs(v['accepted']-(v['last_tau']-v['start'])*row.K)<1e-6
                assert v['max_scaled_residual']<=1+1e-10 and v['max_tangent_backward_error']<=1e-10
            assert (row.status=='COMPLETED')==(aa[-1]['status']=='COMPLETED' and abs(row.last_tau-row.tau_end)<1e-12)
            if row.kind=='tangent':
                for k,probe in enumerate(['cos2','sin2','cos4','sin4','cos6','sin6','cos8','sin8','near_zeros','grid_probe']):
                    assert abs(getattr(row,'peak_log10_G_'+probe)-max(v['peak_log_gain'][k] for v in aa)/np.log(10))<1e-11
        assert i.status.value_counts().to_dict()=={'COMPLETED':41,'PARTIAL':1}
        assert (t.groupby('case').tau.apply(lambda x: (np.diff(x)>0).all())).all()
        assert np.allclose(t.groupby('case').tau.max().reindex(i.case),i.last_tau,rtol=0,atol=1e-12)
        assert not t.duplicated(['case','tau']).any()
        def join_trace(df):
            out=df.merge(t,on=['case','tau'],suffixes=('','_trace'),validate='one_to_one');assert len(out)==len(df);return out
        gj=join_trace(g);rj=join_trace(r);names=[col for col in g.columns if col.startswith('log10_G_')]
        trace_error=max(float(np.max(abs(x[col]-x[col+'_trace']))) for x in [gj,rj] for col in names)
        gamma_error=max(float(np.max(abs(g['gamma_tau_'+col[8:]]-np.log(10)*g[col]/g.tau))) for col in names if col!='log10_G_S8')
        gain_error=float(np.max(abs(n.log10_G_nonlinear-np.log10(n.even_rms*np.sqrt(2)/abs(n.eps)))))
        assert trace_error<1e-12 and gamma_error<1e-9 and gain_error<1e-12
        assert np.max(abs(rj.D-rj.D_trace))<1e-12
        assert st['complete']==41 and st['partial']==1 and st['valid_tangent']==23 and st['valid_nonlinear']==19
        audit=dict(sha256=hashlib.sha256(a.archive.read_bytes()).hexdigest(),cases=len(i),segments=len(aud),trace_rows=len(t),return_rows=len(r),fixed_time_rows=len(g),nonlinear_rows=len(n),tangent_comparison_rows=len(c),localization_rows=len(l),replay_rows=len(re),max_replay_L2=float(re.normalized_L2.max()),max_paired_symmetry_difference=float(sym.normalized_symmetry_difference.max()),max_trace_log_gain_discrepancy=trace_error,max_recomputed_gamma_tau_error=gamma_error,max_recomputed_nonlinear_loggain_error=gain_error)
        for k in ['max_scaled_residual','max_stage_odd_defect','max_tangent_backward_error','max_relative_mean_leak','max_absolute_mean']:audit[k]=float(i[k].max())
        (o/'audit_checks.json').write_text(json.dumps(audit,indent=2)+'\n')
        g.merge(i[['case','status','last_tau']],on='case').to_csv(o/'fixed_time_gains.csv',index=False)
        r.to_csv(o/'return_gains.csv',index=False)
        i.to_csv(o/'inventory.csv',index=False)
        # First threshold violation, not an estimate of a continuum stability interval.
        rows=[]
        for key,x in n.groupby('nonlinear',sort=False):
            x=x.sort_values('tau');b=x[(x.relative_vector_difference>.01)|(x.noise_to_signal>.01)];q=x.iloc[-1];first=b.iloc[0] if len(b) else None
            rows.append(dict(case=key,eps=q.eps,first_threshold_violation_tau=None if first is None else first.tau,relative_vector_difference_at_violation=None if first is None else first.relative_vector_difference,noise_to_signal_at_violation=None if first is None else first.noise_to_signal,last_tau=q.tau,last_log10_G_tangent=q.log10_G_tangent,last_log10_G_nonlinear=q.log10_G_nonlinear,last_even_rms=q.even_rms,last_noise_to_signal=q.noise_to_signal))
        pd.DataFrame(rows).to_csv(o/'nonlinear_validity.csv',index=False)
        reg=g[(g.p==2.25)&(g.nu>0)&(g.tau==4.25)].copy();reg['G_cos2']=10**reg.log10_G_cos2;reg['G_S8']=10**reg.log10_G_S8;reg.to_csv(o/'regularized_final_gains.csv',index=False)
        rows=[]
        for (kind,a1,b1),x in c.groupby(['comparison','case_a','case_b']):
            rows.append(dict(comparison=kind,case_a=a1,case_b=b1,last_tau=x.tau.max(),max_base_L2=x.base_L2.max(),max_abs_log10_gain_delta_cos2=x.cos2_log10_gain_delta.abs().max(),max_abs_log10_gain_delta_S8=x.S8_log10_gain_delta.abs().max(),max_relative_vector_difference_cos2=x.cos2_relative_vector_difference.max()))
        pd.DataFrame(rows).to_csv(o/'comparison_envelopes.csv',index=False)
        l[(l.probe=='cos2')&l.tau.isin([.25,.5,1.,1.25,2.,3.,4.,4.25])].to_csv(o/'localization_cos2.csv',index=False)
    import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    def key(N,K,nu=0.,method='radau',p=2.25,M=4):return f'p{p:g}_M{M}_N{N}_K{K}_nu{nu:g}_{method}_tangent'
    # Each plot uses exported traces, not inferred continuation of failed jobs.
    fig,ax=plt.subplots(figsize=(8,4.6))
    for N in (450,900,1800,3600):
        x=t[t.case==key(N,12800)];ax.plot(x.tau,x.log10_G_cos2,label=f'N={N}')
    ax.set(xlabel=r'$\tau$',ylabel=r'$\log_{10}G_2$');ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(o/'inviscid_mesh_gains.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4.6))
    for method in ('radau','avf'):
        for K in (12800,25600):
            x=t[t.case==key(1800,K,method=method)];ax.plot(x.tau,x.log10_G_cos2,label=f'{method.upper()}, K={K}',ls='-' if K==12800 else '--')
    ax.set(xlabel=r'$\tau$',ylabel=r'$\log_{10}G_2$');ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(o/'integrator_gains.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4.6))
    for nu in (.00025,.001,.004):
        for N in (900,1800):
            x=t[t.case==key(N,12800,nu)];ax.plot(x.tau,x.log10_G_cos2,label=f'ν={nu:g}, N={N}',ls='-' if N==1800 else '--')
    ax.set(xlabel=r'$\tau$',ylabel=r'$\log_{10}G_2$');ax.legend(ncol=2,fontsize=9);ax.grid(alpha=.2);fig.tight_layout();fig.savefig(o/'regularized_gains.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4.6));base=key(1800,12800)
    x=t[t.case==base];ax.plot(x.tau,x.log10_G_cos2,label='Tangent',lw=2)
    for eps in (1e-8,1e-7,1e-6):
        x=n[(n.tangent==base)&(n.eps==eps)];ax.plot(x.tau,x.log10_G_nonlinear,label=f'Nonlinear ε={eps:g}')
    ax.set(xlabel=r'$\tau$',ylabel=r'$\log_{10}G_2$');ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(o/'nonlinear_comparison.png',dpi=180);plt.close(fig)
    print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
