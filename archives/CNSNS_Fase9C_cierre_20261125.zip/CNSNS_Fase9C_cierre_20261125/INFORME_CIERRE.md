# Fase 9C — Auditoría y cierre científico

25 de noviembre de 2026. Caso central Z, p=9/4, M=4; control Z, p=2, M=8.

## Alcance y trazabilidad

Fuente: Fase9C_CNSNS_resultados_20261125.zip, SHA-256 registrado en audit_checks.json. Se han comprobado el CRC de todo el ZIP, los 42 casos, las 122 auditorías JSON y la correspondencia entre los tiempos de las 53 039 observaciones, 231 filas a tiempos fijos y 70 mínimos. Se han recalculado las tasas logarítmicas y las ganancias no lineales a partir de las normas exportadas. Los HDF5 completos y las matrices de etapa no están incluidos: no se ha reproducido de forma independiente cada resolución lineal. Se ha consultado el código de producción fase9c/tangent.py, run.py y report.py. Los diez tests previos verifican la diferenciación de las etapas y la reducción transversal; la verificación de Picasso imprimió FASE9C_VERIFICACION_OK.

41 casos completos para sus respectivos horizontes, 1 parcial (tarea 4 del array 3834377, N=3600, K=12800, último tiempo aceptado 3.24109375; fallo de Newton de la trayectoria base). Los 23 casos tangentes tienen prefijos válidos, 19 no lineales completos. El control N=3600,K=25600 estaba diseñado hasta 1.25; no debe tratarse como fallo. El análisis original no certifica convergencia científica.

## Definiciones

K es el número de pasos por travesía, dt=T_cross/K. G_2 es la norma RMS de la respuesta de la ecuación tangente discreta para un coseno de modo 2 de RMS unidad. La normalización por paso y acumulación de logaritmos evitan desbordamientos. G_S8 es el máximo singular restringido al espacio inicial de ocho direcciones seno/coseno de modos 2,4,6,8, no el máximo del operador completo. El modo de sonda de malla depende de N; no se usa como dirección física fija en comparaciones espaciales. La ecuación tangente se diferencia antes de aplicar la proyección impar al estado base. La comparación no lineal utiliza la componente par, sin sustraer artificialmente la fuga de la corrida con epsilon=0.

## Resultado principal: recurrencia y ganancia transversal no tienen la misma robustez

En N=1800, sin hiperviscosidad explícita, los cuatro mínimos se mantienen para Radau y AVF con dos pasos independientes desde cero. En el cuarto mínimo, D y log10 G_2 son respectivamente (0.238728,15.6954), (0.238337,25.7545), (0.244247,52.6794) y (0.242571,138.7117) para Radau K=12800, Radau K=25600, AVF K=12800, AVF K=25600. El máximo restringido S8 tiene log10 ganancias 16.1333,26.1538,52.7928,139.3238. Estas cifras describen los mapas discretos diferenciados, no perturbaciones finitas que alcancen amplitudes astronómicas. Un menor paso aumenta mucho las ganancias, mientras al refinar N a K fijo las ganancias en tiempos comunes disminuyen. No se ha obtenido una tasa independiente de N y K. La conservación de I por AVF (deriva máxima ~1.5e-11 y 6.1e-11 en N=1800) no garantiza estabilidad transversal ni precisión de la tangente. Un residuo hacia atrás pequeño no es una cota del error hacia delante si el sistema implícito está mal condicionado.

En M=8, p=2, a tau=1.25, log10 G_2=25.3839,10.1434,7.0401 para N=1000,2000,4000 con K=27200; 14.7094 y 10.5440 para N=2000,4000 con K=54400. El mínimo próximo a 1.185 tiene D~1.093, no es un retorno fuerte. Este control reproduce la sensibilidad a espacio y tiempo sin demostrar una inestabilidad del continuo.

## Localización de la respuesta transversal

En N=1800, K=12800, tau=1 (tiempo común próximo al primer retorno), los nodos con |U|<=0.2 ocupan 13.11% del dominio y contienen 97.26% de la norma cuadrática de la perturbación propagada desde cos2. Los modos |n|>20 contienen 99.74% de dicha norma. Para K=25600 las cifras son 86.14% y 99.90%; AVF K=25600 da 93.43% y 99.99%. La fracción en modos altos es un diagnóstico discreto de la respuesta normalizada. No se identifica un mecanismo causal a partir de esta concentración ni se establece una ley de escala de la ganancia. El resultado complementa 9A (localización del residuo de recurrencia, que es un observable distinto).

## Efecto de nu fija

Para nu=0.00025,0.001,0.004, a tau=4.25 las ganancias G_2 son 159.90/174.84,140.88/147.67,139.76/140.45 (N=900/1800; K=12800). Las discrepancias máximas de log10 G_2 a tiempos comunes son 0.3092,0.1444,0.03973 décadas, respectivamente. Las diferencias vectoriales relativas máximas son 1.125,0.983,0.495, respectivamente (normalización por la mayor de las dos normas). Se observa fuerte supresión del crecimiento excesivo, no estabilidad contractual ni convergencia de vectores completos. El control regularizado no incluye refinamiento temporal independiente; tampoco permite extrapolar nu->0.

## Perturbaciones finitas y ruido numérico

En N=1800, K=12800, tau=0.5, log10 G_2 tangente=1.778494; para eps=1e-8,1e-7,1e-6 las diferencias vectoriales relativas son ~2e-6,2.27e-4,1.93e-2. Adoptando como diagnóstico un umbral de 1% simultáneamente en la diferencia vectorial y razón ruido/señal, la primera muestra que lo incumple es tau=0.59,0.56,0.41, respectivamente. No se interpreta este umbral como una frontera matemática de estabilidad. La proximidad de las ganancias escalares puede ocultar divergencia vectorial (eps=1e-8 en tau=1.01: diferencia ~55%). En tau=4.25 la corrida sin perturbación tiene RMS par 8.669e-3, de modo que las comparaciones finitas tardías ya no separan limpiamente señal y fuga numérica. En la pareja de signos opuestos la discrepancia de equivariancia alcanza 4.04e-2; a tiempos cortos es mucho menor. El control sin perturbación mide fuga numérica, no un exponente por sí mismo. Se conserva el resultado temprano y no se interpretan las ganancias lineales tardías como amplificación física de una perturbación finita.

## Controles algebraicos y reproducibilidad

Residuo escalado máximo 0.999994; defecto máximo de antisimetría de etapas 7.14e-13; error hacia atrás máximo 5.04e-16; defecto relativo máximo de media tangente antes de retirarlo 5.73e-14. En el control Newton cien veces más estricto (N=1800,K=12800,tau<=1.25) la discrepancia máxima de base es 8.94e-8 y la diferencia máxima en log10 G_2, 1.03e-4; la diferencia vectorial máxima es 6.19e-4. Por ello la sensibilidad observada a N, dt y método no se explica solo por esta tolerancia, al menos en el intervalo del control.

El replay 9B versus 9C, N=1800,K=12800, tiene 429 comparaciones; diferencia L2 normalizada 3.78e-10 a tau=1, 6.54e-7 a tau=2 y máximo 3.4339e-2. No es reproducción bit a bit de la órbita tardía. Los datos no permiten identificar qué diferencia de implementación/arredondeo inicia la separación. Esto refuerza la necesidad de distinguir los observables del campo y de la respuesta tangente.

## Decisión

Cerrada 9C como diagnóstico de sensibilidad transversal de tiempo finito. No se certifica una tasa convergente de amplificación, estabilidad transversal de la PDE, mala formulación del continuo o inestabilidad asintótica. No relanzar el caso parcial por defecto: existen controles espaciales/temporales hasta el primer retorno en N=3600 y ya se ha documentado una dependencia de muchos órdenes de magnitud a igual N. Si en el futuro se quiere demostrar una tasa del continuo, será un objetivo independiente, con refinamiento conjunto de N y dt, estimación de condicionamiento y controles no lineales de precisión. Mantener el resultado de sensibilidad y sus reservas en el cuerpo principal de CNSNS, relegando la campaña completa al suplemento.
