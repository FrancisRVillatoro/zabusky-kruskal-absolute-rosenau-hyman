"""Verify archived bytes and recompute the paper's principal numerical comparisons."""
import csv
import hashlib
import math
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "exports"

def read(path, sep=","):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter=sep))

def near(a, b, tolerance):
    if abs(a - b) > tolerance:
        raise ValueError(f"{a} differs from {b} by more than {tolerance}")

def main():
    provenance = read(ROOT / "FILE_PROVENANCE.tsv", "\t")
    for item in provenance:
        path = ROOT / item["supplement_path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
            raise ValueError(f"SHA-256 mismatch for {path}")
    print(f"Verified {len(provenance)} archived source and data files.")

    fine = {int(r["index"]): r for r in read(DATA / "returns/retornos.csv")
            if r["N"] == "1800" and r["status"] == "LOCAL_MIN"}
    fourth, = [r for r in read(DATA / "fourth_return/retornos4b.csv")
               if r["N"] == "1800" and r["dt_divisor"] == "4"]
    fine[4] = fourth
    if set(fine) != {1, 2, 3, 4}:
        raise ValueError("Incomplete return sequence")
    for j, r in sorted(fine.items()):
        D, amp, H = map(float, (r["D"], r["r"], r["H"]))
        near(D**2, (amp - 1)**2 + H, 2e-14)
        near(float(r["Phi1"]), amp**2 / (amp**2 + H), 2e-14)
        if j <= 3:
            samples = read(DATA / f"returns/profile_return{j}_N1800.csv")
            if len(samples) != 1800:
                raise ValueError("Unexpected full-field grid")
            squared_error = sum((float(v["u"]) - float(v["u0_opt_shift"]))**2
                                for v in samples)
            reference_power = sum(float(v["u0_opt_shift"])**2 for v in samples)
            near(math.sqrt(squared_error / reference_power), D, 1e-12)
        print(f"Return {j}   tau={float(r['tau']):.8f}  D={D:.8f}")

    rows = read(DATA / "pulse_morphology/fase5/results/analysis/snapshots.csv")
    positive = [r for r in rows if r["case"] == "P_p2_M8" and r["role"] == "space_high"
                and float(r["tau"]) >= 0.25 - 1e-12]
    near(len(positive), 176, 0)
    floor = min(float(r["minimum_over_peak"]) for r in positive)
    if floor <= 0.01:
        raise ValueError("Positive background result differs on a stored snapshot")
    print(f"P, M=8    {len(positive)} snapshots   smallest min/max={floor:.8f}")

    comp = read(DATA / "regularization/fase6/results/analysis/zero_nu_comparison.csv")
    groups = defaultdict(list)
    for r in comp:
        gap = abs(float(r["nu_D"]) - float(r["nu0_D"]))
        groups[r["N"], r["return_index"]].append((float(r["nu"]), gap))
    if len(groups) != 8:
        raise ValueError("Unexpected set of mesh/return comparisons")
    for group, series in groups.items():
        s = sorted(series)
        if len(s) != 3 or not s[0][1] < s[1][1] < s[2][1]:
            raise ValueError(f"Weak-regularization comparison differs for {group}")
    print("Checked the three regularization coefficients against the discrete "
          "unregularized return at each of two resolutions and four returns.")

if __name__ == "__main__":
    main()
