"""Fixed-step periodic mass-matrix Radau controls for the manuscript review.

The nonlinear solver is the production solver. The optional precomputed sparse
pattern evaluates its exact analytic stage Jacobian for zero physical viscosity.
Usage: python compare_radau.py --case free900 --output results
"""
from pathlib import Path
import argparse
import csv
import json
import sys
import time

import numpy as np
import scipy
from scipy.sparse import csc_matrix

HERE = Path(__file__).resolve().parent
for candidate in [HERE.parent / 'code', HERE.parent / 'supp' / 'code', HERE.parent.parent / 'code']:
    if (candidate / 'absk_radau').is_dir():
        sys.path.insert(0, str(candidate))
        break
from absk_radau import (A_R, PeriodicAbsK, MassRadau5, NewtonOptions, NewtonFailure,
                         make_initial_data, domain_length, crossing_time)

# p, M, N, steps per crossing, horizon, initial family, project, perturbation
CASES = {
    'free900': (2.25, 4, 900, 3200, 4.25, 'Z', False, 0),
    'pert900': (2.25, 4, 900, 3200, 4.25, 'Z', False, 1e-7),
    'project450': (2.25, 4, 450, 3200, 4.25, 'Z', True, 0),
    'project900': (2.25, 4, 900, 3200, 4.25, 'Z', True, 0),
    'null900': (7/3, 4, 900, 3200, 1.25, 'Z', True, 0),
    'cubic450': (3., 4, 450, 3200, 1.25, 'Z', True, 0),
    'cubic900': (3., 4, 900, 3200, 1.25, 'Z', True, 0),
    'short336': (2.25, 3, 336, 3200, 1.25, 'Z', True, 0),
    'short672': (2.25, 3, 672, 3200, 1.25, 'Z', True, 0),
    'long560': (2.25, 5, 560, 3200, 1.25, 'Z', True, 0),
    'long1120': (2.25, 5, 1120, 3200, 1.25, 'Z', True, 0),
    'positive1000': (2., 8, 1000, 3400, 5., 'P', False, 0),
    'positive2000': (2., 8, 2000, 3400, 5., 'P', False, 0),
}


class FixedPatternRadau(MassRadau5):
    """Same sparse blocks as MassRadau5; reuse indices for nu=frame_speed=0."""
    def __init__(self, model, options, project):
        super().__init__(model, options, project)
        if model.nu != 0 or model.frame_speed != 0:
            raise ValueError('The cached pattern is for the zero-linear-term experiments.')
        # Store entries of each column in CSC order. Structural zeros in the
        # first/third derivative center can only contribute to a diagonal block.
        mass = model.mass.tocoo()
        k = np.asarray(model.K.tocsr()[mass.row, mass.col]).ravel()
        row, col, base, weights = [], [], [], []
        for i in range(3):
            for j in range(3):
                mask = np.ones_like(k, dtype=bool) if i == j else (k != 0)
                row.append(i*self.n + mass.row[mask])
                col.append(j*self.n + mass.col[mask])
                base.append(mass.data[mask] if i == j else np.zeros(mask.sum()))
                weights.append(A_R[i,j]*k[mask])
        row, col = np.concatenate(row), np.concatenate(col)
        order = np.lexsort((row, col))
        self.rows = row[order].astype(np.int32)
        self.cols = col[order]
        self.starts = np.r_[0, np.cumsum(np.bincount(col,minlength=3*self.n))].astype(np.int32)
        self.base = np.concatenate(base)[order]
        self.weights = np.concatenate(weights)[order]

    def stage_jacobian(self, stages, dt):
        derivative = self.model.p * np.abs(stages.ravel())**(self.model.p-1)
        entries = self.base + dt*self.weights*derivative[self.cols]
        return csc_matrix((entries, self.rows, self.starts), shape=(3*self.n,3*self.n))


def kernel_check():
    m = PeriodicAbsK(48, domain_length(2.25,4), 2.25)
    options = NewtonOptions(predictor='euler')
    direct, cached = MassRadau5(m, options), FixedPatternRadau(m, options, False)
    stages = np.random.default_rng(34).normal(size=(3,48))
    diff = (direct.stage_jacobian(stages,.01)-cached.stage_jacobian(stages,.01)).toarray()
    assert np.max(np.abs(diff)) < 1e-12
    ua = make_initial_data(m)
    ub = ua.copy()
    for _ in range(8):
        ua,_=direct.step(ua,.01)
        ub,_=cached.step(ub,.01)
    assert np.max(np.abs(ua-ub)) < 1e-12


def run(name, output):
    p,m,n,k,horizon,family,project,epsilon=CASES[name]
    length=domain_length(p,m)
    model=PeriodicAbsK(n,length,p)
    configs=[NewtonOptions(predictor='euler'),
             NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='euler'),
             NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='constant')]
    solvers=[FixedPatternRadau(model, opt, project) for opt in configs]
    initial=make_initial_data(model,family)
    u=solvers[0].project(initial.copy())
    if epsilon: u+=epsilon*np.cos(4*np.pi*model.x/length)
    # D uses the original pure harmonic target for all Z trajectories,
    # including the explicitly perturbed transverse test.
    a,b=(0,1) if family=='Z' else (.5,.5)
    I0=model.lp_invariant(u)
    s=crossing_time(p,m)/k
    result_dir=output/name
    result_dir.mkdir(parents=True,exist_ok=True)
    best={j:(float('inf'),-1,None) for j in range(1,round(horizon)+1)}
    rows=[]; fields=[]; ticks=[]; accepted=0; fallbacks=0; err=0.; failure=None

    def observe(step):
        ft=np.fft.rfft(u)/n
        r=2*abs(ft[1])/b
        H=(2*np.sum(abs(ft[2:-1])**2)+abs(ft[-1])**2)/(b*b/2)
        D=np.sqrt(((ft[0].real-a)**2+b*b/2*((r-1)**2+H))/(a*a+b*b/2))
        e5=4*abs(ft[5])**2/b**2
        rows.append((step,step/k,D,r,H,r*r/(r*r+H),e5/H if H>1e-25 else np.nan,
                     model.normalized_halfwave_defect(u), (model.lp_invariant(u)-I0)/I0,
                     u.min(),u.max()))

    observe(0);ticks.append(0);fields.append(u.copy())
    started=time.perf_counter()
    for step in range(1, round(horizon*k)+1):
        for idx,solver in enumerate(solvers):
            try:
                new,st=solver.step(u,s)
                break
            except NewtonFailure as exc:
                last_message=str(exc)
        else:
            failure=last_message
            break
        u=new;accepted=step;fallbacks+=int(idx>0);err=max(err,st.norm_residual)
        # Resolve all candidate minima; store full fields every .01 crossing and
        # the exact minimum for each +/- .20 return window separately.
        observe(step)
        if step % (k//100)==0:
            ticks.append(step);fields.append(u.copy())
        tau=step/k
        for j in range(1,round(horizon)+1):
            if abs(tau-j) < .2 and rows[-1][2] < best[j][0]:
                best[j]=(rows[-1][2],step,u.copy())
        if step % 1000==0:
            print(name,step,round(step/k,3),round(time.perf_counter()-started,1),flush=True)
    columns='step,tau,D,r,H,Phi1,e5_over_H,half_defect,relative_I_change,min_u,max_u'.split(',')
    with (result_dir/'history.csv').open('w') as handle:
        writer=csv.writer(handle); writer.writerow(columns);writer.writerows(rows)
    # Retain common-time fields losslessly for pairwise comparison, and provide
    # explicit candidate snapshots (interiority is checked by the analysis).
    np.savez_compressed(result_dir/'fields.npz',step=ticks,u=np.stack(fields))
    minima={f'u{j}': x[2] for j,x in best.items() if x[2] is not None}
    minima.update({f'step{j}':x[1] for j,x in best.items() if x[2] is not None})
    np.savez_compressed(result_dir/'near_integer.npz',**minima)
    status=dict(case=name,N=n,p=p,M=m,family=family,project=project,epsilon=epsilon,
                k=k,target=horizon,accepted=accepted,last_tau=accepted/k,retries=fallbacks,
                max_scaled_residual=err,failed=failure,scipy=scipy.__version__,
                seconds=time.perf_counter()-started)
    (result_dir/'status.json').write_text(json.dumps(status,indent=2)+'\n')
    print(status,flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--case',choices=CASES)
    ap.add_argument('--output',type=Path,default=HERE/'results')
    args=ap.parse_args();kernel_check()
    if args.case:
        run(args.case,args.output)
