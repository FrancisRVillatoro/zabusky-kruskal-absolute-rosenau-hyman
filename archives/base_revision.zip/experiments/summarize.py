"""Summarize completed fixed-step controls on matched output grids."""
from pathlib import Path
import json
import csv
import numpy as np
from scipy.signal import find_peaks
from compare_radau import CASES

root=Path(__file__).resolve().parent
dest=root/'results'
def save(file,rows):
    if rows:
        with (dest/file).open('w') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]))
            w.writeheader(); w.writerows(rows)

def history(case):
    return np.genfromtxt(dest/case/'history.csv',names=True,delimiter=',')

def field(case):
    with np.load(dest/case/'fields.npz') as a:
        return a['step']/CASES[case][3],a['u']

def pair(x,y):
    t,u=field(x); t2,v=field(y)
    times,i,l=np.intersect1d(t,t2,return_indices=True)
    fine=v[l,::v.shape[1]//u.shape[1]]
    return times,np.linalg.norm(u[i]-fine,axis=1)/np.linalg.norm(u[0])
def band(x):
    return x.min(),x.max()

def main():
    states=[]; events=[]; powers=[]; traces=[]; mins=[]
    for case in CASES:
        base=dest/case
        if not (base/'status.json').exists():continue
        status=json.loads((base/'status.json').read_text())
        states.append(status)
        h=history(case); t=h['tau']
        if status['family']=='P':
            for label,left,right in [('I',.25,2),('II',2,5),('final',5,5)]:
                arr=h[(t>=left)&(t<=right)]
                if len(arr):
                    q=arr['min_u']/arr['max_u']
                    mins.append(dict(case=case,interval=label,tau_first=arr['tau'][0],tau_last=arr['tau'][-1],min_ratio=q.min(),max_ratio=q.max(),median_ratio=np.median(q),min_u=arr['min_u'].min()))
            continue
        candidates=find_peaks(-h['D'])[0]
        intervals=[('survey',.2,1.25),('j1',.94,1.10),('j2',1.8,2.2),('j3',2.8,3.2),('j4',3.8,4.2)]
        for label,left,right in intervals:
            valid=candidates[(t[candidates]>left)&(t[candidates]<right)]
            if status['last_tau']+1e-10<right:continue
            j=valid[np.argmin(h['D'][valid])] if len(valid) else None
            row=dict(case=case,interval=label,n_candidates=len(valid))
            for key in ('tau','D','H','r','e5_over_H','half_defect','relative_I_change'):
                row[key]=h[key][j] if j is not None else ''
            events.append(row)
    for x,y in [('cubic450','cubic900'),('short336','short672'),('long560','long1120'),('positive1000','positive2000'),('project900','free900'),('free900','pert900'),('project450','project900')]:
        if not all((dest/q/'status.json').exists() for q in (x,y)):continue
        t,d=pair(x,y)
        for a,b in [(0,1.25),(0,4.25),(.9,1.1),(1.9,2.1),(2.9,3.1),(3.9,4.1),(0,5)]:
            ix=(t>=a-1e-10)&(t<=b+1e-10)
            if not ix.any() or t[-1]+1e-10<b:continue
            powers.append(dict(A=x,B=y,first=a,last=b,field_difference_max=d[ix].max(),field_difference_last=d[ix][-1]))
        if 'free900' in (x,y):
            for time,di in zip(t,d):
                traces.append(dict(A=x,B=y,tau=time,field_difference=di,relative_to_initial_perturbation=di/d[0] if d[0]>0 else ''))
    save('run_status.csv',states);save('local_minima.csv',events);save('field_comparisons.csv',powers);save('positive_troughs.csv',mins);save('projection_trace.csv',traces)
if __name__=='__main__':main()
