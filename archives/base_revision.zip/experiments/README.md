# Independent Radau experiments

These runs use the mass-matrix Radau solver and an analytic sparse Jacobian with its CSC index pattern cached. compare_radau.py checks the Jacobian against the original assembly and compares eight integration steps on a small grid before each run. Every accepted stage is subject to the original scaled residual test. Retries retain the same time step. Each status.json records the achieved time, configuration, retry count, SciPy version and an explicit failure field.

Run in this directory after unpacking the full supplement and installing the Python dependencies.

    export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
    for c in project450 project900 free900 pert900 cubic450 cubic900 short336 short672 long560 long1120 null900 positive1000 positive2000; do
        python compare_radau.py --case "$c" || break
    done
    python extend_m5.py long560
    python extend_m5.py long1120
    python fourth_profile.py
    python summarize.py
    python plot_controls.py

All histories record the return distance to the original cosine for Z; the epsilon trajectory uses that same reference. Fields are sampled every 0.01 crossing for comparisons, and event depths use every accepted step within the selected window unless the profile is being matched to the archived production catalogue. The M=5 continuation starts at the saved field at 1.25 and brackets the return in the extended window. The fine fourth-return field replay starts from the all-node archived third-return field, uses the base step to 3.25 and then uses its quarter step; event detection follows the production output cadence. Full-field series compare coincident spatial nodes. The positive long-time calculation resolves every time step when determining the first negative value and the raw minimum.

The summary CSV files in results/ give status, interval-specific local minima, field comparisons, positive trough statistics and the perturbation trace. In results/<case>/ the NPZ arrays retain common-time complete fields, the near-integer candidates and the associated integration steps. Endpoints of return-search windows are excluded from all reported minima. A missing minimum in the near-integer window does not rule out a minimum at another time.

Local runs and figures have been generated with the versions in local_versions.txt. The historical production software versions are in the top-level README.
