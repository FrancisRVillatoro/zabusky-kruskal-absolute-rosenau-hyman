"""Reconstruct the fine Radau fourth-return profile from the full archived third-return field."""
from pathlib import Path
import numpy as np
import json
from compare_radau import FixedPatternRadau, PeriodicAbsK, domain_length, crossing_time, NewtonOptions, NewtonFailure
HERE=Path(__file__).resolve().parent
source=next(p for p in (HERE.parent/'supp',HERE.parent,HERE.parent.parent) if (p/'exports/returns/profile_return3_N1800.csv').exists())
profile=np.genfromtxt(source/'exports/returns/profile_return3_N1800.csv',delimiter=',',names=True)
p,m,n=2.25,4,1800
model=PeriodicAbsK(n,domain_length(p,m),p)
opts=[NewtonOptions(predictor='euler'),NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='euler'),NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='constant')]
solvers=[FixedPatternRadau(model,o,True) for o in opts]
u=profile['u'].copy()
start=float(profile['tau'][0])
out=HERE/'results'/'fine_fourth'
out.mkdir(parents=True,exist_ok=True)
best=None
for k,end in [(3200,3.25),(12800,4.2)]:
    dt=crossing_time(p,m)/k
    for i in range(round(start*k)+1,round(end*k)+1):
        for solver in solvers:
            try:
                v,_=solver.step(u,dt)
                break
            except NewtonFailure as ex:
                msg=str(ex)
        else:
            (out/'failure.txt').write_text(f'{(i-1)/k}: {msg}')
            raise RuntimeError(msg)
        u=v
        if 3.8 <= i/k <=4.2 and i%4==0:
            f=np.fft.rfft(u)/n
            D=np.sqrt((2*abs(f[1])-1)**2+4*np.sum(abs(f[2:-1])**2)+2*abs(f[-1])**2)
            if best is None or D < best[0]:best=(D,i/k,u.copy())
        if i%1600==0:print(i/k,flush=True)
    start=end
np.savez_compressed(out/'near_integer.npz',u4=best[2],tau=best[1],D=best[0])
print(best[:2],flush=True)
