"""Continue the M=5 signed runs whose return dip crosses the survey endpoint."""
import argparse
import csv
import json
import numpy as np
from compare_radau import CASES,HERE,FixedPatternRadau,PeriodicAbsK,domain_length,crossing_time,NewtonOptions,NewtonFailure
from scipy.signal import find_peaks
parser=argparse.ArgumentParser()
parser.add_argument('case',choices=['long560','long1120'])
case=parser.parse_args().case
p,m,n,k,*_=CASES[case]
dest=HERE/'results'/case
st=json.loads((dest/'status.json').read_text())
assert st['last_tau']==1.25 and st['failed'] is None
with np.load(dest/'fields.npz') as a:u=a['u'][-1].copy()
model=PeriodicAbsK(n,domain_length(p,m),p)
opts=[NewtonOptions(predictor='euler'),NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='euler'),NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='constant')]
solvers=[FixedPatternRadau(model,o,True) for o in opts]
s=crossing_time(p,m)/k
rows=[]
failed=None
for step in range(round(1.25*k)+1,round(1.65*k)+1):
    for solver in solvers:
        try:
            v,_=solver.step(u,s);break
        except NewtonFailure as ex:msg=str(ex)
    else:failed=msg;break
    u=v
    f=np.fft.rfft(u)/n
    H=4*np.sum(abs(f[2:-1])**2)+2*abs(f[-1])**2
    D=np.sqrt((2*abs(f[1])-1)**2+H)
    rows.append((step/k,D,H,4*abs(f[5])**2/H))
with (dest/'extension.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['tau','D','H','e5_over_H']);w.writerows(rows)
(dest/'extension_status.json').write_text(json.dumps(dict(last_tau=rows[-1][0],failed=failed),indent=2)+'\n')
a=np.array(rows);ix=find_peaks(-a[:,1],prominence=.03)[0]
print(case,st['last_tau'],a[-1,0],a[ix],failed,flush=True)
