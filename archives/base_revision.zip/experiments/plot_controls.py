"""Return timing, sensitivity to even-harmonic perturbation and sign of the raised-cosine trough."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from summarize import history,pair
root=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':8.5,'axes.spines.right':False,'axes.spines.top':False,'pdf.fonttype':42})
fig,(a,b,c)=plt.subplots(1,3,figsize=(7.05,2.35),layout='constrained')
for case,label,color,style in [('short672','3','#34659a','--'),('project900','4','#a34627','-'),('long1120','5','#167563','-.')]:
    data=history(case)
    t=data['tau'];d=data['D']
    if case=='long1120':
        extra=np.genfromtxt(root/'results'/case/'extension.csv',names=True,delimiter=',')
        t=np.r_[t,extra['tau']]; d=np.r_[d,extra['D']]
    a.plot(t[::5],d[::5],ls=style,lw=1.1,label=label,color=color)
a.set(xlim=(0,1.65),ylim=(-.03,1.22),xlabel='Crossings, '+r'$\tau$',ylabel='Return distance '+r'$D$')
a.legend(title=r'$M$',loc='upper left',ncol=1,fontsize=7,frameon=False,handlelength=1.6,borderpad=.2)
t,d=pair('free900','pert900');b.semilogy(t,d,color='#34659a',lw=1.1)
b.set(xlabel='Crossings, '+r'$\tau$',ylabel=r'$\|u_\epsilon-u\|_2/\|u_0\|_2$',xlim=(0,4.25))
for case,label,color,ls in [('positive1000','1000','#945133','--'),('positive2000','2000','#167563','-')]:
    data=history(case);stride=10
    c.plot(data['tau'][::stride],(data['min_u']/data['max_u'])[::stride],color=color,ls=ls,label=label,lw=.95)
c.axhline(0,lw=.7,color='.3');c.set(xlabel='Crossings, '+r'$\tau$',ylabel=r'$\min u/\max u$',xlim=(0,5))
c.legend(loc='upper right',fontsize=7,frameon=False,title=r'$N$')
for ax,title in zip((a,b,c),['(a) Domain length','(b) Transverse perturbation','(c) Raised-cosine trough']):
    ax.set_title(title,loc='left',fontsize=9.3);ax.grid(axis='y',alpha=.18,lw=.6)
fig.savefig(root/'extended_controls.pdf',bbox_inches='tight',pad_inches=.04)
