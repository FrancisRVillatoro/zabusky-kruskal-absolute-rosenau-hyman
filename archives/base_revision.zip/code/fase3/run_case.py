"""Run ONE campaign row with the already verified phase-2 solver.

For Picasso: python3 -m fase3.run_case --manifest fase3/campaign_main.csv --index "$SLURM_ARRAY_TASK_ID" --output fase3/results/main
It never installs anything or edits phase-2 sources.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import platform
import numpy as np
import scipy
import h5py
from .design import read_manifest
from absk_radau.model import PeriodicAbsK, make_initial_data
from absk_radau.radau_mass import MassRadau5,NewtonOptions,RunStats
from absk_radau.io import H5Recorder


def validate_h5(path:Path, row):
    with h5py.File(path,'r') as h:
        status=h.attrs['status']
        if status != 'COMPLETED':raise AssertionError(f'HDF5 not COMPLETE: {status}')
        n=int(row['N']); tau_end=float(row['tau_end'])
        tcross=float(row['T_cross'])
        t=np.asarray(h['t'][:]); u=h['u']; d=h['diagnostics']; logs=h['step_log'][:]
        assert u.ndim==2 and u.shape[1]==n and u.shape[0]==t.size
        assert t.size==round(tau_end/float(row['tau_out']))+1, (t.size,row['run_id'])
        assert d.shape==(t.size,10)
        assert np.all(np.isfinite(u[:])), 'non-finite fields'
        assert np.all(np.diff(t)>0), 'non-increasing times'
        tau=t/tcross
        ref=np.arange(t.size,dtype=float)*float(row['tau_out'])
        assert np.max(np.abs(tau-ref))<5e-10,(np.max(np.abs(tau-ref)),row['run_id'])
        assert abs(tau[-1]-tau_end)<1e-10
        assert np.all(np.isfinite(d[:,1:4]))
        stats=json.loads(h.attrs['run_stats_json'])
        assert int(stats['accepted'])==len(logs),(stats['accepted'],len(logs))
        assert stats['rejected_newton']==0 and stats['rejected_error']==0
        assert np.all(logs[:,7]==1.),'unexpected rejected event'
        assert float(stats['max_scaled_residual'])<=1.+1e-10
        assert np.all(logs[:,4]<=1.+1e-10),'stage RMS tolerance exceeded'
        assert float(stats['max_accepted_dt']) <= float(row['dt'])*(1+1e-9)
        assert float(stats['min_accepted_dt']) >= float(row['dt'])*(1-1e-7), 'unexpected shortened timestep'
        assert np.allclose(h['x'][:],np.arange(n)*float(h.attrs['period'])/n,rtol=0,atol=5e-12)
        mas=d[:,1]
        mass_abs=float(abs(mas[-1]-mas[0]))
        I=d[:,2]
        inv_rel=float(abs(I[-1]-I[0])/max(abs(I[0]),1e-300))
        if float(row['nu'])==0.:
            # Not an a priori guarantee for long time: record, don't filter on drift.
            assert np.all(np.isfinite(I))
        return dict(status='COMPLETED',snapshots=int(t.size),steps=int(stats['accepted']),
                    elapsed_physical_time=float(t[-1]),elapsed_tau=float(tau[-1]),
                    mass_drift_abs=mass_abs,lp_drift_relative=inv_rel,
                    max_scaled_newton_rms=float(stats['max_scaled_residual']),
                    max_newton_iterations_per_step=int(np.nanmax(logs[:,2])),
                    max_abs_halfwave_defect=float(np.nanmax(d[:,4])) if 'Z'==row['family'] else None)


def main():
    a=argparse.ArgumentParser()
    a.add_argument('--manifest',required=True)
    a.add_argument('--index',required=True,type=int)
    a.add_argument('--output',required=True)
    args=a.parse_args()
    entries=read_manifest(args.manifest)
    if args.index<1 or args.index>len(entries):
        raise SystemExit('Indice fuera del manifiesto')
    row=entries[args.index-1]
    if int(row['task_id'])!=args.index:
        raise AssertionError('Manifest order not preserved')
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    result=out/(row['run_id']+'.h5')
    manifest_sha256=hashlib.sha256(Path(args.manifest).read_bytes()).hexdigest()
    # Fixed integer step count: crucial for clean tau-aligned comparisons.
    # The phase-2 integrate() loop may append a tiny final step when
    # repeated floating-point additions leave t just below t_end.
    # We DO NOT change Radau stages; we only use exactly n_snapshots*nsubsteps.
    nblocks=int(round(float(row['tau_end'])/float(row['tau_out'])))
    nsub=int(row['save_every'])
    nsteps=nblocks*nsub
    if nsteps>int(row['max_steps']):
        raise ValueError('nsteps > max_steps')
    dt=float(row['dt'])
    tcross=float(row['T_cross'])
    t_end=nsteps*dt
    if abs(t_end/tcross-float(row['tau_end']))>1e-10:
        raise AssertionError('t_end and tau_end inconsistent')
    n=int(row['N'])
    p=float(row['p']);M=float(row['M']);nu=float(row['nu'])
    model=PeriodicAbsK(n,float(2*np.pi*M*p/(p-1)),p,nu)
    options=NewtonOptions(atol=float(row['newton_atol']),
                          rtol=float(row['newton_rtol']),
                          max_iter=int(row['newton_max_iter']),predictor='euler')
    project_half=bool(int(row['project_half']))
    solver=MassRadau5(model,options,project_half=project_half)
    u=solver.project(make_initial_data(model,row['family'],1.))
    config=dict(run_id=row['run_id'],phase='phase3',p=p,M=M,N=n,
                family=row['family'],amplitude=1.,nu=nu,project_half=project_half,
                regularization='fourth_order',T_cross=tcross,t_end=t_end,
                dt=dt,save_every=nsub,nsteps=nsteps,raw_manifest_row=row,
                driver='fixed_exact_integer_step_count',
                environment=dict(python=sys.version.split()[0],numpy=np.__version__,
                                 scipy=scipy.__version__,h5py=h5py.__version__,
                                 platform=platform.platform()))
    print('FASE3_START',row['run_id'],'N',n,'nu',nu,'dt',dt,
          'tau_end',row['tau_end'],'nsteps',nsteps,flush=True)
    start=time.perf_counter()
    recorder=H5Recorder(result,model,config,row['family'],1.)
    stats=RunStats(mode='fixed_exact_step_count')
    try:
        recorder(0.,u,stats)
        for k in range(1,nsteps+1):
            # A failure of the sparse nonlinear solve raises and marks HDF5 incomplete.
            u,diag=solver.step(u,dt)
            t=k*dt  # multiplication avoids accumulated floating-point drift
            stats.add_step(diag,dt)
            stats.final_time=t
            recorder.on_step(t,dt,diag,'accepted',float('nan'))
            if k%nsub==0:
                recorder(t,u,stats)
            if k%max(nsub, nsteps//5)==0:
                print('FASE3_PROGRESS',row['run_id'],f'{k}/{nsteps}',flush=True)
        recorder.finish(stats)
    except BaseException as exc:
        recorder.fail(exc)
        raise
    audit=validate_h5(result,row)
    audit.update(run_id=row['run_id'],task_id=args.index,manifest_sha256=manifest_sha256,
                 wall_seconds=time.perf_counter()-start,
                 description='Independent HDF5 validation on Picasso compute node')
    audit_file=out/(row['run_id']+'.audit.json')
    if audit_file.exists():
        raise FileExistsError('No se sobrescribe auditoria: '+str(audit_file))
    audit_file.write_text(json.dumps(audit,indent=2,allow_nan=False)+'\n')
    print('FASE3_CASE_OK',row['run_id'],'N',row['N'],
          'accepted',audit['steps'],'max_rms',audit['max_scaled_newton_rms'],
          'mass_drift',audit['mass_drift_abs'],
          'lp_drift',audit['lp_drift_relative'],flush=True)

if __name__=='__main__':main()
