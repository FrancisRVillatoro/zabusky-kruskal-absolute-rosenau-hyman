"""Auditoria no invasiva: campos HDF5 existentes -> curvas modales y mínimos muestreados.
No integra la PDE, no modifica simulaciones ni sustituye casos faltantes.
Requiere NumPy, SciPy, h5py. Usar python/3.14.3 en Picasso.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import zipfile
from pathlib import Path

import h5py
import numpy as np
from scipy.signal import find_peaks

FIELDS_SERIES = ['run_id','case','role','N','tau','D_cont','D_grid','Phi1','r','H_high','I_p1','mass','Ahalf']
FIELDS_MIN = ['run_id','case','role','N','tau','D_cont','Phi1','r','H_high','prominence','selection']
FIELDS_RESUMEN = ['run_id','case','role','N','estado','tau_final','D_final','I_drift_rel','newton_rms_max',
                  'n_min_locales','tau_min_post_02','D_min_post_02','tau_min_080_120','D_min_080_120','fuente']


def write_rows(path, fields, rows):
    with Path(path).open('w', encoding='utf-8', newline='') as out:
        wr = csv.DictWriter(out, fieldnames=fields)
        wr.writeheader()
        wr.writerows(rows)


def execute(input_dir, outdir, archive, expected=26):
    input_dir=Path(input_dir); outdir=Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    source_files=sorted(input_dir.glob('*.h5'))
    if not source_files:
        raise RuntimeError(f'No se encontraron HDF5 en {input_dir}; comprobar enlaces de combined_fixed')
    series=[]; minima=[]; summaries=[]; invalid=[]
    for file in source_files:
        with h5py.File(file, 'r') as h:
            state=str(h.attrs.get('status', 'UNKNOWN'))
            if state != 'COMPLETED':
                invalid.append(f'{file.name}: {state}')
                continue
            config=json.loads(h.attrs['config_json'])
            t=np.asarray(h['t'][:], dtype=float)
            d=np.asarray(h['diagnostics'][:], dtype=float)
            if d.ndim != 2 or d.shape[1] != 10 or d.shape[0] != len(t):
                raise RuntimeError(f'Diagnosticos incompatibles en {file}')
            tc=float(config['T_cross'])
            tau=t/tc
            if not (np.all(np.isfinite(d[:,[1,2,5,7,8,9]])) and np.all(np.diff(t)>0)):
                raise RuntimeError(f'Diagnosticos no finitos o tiempos no crecientes en {file}')
            name=file.stem
            if '__' not in name: raise RuntimeError(f'Nombre inesperado: {name}')
            case,role=name.split('__',1)
            nn=int(h.attrs['n_cells'])
            for j in range(len(tau)):
                series.append(dict(run_id=name,case=case,role=role,N=nn,
                        tau=f'{tau[j]:.12g}',D_cont=f'{d[j,5]:.17g}',
                        D_grid=f'{d[j,6]:.17g}',Phi1=f'{d[j,7]:.17g}',r=f'{d[j,8]:.17g}',
                        H_high=f'{d[j,9]:.17g}',I_p1=f'{d[j,2]:.17g}',mass=f'{d[j,1]:.17g}',
                        Ahalf=f'{d[j,4]:.17g}'))
            indices, props=find_peaks(-d[:,5],prominence=0.005, distance=3)
            indices=[(int(idx),float(prom)) for idx,prom in zip(indices,props['prominences']) if tau[idx]>=.2]
            for idx,prom in indices:
                minima.append(dict(run_id=name,case=case,role=role,N=nn,
                        tau=f'{tau[idx]:.12g}',D_cont=f'{d[idx,5]:.17g}',
                        Phi1=f'{d[idx,7]:.17g}',r=f'{d[idx,8]:.17g}',
                        H_high=f'{d[idx,9]:.17g}',prominence=f'{prom:.15g}',selection='local_sampled'))
            def window_min(a,b):
                ix=np.flatnonzero((tau>=a-1.e-10)&(tau<=b+1.e-10))
                if not len(ix): return None,None
                at=int(ix[np.argmin(d[ix,5])]);return round(float(tau[at]),10),float(d[at,5])
            t02,d02=window_min(.2,float(tau[-1]))
            t80,d80=window_min(.8,1.2)
            invdrift=float(abs(d[-1,2]-d[0,2])/max(abs(d[0,2]),1.e-300))
            auditpath=file.with_suffix('.audit.json')
            maxnewton=''
            if auditpath.is_file():
                maxnewton=json.loads(auditpath.read_text()).get('max_scaled_newton_rms','')
            summaries.append(dict(run_id=name,case=case,role=role,N=nn,estado='COMPLETED',
                    tau_final=f'{tau[-1]:.12g}',D_final=f'{d[-1,5]:.17g}',
                    I_drift_rel=f'{invdrift:.17g}',newton_rms_max=maxnewton,
                    n_min_locales=len(indices),tau_min_post_02=t02,D_min_post_02=d02,
                    tau_min_080_120=t80,D_min_080_120=d80,fuente=str(file)))
    write_rows(outdir/'series_25.csv', FIELDS_SERIES, series)
    write_rows(outdir/'minimos_locales.csv', FIELDS_MIN, minima)
    write_rows(outdir/'resumen_25.csv', FIELDS_RESUMEN, summaries)
    report={'total_esperado':expected,'hdf5_completados':len(summaries),'faltantes':expected-len(summaries),
            'n_snapshots':len(series),'n_minimos_locales':len(minima),'errores':invalid,
            'aviso':'Minimos muestreados en tiempos guardados; no se infiere convergencia del continuo. '
                    'No se reemplaza la trayectoria fallida. Las ventanas incluyen puntos finales.'}
    (outdir/'resumen_25.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    archive=Path(archive)
    archive.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name in ('series_25.csv','minimos_locales.csv','resumen_25.csv','resumen_25.json'):
            z.write(outdir/name,arcname=name)
    print('FASE3_RETORNOS_OK',len(summaries),'/',expected,'snapshot_rows',len(series),
          'local_minima',len(minima),'zip',archive,flush=True)
    for v in summaries:
        if v['case'] == 'Z_p225_M4':
            print('RETORNO_CENTRAL',v['role'],v['N'],v['tau_min_080_120'],v['D_min_080_120'],flush=True)
    return report


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--combined',default='fase3/results/combined_fixed')
    p.add_argument('--out',default='fase3/results/retornos_25')
    p.add_argument('--zip',default='fase3/Fase3_retornos_25_20261117.zip')
    args=p.parse_args()
    execute(args.combined,args.out,args.zip)

if __name__=='__main__':main()
