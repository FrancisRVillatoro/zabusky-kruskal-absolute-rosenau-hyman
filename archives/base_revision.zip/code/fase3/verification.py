"""Fase 3: reproducible analytic/numerical verification (CPU node only).
Run: python3 -m fase3.verification --out fase3/results/verification.json
No long recurrence simulation is attempted in this script.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import platform
import sys
import time
import numpy as np
import scipy
import h5py
from scipy import sparse
from absk_radau.model import PeriodicAbsK, make_initial_data, domain_length
from absk_radau.radau_mass import MassRadau5, NewtonOptions, integrate


def spectral_derivative(u, L, order):
    n = u.size
    k = 2*np.pi*np.fft.fftfreq(n,d=L/n)
    return np.fft.ifft((1j*k)**order*np.fft.fft(u)).real


def manufactured_defect(n, nu=0.0, p=2.25):
    """Defect in A*u_t = F_h(u)+A*g, g chosen from the continuum PDE.

    Strictly positive smooth manufactured profile, not an unforced solution.
    Analytical time derivative and independent Fourier differentiation.
    """
    m=PeriodicAbsK(n,2*np.pi,p,nu)
    x=m.x
    t=.27
    phase=2*x-.7*t
    psi=3*x+.4*t
    u=.8+.1*np.cos(phase)+.05*np.sin(psi)
    ut=.07*np.sin(phase)+.02*np.cos(psi)
    f=m.flux(u)
    source=ut+spectral_derivative(f,m.L,1)+spectral_derivative(f,m.L,3)+nu*spectral_derivative(u,m.L,4)
    defect=m.mass@ut-m.rhs(u)-m.mass@source
    return float(np.sqrt(m.dx*np.dot(defect,defect)))


def fourth_order_viscosity_error(n):
    m=PeriodicAbsK(n,2*np.pi,2.,nu=.01)
    u=.3*np.cos(2*m.x)+.12*np.sin(3*m.x)
    ref=(2**4)*.3*np.cos(2*m.x)+(3**4)*.12*np.sin(3*m.x)
    e=m.Q2@u-ref
    return float(np.sqrt(m.dx*np.dot(e,e)))


def smooth_time_order():
    model=PeriodicAbsK(64,domain_length(2.25,4),2.25)
    u0=.8+.15*np.cos(2*np.pi*model.x/model.L)
    dtlist=[.5,.25,.125,.0625,.03125]
    y=[]
    results=[]
    for dt in dtlist:
        solver=MassRadau5(model,NewtonOptions(atol=1e-14,rtol=1e-13,max_iter=16,predictor='euler'))
        _,values,stats=integrate(solver,u0,5.,dt,save_every=1_000_000,fixed_failure_policy='abort')
        assert stats.rejected_newton == 0
        y.append(values[-1])
        results.append({'dt':dt,'max_scaled_residual':stats.max_scaled_residual,'accepted':stats.accepted})
    errors=[float(np.linalg.norm(z-y[-1])/np.linalg.norm(u0)) for z in y[:-1]]
    ratios=[errors[i]/errors[i+1] for i in (0,1)]  # do not fit the round-off plateau
    assert all(25 < x < 40 for x in ratios), f'Expected 5th order in smooth regime, got {ratios}'
    return {'dt':dtlist,'errors_vs_dt_0.03125':errors,'ratios_reliable':ratios,'runs':results,
            'warning':'Finite reference and algebraic roundoff limit finest-step ratios.'}


def isolated_compacton_error(n, *, sign=1.):
    """Short travelling p=2 compacton; limited regularity, no order-4 claim."""
    p=2.; c=.75
    model=PeriodicAbsK(n,domain_length(2.,4),p)
    radius=math.pi*p/(p-1.)
    beta=(p-1.)/(2*p)
    amp=(2*p*c/(p+1.))**(1/(p-1.))
    def profile(t):
        xi=((model.x-model.L/2-c*t+model.L/2)%model.L)-model.L/2
        z=np.maximum(np.cos(beta*xi),0.)
        return sign*amp*np.where(np.abs(xi)<=radius,z**(2/(p-1.)),0.)
    y0=profile(0.)
    solver=MassRadau5(model,NewtonOptions(atol=1e-12,rtol=1e-10,max_iter=18,predictor='euler'))
    y=y0.copy()
    for _ in range(50):
        y,diag=solver.step(y,.01)
    return float(np.linalg.norm(y-profile(.5))/np.linalg.norm(y0))


def algebraic_and_structure():
    m=PeriodicAbsK(64,domain_length(2.25,4),2.25)
    u=make_initial_data(m,'Z')
    mean_rhs=float(np.sum(m.velocity(u))*m.dx)
    lp_rhs=float(m.lp_balance_rhs(u))
    norm_k=float(sparse.linalg.norm((m.K+m.K.T).tocsr()))
    norm_a=float(sparse.linalg.norm((m.mass-m.mass.T).tocsr()))
    assert abs(mean_rhs)<1e-9, mean_rhs
    assert abs(lp_rhs)<1e-9, lp_rhs
    assert norm_k<1e-10 and norm_a<1e-10
    solver=MassRadau5(m,NewtonOptions(atol=1e-12,rtol=1e-10,predictor='euler'),project_half=True)
    u1,diag=solver.step(u,0.01)
    assert diag.norm_residual <=1.,diag.norm_residual
    assert m.normalized_halfwave_defect(u1)<1e-12
    return {'mean_derivative':mean_rhs,'lp_balance_unregularized':lp_rhs,
            'K_plus_KT_fro':norm_k,'A_minus_AT_fro':norm_a,
            'sample_scaled_newton_residual':diag.norm_residual,
            'halfwave_defect':m.normalized_halfwave_defect(u1)}


def run():
    start=time.monotonic()
    result={'status':'NOT_FINISHED','environment':{'python':sys.version.split()[0],
        'numpy':np.__version__,'scipy':scipy.__version__,'h5py':h5py.__version__,
        'platform':platform.platform()},'checks':{}}
    result['checks']['operators']=algebraic_and_structure()
    for nu in (0.,.003):
        vals=[manufactured_defect(n,nu=nu) for n in (32,64,128,256)]
        ratios=[vals[i]/vals[i+1] for i in range(3)]
        assert all(v>12 for v in ratios), f'Unexpected spatial convergence nu={nu}: {ratios}'
        result['checks'][f'smooth_manufactured_nu_{nu}']={'N':[32,64,128,256],
            'mass_form_defect_L2':vals,'refinement_ratios':ratios,
            'meaning':'manufactured residual; not an unforced PDE trajectory'}
    vals=[fourth_order_viscosity_error(n) for n in (32,64,128,256)]
    ratios=[vals[i]/vals[i+1] for i in range(3)]
    assert all(v>13 for v in ratios), f'Viscosity stencil fourth-order check failed: {ratios}'
    result['checks']['regularizer_Q2']={'N':[32,64,128,256],
        'error_L2':vals,'refinement_ratios':ratios}
    result['checks']['smooth_time_order_5']=smooth_time_order()
    ep=[isolated_compacton_error(n) for n in (128,256,512)]
    rn=[ep[i]/ep[i+1] for i in (0,1)]
    assert all(v>2 for v in rn),f'Compacton profile does not improve: {rn}'
    en=isolated_compacton_error(128,sign=-1.)
    assert abs(en-ep[0])<1e-9
    result['checks']['isolated_compacton_low_regularity']={
        'N':[128,256,512], 'p':2, 'c':.75, 'T':.5,
        'relative_profile_errors':ep,'refinement_ratios':rn,
        'anticompacton_error_N128':en,
        'warning':'Limited regularity: no claim of formal order five/fourth in this test'}
    result['elapsed_seconds']=time.monotonic()-start
    result['status']='PASSED'
    return result


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',default='fase3/results/verification.json')
    args=p.parse_args()
    result=run()
    out=Path(args.out)
    out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():
        raise FileExistsError(f'No se sobrescribe una verificación anterior: {out}')
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    for k,v in result['checks'].items():
        print(k, v.get('refinement_ratios',v.get('ratios_reliable','OK')))
    print('FASE3_VERIFICACION_OK',str(out))

if __name__=='__main__':
    main()
