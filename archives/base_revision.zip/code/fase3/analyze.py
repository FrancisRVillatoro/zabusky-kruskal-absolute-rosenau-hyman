"""Fase 3 error budget, field-wise comparisons on EXACT shared output times.

Does not assert convergence or well-posedness from completed jobs.
Requires 26 COMPLETED phase3 production files, else stops with missing names.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
import numpy as np
import h5py
from scipy.signal import find_peaks
from .design import read_manifest


def load_run(row, folder):
    file=Path(folder)/(row['run_id']+'.h5')
    auditfile=Path(folder)/(row['run_id']+'.audit.json')
    if not file.exists() or not auditfile.exists():
        raise FileNotFoundError(str(file)+' or '+str(auditfile))
    with h5py.File(file,'r') as h:
        if h.attrs['status']!='COMPLETED':
            raise ValueError('INCOMPLETE '+str(file))
        config=json.loads(h.attrs['config_json'])
        data={'u':h['u'][:], 't':h['t'][:], 'x':h['x'][:],
              'd':h['diagnostics'][:], 'stats':json.loads(h.attrs['run_stats_json']),
              'N':int(row['N']), 'Tcross':float(row['T_cross']),
              'L':float(h.attrs['period']), 'row':row,
              'config':config}
    if not np.all(np.isfinite(data['u'])):raise ValueError('Nonfinite fields '+str(file))
    return data


def difference(a,b,align=False):
    """Difference of fields on common grid/time; a and b may differ by ×2 N.

    Smooth interpolations are NOT used. If b is finer by factor 2, subsample.
    """
    if b['N']==2*a['N']:
        bfield=b['u'][:,::2]
    elif b['N']==a['N']:
        bfield=b['u']
    else:raise ValueError('Grid ratio must be 1 or 2 and input ordered coarse then fine')
    assert bfield.shape==a['u'].shape,(a['row']['run_id'],b['row']['run_id'])
    if not np.allclose(a['t']/a['Tcross'],b['t']/b['Tcross'],atol=2e-10,rtol=0):
        raise ValueError('Output times do not align')
    # Normalized discrete L² difference using the same coarse grid.
    scale=np.linalg.norm(a['u'][0])
    if scale<=0.:raise ValueError('Zero initial norm')
    delta=np.linalg.norm(bfield-a['u'],axis=1)/scale
    assert np.all(np.isfinite(delta))
    return delta


def summarize_difference(a,b):
    delta=difference(a,b)
    tau=a['t']/a['Tcross']
    values={f'tau_{q:g}':float(delta[np.argmin(abs(tau-q))]) if q<=tau[-1]+1e-9 else None
            for q in (.25,.5,1.,1.25,1.5,2.)}
    return dict(first=float(delta[0]),final=float(delta[-1]),
                max=float(delta.max()),rms=float(np.sqrt(np.mean(delta**2))),
                times=values,curve=[float(x) for x in delta])


def observed_order(coarse_diff,fine_diff):
    # Observed at end; only meaningful if both differences are in an asymptotic regime.
    if coarse_diff<=0 or fine_diff<=0:return None
    return float(math.log(coarse_diff/fine_diff,2))


def returns(u):
    tau=u['t']/u['Tcross']
    d=u['d'][:,5]
    if not np.all(np.isfinite(d)):return []
    # Candidate local minima only. No invented minima at endpoints.
    indices,_=find_peaks(-d,prominence=.012,distance=3)
    indices=[int(i) for i in indices if tau[i]>=.2]
    return [{'tau_sampled':float(tau[i]),'D_cont_sampled':float(d[i]),
             'r':float(u['d'][i,8]),'Phi1':float(u['d'][i,7]),'H_high':float(u['d'][i,9])}
            for i in indices[:25]]


def analyze(manifest,folder):
    rows=read_manifest(manifest)
    missing=[]
    for row in rows:
        if not (Path(folder)/(row['run_id']+'.h5')).exists() or not (Path(folder)/(row['run_id']+'.audit.json')).exists():
            missing.append(row['run_id'])
    if missing:
        raise RuntimeError('FASE3_INCOMPLETA: faltan '+str(len(missing))+' resultados:\n'+'\n'.join(missing))
    results={r['run_id']:load_run(r,folder) for r in rows}
    cases=sorted(set(r['case'] for r in rows))
    summary=[]
    curves=[]
    full_report={'status':'ANALIZADO_NO_ES_PRUEBA_DE_CONVERGENCIA',
                 'caveats':['Diferencias entre mallas no son cotas rigurosas',
                            'Orden observado sólo interpretable en régimen asintótico',
                            'Los mínimos están muestreados cada 0.01 en tau',
                            'Tasa de separación y regularización a nu->0 se estudiarán después'],
                 'comparisons':{}}
    for case in cases:
        by_role={r['role']:results[r['run_id']] for r in rows if r['case']==case}
        mandatory=['space_low','space_mid','space_high','time_x2','time_x4']
        if not all(role in by_role for role in mandatory):continue
        low,mid,high=map(by_role.get,('space_low','space_mid','space_high'))
        t2,t4=by_role['time_x2'],by_role['time_x4']
        sc1=summarize_difference(low,mid);sc2=summarize_difference(mid,high)
        ti1=summarize_difference(t4,t2);ti2=summarize_difference(t2,high)
        order_space=observed_order(sc1['final'],sc2['final'])
        order_time=observed_order(ti1['final'],ti2['final'])
        rec=returns(high)
        Ip=high['d'][:,2]
        mass=high['d'][:,1]
        base=dict(case=case,Nlow=low['N'],Nmid=mid['N'],Nhigh=high['N'],
                  nu=high['row']['nu'],tau_end=high['row']['tau_end'],
                  spatial_low_mid_final=sc1['final'],spatial_mid_high_final=sc2['final'],
                  spatial_order_end=order_space,
                  time_4dt_2dt_final=ti1['final'],time_2dt_dt_final=ti2['final'],
                  time_order_end=order_time,
                  Ip_rel_drift=float(abs(Ip[-1]-Ip[0])/max(abs(Ip[0]),1e-300)),
                  mass_abs_drift=float(abs(mass[-1]-mass[0])),
                  max_newton_rms=float(high['stats']['max_scaled_residual']),
                  max_halfwave=float(np.max(high['d'][:,4])),
                  num_local_return_candidates=len(rec),
                  best_sampled_return_tau=(min(rec,key=lambda z:z['D_cont_sampled'])['tau_sampled'] if rec else None),
                  best_sampled_return_D=(min(rec,key=lambda z:z['D_cont_sampled'])['D_cont_sampled'] if rec else None))
        if 'newton_strict' in by_role:
            alg=summarize_difference(high,by_role['newton_strict'])
            base['algebraic_default_strict_final']=alg['final']
            full_report['comparisons'][case+'_algebraic']=dict(**{k:v for k,v in alg.items() if k!='curve'})
            curves.append((case,'algebraic_tight_default',high['t']/high['Tcross'],alg['curve']))
        summary.append(base)
        full_report['comparisons'][case]=dict(
            spatial_low_mid={k:v for k,v in sc1.items() if k!='curve'},
            spatial_mid_high={k:v for k,v in sc2.items() if k!='curve'},
            temporal_4dt_2dt={k:v for k,v in ti1.items() if k!='curve'},
            temporal_2dt_dt={k:v for k,v in ti2.items() if k!='curve'},
            observed_spatial_end=order_space,observed_temporal_end=order_time,
            returns_sampled=rec,
            N=[low['N'],mid['N'],high['N']],
            dt=[float(t4['row']['dt']),float(t2['row']['dt']),float(high['row']['dt'])],
            note='Time and space refinement at fixed independent parameter axes')
        tau=high['t']/high['Tcross']
        for nm,vec in [('spatial_low_mid',sc1['curve']),('spatial_mid_high',sc2['curve']),
                       ('temporal_4dt_2dt',ti1['curve']),('temporal_2dt_dt',ti2['curve'])]:
            curves.append((case,nm,tau,vec))
    regs={r['role']:results[r['run_id']] for r in rows if r['role'].startswith('regularized_')}
    if len(regs)==3:
        reglow=regs['regularized_N256'];regmid=regs['regularized_N512'];reghi=regs['regularized_N1024']
        v1=summarize_difference(reglow,regmid);v2=summarize_difference(regmid,reghi)
        full_report['regularization_nu_1e-4']={
           'spatial_256_512_final':v1['final'],
           'spatial_512_1024_final':v2['final'],
           'observed_order_end':observed_order(v1['final'],v2['final']),
           'status':'Preliminary fixed nu check, not zero-viscosity limit'}
    return summary,curves,full_report


def write_report(outdir,summary,curves,report):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    path=outdir/'error_budget.csv'
    with path.open('w',newline='') as fh:
        cols=[]
        for row in summary:
            for k in row:
                if k not in cols:cols.append(k)
        w=csv.DictWriter(fh,fieldnames=cols);w.writeheader();w.writerows(summary)
    with (outdir/'error_curves.csv').open('w',newline='') as fh:
        w=csv.writer(fh);w.writerow(['case','comparison','tau','normalized_L2_difference'])
        for case,name,taus,delta in curves:
            for t,e in zip(taus,delta):w.writerow([case,name,f'{t:.12g}',f'{e:.17g}'])
    (outdir/'error_budget.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    with (outdir/'README_RESULTADOS.txt').open('w') as fh:
        fh.write('Diferencias en L² entre discretizaciones, NO estimaciones rigurosas de error de la PDE.\n')
        fh.write('Las comparaciones de tiempo usan el mismo N alto; las espaciales usan el mismo dt pequeño.\n')
        fh.write('Todas las curvas comparten tiempos tau sin interpolación temporal.\n')
        fh.write('Los retornos se han detectado sólo sobre la cuadrícula de salida, paso 0.01 tau.\n')
    print('FASE3_POSTPROCESO_OK',len(summary),'casos fundamentales',outdir)
    print(json.dumps(summary,indent=2,allow_nan=False))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--manifest',default='fase3/campaign_main.csv')
    p.add_argument('--results',default='fase3/results/main')
    p.add_argument('--out',default='fase3/results/analysis')
    args=p.parse_args()
    summary,curves,report=analyze(args.manifest,args.results)
    if len(summary)!=4:
        raise RuntimeError(f'Se esperaban 4 casos completos, se obtuvieron {len(summary)}')
    write_report(args.out,summary,curves,report)

if __name__=='__main__':main()
