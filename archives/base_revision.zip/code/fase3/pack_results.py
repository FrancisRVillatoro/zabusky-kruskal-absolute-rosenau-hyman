"""Pack ONLY small scientific reports and audits, not raw HDF5 trajectories."""
from __future__ import annotations
import argparse
from pathlib import Path
import zipfile


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',default='fase3/Fase3_CNSNS_resultados_20261117.zip')
    args=p.parse_args()
    out=Path(args.out)
    if out.exists():raise FileExistsError(f'No sobrescribir paquete existente: {out}')
    paths=[]
    for name in ('fase3/README.md','fase3/campaign_main.csv','fase3/campaign_pilot.csv',
                 'fase3/results/analysis/error_budget.csv',
                 'fase3/results/analysis/error_curves.csv',
                 'fase3/results/analysis/error_budget.json',
                 'fase3/results/analysis/README_RESULTADOS.txt'):
        if not Path(name).exists():raise FileNotFoundError('Falta resultado '+name)
        paths.append(Path(name))
    checks={
      'main audits':('fase3/results/main/*.audit.json',26),
      'pilot audits':('fase3/results/pilot/*.audit.json',4),
      'verification':('fase3/results/verification_picasso_*.json',1),
    }
    for key,(pat,count) in checks.items():
        found=sorted(Path('.').glob(pat))
        if len(found)!=count and (key!='verification' or len(found)<1):
            raise RuntimeError(f'{key}: se esperaban {count}; encontrados {len(found)}')
        paths.extend(found)
    # Logs help audit failures/warnings without copying thousands of snapshots.
    paths.extend(sorted(Path('fase3/logs').glob('*.out')))
    paths.extend(sorted(Path('fase3/logs').glob('*.err')))
    with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in paths:z.write(path,arcname=str(path))
    with zipfile.ZipFile(out,'r') as z:
        err=z.testzip()
        if err:raise RuntimeError('ZIP integrity failure: '+err)
    print('FASE3_PAQUETE_OK',out,'files',len(paths))

if __name__=='__main__':main()
