"""Deterministic 4-case, 20+2+3-run phase-3 design.

All trajectories of a given case share EXACTLY the same output times:
  tau_out = 0.01; dt * save_every = T_cross * tau_out.
Temporal refinements vary only dt; spatial refinements vary only N.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from absk_radau.model import crossing_time

TAU_OUT=.01
TARGET_DT=.02
CASES=[
    dict(case='P_p2_M4',p=2.,M=4,family='P',project_half=0,N=[500,1000,2000],tau_end=2.00),
    dict(case='Z_p2_M4',p=2.,M=4,family='Z',project_half=0,N=[500,1000,2000],tau_end=1.50),
    dict(case='Z_p225_M4',p=2.25,M=4,family='Z',project_half=1,N=[450,900,1800],tau_end=1.25),
    dict(case='Z_p2_M8',p=2.,M=8,family='Z',project_half=1,N=[1000,2000,4000],tau_end=1.25),
]
FIELDS=['task_id','run_id','case','group','role','p','M','family','project_half','N',
        'nu','tau_end','tau_out','T_cross','save_every','dt','newton_atol',
        'newton_rtol','newton_max_iter','max_steps']


def substeps(case):
    # Divisible by 4. Thus dt doubles/quadruples on comparison runs.
    return 4*math.ceil(crossing_time(case['p'],case['M'],1.)*TAU_OUT/TARGET_DT/4)


def row(case,role,N,nsteps,tau_end=None,nu=0.,strict=False,group='main'):
    tcr=crossing_time(case['p'],case['M'],1.)
    end=case['tau_end'] if tau_end is None else tau_end
    assert abs(end/TAU_OUT-round(end/TAU_OUT))<1e-9
    assert nsteps>0 and int(nsteps)==nsteps
    dt=tcr*TAU_OUT/nsteps
    est=int(round(end/TAU_OUT))*nsteps
    return dict(run_id=f"{case['case']}__{role}",case=case['case'],group=group,role=role,
         p=case['p'],M=case['M'],family=case['family'],project_half=case['project_half'],
         N=N,nu=nu,tau_end=end,tau_out=TAU_OUT,T_cross=tcr,save_every=nsteps,dt=dt,
         newton_atol=1e-13 if strict else 1e-11,
         newton_rtol=1e-11 if strict else 1e-9,
         newton_max_iter=16 if strict else 12,max_steps=max(200_000,est+100))


def make_campaigns():
    pilot=[]; main=[]
    for case in CASES:
        k=substeps(case)
        assert k%4==0
        pilot.append(row(case,'pilot',case['N'][1],k,tau_end=.10,group='pilot'))
        main += [row(case,'space_low',case['N'][0],k),
                 row(case,'space_mid',case['N'][1],k),
                 row(case,'space_high',case['N'][2],k),
                 row(case,'time_x2',case['N'][2],k//2),
                 row(case,'time_x4',case['N'][2],k//4)]
        if case['case'] in ('Z_p2_M4','Z_p225_M4','Z_p2_M8'):
            main.append(row(case,'newton_strict',case['N'][2],k,strict=True))
    reg=CASES[0]
    k=substeps(reg)
    for n in (256,512,1024):
        main.append(row(reg,f'regularized_N{n}',n,k,tau_end=.25,nu=1.e-4))
    assert len(main)==26 and len(pilot)==4
    for name,rows in [('pilot',pilot),('main',main)]:
        ids=[x['run_id'] for x in rows]
        assert len(set(ids))==len(ids),(name,ids)
        for i,x in enumerate(rows,1):x['task_id']=i
    return pilot,main


def write_csv(path,rows):
    out=Path(path);out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():
        raise FileExistsError(f'No se sobreescribe el plan existente: {out}')
    with out.open('w',newline='',encoding='utf-8') as fh:
        wr=csv.DictWriter(fh,fieldnames=FIELDS)
        wr.writeheader();wr.writerows(rows)
    return hashlib.sha256(out.read_bytes()).hexdigest()


def read_manifest(path):
    with open(path,newline='',encoding='utf-8') as fh:
        rows=list(csv.DictReader(fh))
    if len(rows)!=len(set(x['run_id'] for x in rows)):
        raise ValueError('Duplicated run_id')
    if [int(x['task_id']) for x in rows]!=list(range(1,len(rows)+1)):
        raise ValueError('Nonconsecutive task_id')
    return rows


def main():
    a=argparse.ArgumentParser()
    a.add_argument('--directory',default='fase3')
    args=a.parse_args()
    pilot,main=make_campaigns()
    for nm,rows in (('pilot',pilot),('main',main)):
        path=Path(args.directory)/f'campaign_{nm}.csv'
        digest=write_csv(path,rows)
        print(f'{nm}: {len(rows)} casos; SHA256 {digest}; {path}')
    print('FASE3_DISENO_OK: 4 piloto + 20 refinamientos + 3 Newton estrictos + 3 regularizados')

if __name__=='__main__': main()
