from __future__ import annotations
import tempfile
import unittest
from pathlib import Path
from dataclasses import replace
import numpy as np
from absk_radau.model import PeriodicAbsK,make_initial_data,crossing_time
from absk_radau.radau_mass import MassRadau5,NewtonOptions,RunStats
from absk_radau.io import H5Recorder
from fase3.rescate.repair import recover_one,prepare_prefix
from fase3.rescate.inspect import summarize

class Tests(unittest.TestCase):
    def test_resume_checkpoint_no_dt_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            temp=Path(temp)
            n=64;p=2.; M=4; dt=.002; sub=2; blocks=4
            tc=crossing_time(p,M,1.)
            row=dict(N=str(n),dt=str(dt),save_every=str(sub),tau_end=str((blocks*sub*dt)/tc),
                     tau_out=str((sub*dt)/tc),T_cross=str(tc),max_steps='100',p=str(p),M=str(M),
                     nu='0',family='P',project_half='0',newton_atol='1e-11',
                     newton_rtol='1e-9',newton_max_iter='12',run_id='synthetic')
            model=PeriodicAbsK(n,2*np.pi*M*p/(p-1),p,0.)
            solver=MassRadau5(model,NewtonOptions(predictor='euler'))
            u=make_initial_data(model,'P',1.)
            orig=temp/'original.h5';rec=H5Recorder(orig,model,dict(row,run_id='synthetic'),'P',1.)
            stats=RunStats()
            rec(0.,u,stats)
            for k in range(1,5):
                u,d=solver.step(u,dt);stats.add_step(d,dt);stats.final_time=k*dt
                rec.on_step(k*dt,dt,d,'accepted',float('nan'))
                if k%sub==0:rec(k*dt,u,stats)
            rec.fail(RuntimeError('intentional stop for regression'))
            t,fields,logs,k0,cfg=prepare_prefix(orig,row)
            self.assertEqual(k0,4)
            self.assertEqual(len(t),3)
            dest=temp/'recovered.h5'
            audit=recover_one(row,orig,dest)
            self.assertEqual(audit['steps'],8)
            self.assertEqual(audit['nrecovered_steps'],4)
            self.assertTrue(audit['dt_changed'] is False)
            self.assertTrue(audit['status']=='RECOVERED_FIXED_DT')
            self.assertTrue(dest.exists())
            self.assertTrue(dest.with_suffix('.audit.json').exists())
            self.assertEqual(summarize('missing',temp)['status'],'MISSING_HDF5')

if __name__=='__main__':unittest.main()
