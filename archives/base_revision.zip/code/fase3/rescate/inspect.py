"""Inspect partial Phase 3 without pretending to have 26 completed results."""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
import h5py
import numpy as np
from fase3.design import read_manifest
from fase3.analyze import load_run, summarize_difference

COMPARISONS=(('space_low_vs_mid','space_low','space_mid'),
             ('space_mid_vs_high','space_mid','space_high'),
             ('time_x4_vs_x2','time_x4','time_x2'),
             ('time_x2_vs_small','time_x2','space_high'),
             ('algebraic_default_vs_strict','space_high','newton_strict'))

def summarize(run_id,folder):
    p=Path(folder)/(run_id+'.h5')
    a=Path(folder)/(run_id+'.audit.json')
    if not p.exists():return dict(status='MISSING_HDF5')
    try:
        with h5py.File(p,'r') as h:
            status=str(h.attrs['status'])
            t=np.asarray(h['t'][:]);d=np.asarray(h['diagnostics'][:]);
            uend=h['u'][-1] if len(t) else np.array([])
            logs=h['step_log'][:] if 'step_log' in h else np.zeros((0,8))
            cfg=json.loads(h.attrs['config_json'])
            tc=float(cfg['T_cross']);
            inv0=d[0,2] if len(d) else np.nan
            inv_end=d[-1,2] if len(d) else np.nan
            return dict(status=status,audit_exists=a.exists(),snapshots=len(t),
                   accepted_log_steps=int(np.sum(logs[:,7]==1)) if len(logs) else 0,
                   last_saved_tau=float(t[-1]/tc) if len(t) else None,
                   drift_I_relative=float(abs(inv_end-inv0)/max(abs(inv0),1e-300)) if len(d) else None,
                   last_D_cont=float(d[-1,5]) if len(d) and np.isfinite(d[-1,5]) else None,
                   last_H_high=float(d[-1,9]) if len(d) and np.isfinite(d[-1,9]) else None,
                   last_abs_u_max=float(np.max(np.abs(uend))) if len(uend) else None,
                   failure_reason=str(h.attrs.get('failure_reason','')),
                   last_newton_scaled_rms=float(np.max(logs[:,4])) if len(logs) else None)
    except Exception as exc:
        return dict(status='CORRUPT_OR_UNREADABLE',failure_reason=f'{type(exc).__name__}: {exc}')


def report(manifest,source,recovered,out):
    rows=read_manifest(manifest)
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    records=[]; usable={}
    for row in rows:
        rid=row['run_id']
        original=summarize(rid,source)
        recov=summarize(rid,recovered)
        if original.get('status')=='COMPLETED' and original.get('audit_exists'):
            location=source
        elif recov.get('status')=='COMPLETED' and recov.get('audit_exists'):
            location=recovered
        else: location=None
        record=dict(index=int(row['task_id']),run_id=rid,case=row['case'],role=row['role'],
                    N=int(row['N']),dt=float(row['dt']),source_selected=location or '',
                    original=original, recovery=recov)
        records.append(record)
        if location:
            usable[rid]=load_run(row,location)
    comparisons=[]
    for case in sorted({r['case'] for r in rows}):
        byrole={r['role']:usable[r['run_id']] for r in rows if r['case']==case and r['run_id'] in usable}
        for title,a,b in COMPARISONS:
            if a not in byrole or b not in byrole:continue
            try:
                comp=summarize_difference(byrole[a],byrole[b])
                comparisons.append(dict(case=case,comparison=title,normalized_final=comp['final'],
                                        normalized_max=comp['max'],normalized_rms=comp['rms'],
                                        comparison_values=comp['times']))
            except Exception as exc:
                comparisons.append(dict(case=case,comparison=title,error=str(exc)))
    finished=[r for r in records if r['source_selected']]
    data={'status':'PARTIAL_DIAGNOSTIC_NOT_FULL_PHASE3',
          'total':len(rows),'complete':len(finished),'missing':len(rows)-len(finished),
          'cases':records,'available_comparisons':comparisons,
          'warning':'FAILED runs are computational failures, not proof of continuum ill-posedness. Newton-globalized recoveries retain dt but use variant nonlinear solve.'}
    (out/'partial_status.json').write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
    with (out/'partial_cases.csv').open('w',newline='') as fh:
        fields=['index','run_id','case','role','N','dt','source_selected','original_status',
                'original_last_tau','original_inv_drift','original_last_D','original_failure',
                'recovery_status','recovery_last_tau','recovery_failure']
        writer=csv.DictWriter(fh,fieldnames=fields);writer.writeheader()
        for r in records:
            a,b=r['original'],r['recovery']
            writer.writerow(dict(index=r['index'],run_id=r['run_id'],case=r['case'],role=r['role'],N=r['N'],
                dt=r['dt'],source_selected=r['source_selected'],original_status=a.get('status'),
                original_last_tau=a.get('last_saved_tau'),original_inv_drift=a.get('drift_I_relative'),
                original_last_D=a.get('last_D_cont'),original_failure=a.get('failure_reason'),
                recovery_status=b.get('status'),recovery_last_tau=b.get('last_saved_tau'),
                recovery_failure=b.get('failure_reason')))
    with (out/'partial_comparisons.csv').open('w',newline='') as fh:
        fields=['case','comparison','normalized_final','normalized_max','normalized_rms','error']
        writer=csv.DictWriter(fh,fieldnames=fields);writer.writeheader()
        for r in comparisons:writer.writerow({k:r.get(k,'') for k in fields})
    print('FASE3_PARCIAL_OK',len(finished),'/',len(rows),'completadas; comparaciones',len(comparisons))
    for r in records:
        if not r['source_selected']:
            print('FALTANTE',r['index'],r['run_id'],'tau_guardado',r['original'].get('last_saved_tau'),
                  'razon',r['original'].get('failure_reason'))
    for c in comparisons:
        print('COMPARACION',c['case'],c['comparison'],c.get('normalized_final',c.get('error')))
    return data


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',default='fase3/campaign_main.csv')
    ap.add_argument('--source',default='fase3/results/main')
    ap.add_argument('--recovered',default='fase3/results/rescue_fixed')
    ap.add_argument('--out',default='fase3/results/analysis_partial')
    a=ap.parse_args(); report(a.manifest,a.source,a.recovered,a.out)
if __name__=='__main__':main()
