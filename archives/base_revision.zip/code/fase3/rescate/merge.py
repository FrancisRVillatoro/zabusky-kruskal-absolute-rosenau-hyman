"""Safe symlink aggregation of original+rescued cases, no copying and no overwrites."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import h5py
from fase3.design import read_manifest


def merge(manifest,original,recovered,dest):
    rows=read_manifest(manifest)
    original=Path(original);recovered=Path(recovered);dest=Path(dest)
    dest.mkdir(parents=True,exist_ok=True)
    if list(dest.iterdir()):
        raise RuntimeError('Destino no vacio, se prohibe alterar enlaces ya existentes: '+str(dest))
    counts={'original':0,'recovered':0,'missing':0}
    missed=[]
    for row in rows:
        name=row['run_id'];selected=None;kind=None
        for folder,tag in ((original,'original'),(recovered,'recovered')):
            hfile=folder/(name+'.h5');afile=folder/(name+'.audit.json')
            if not hfile.exists() or not afile.exists():continue
            with h5py.File(hfile,'r') as h:
                if h.attrs['status']!='COMPLETED':continue
            selected=(hfile,afile);kind=tag
            break
        if selected is None:
            counts['missing']+=1;missed.append(name);continue
        for path in selected:
            (dest/path.name).symlink_to(path.resolve())
        counts[kind]+=1
    (dest/'merge_status.json').write_text(json.dumps({'counts':counts,'missing':missed},indent=2)+'\n')
    print('FASE3_MERGE',counts)
    if counts['missing']:
        print('FASE3_INCOMPLETA_SIGUE',','.join(missed))
    else:
        print('FASE3_MERGE_COMPLETO_OK')
    return counts


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',default='fase3/campaign_main.csv')
    ap.add_argument('--original',default='fase3/results/main')
    ap.add_argument('--recovered',default='fase3/results/rescue_fixed')
    ap.add_argument('--dest',default='fase3/results/combined_fixed')
    a=ap.parse_args();merge(a.manifest,a.original,a.recovered,a.dest)
if __name__=='__main__':main()
