"""Pack a compact Phase-3 rescue audit, excluding HDF5 fields."""
from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib

ROOT=Path('fase3')
PATTERNS=[
 'campaign_main.csv','results/analysis_partial/*',
 'results/analysis_recovered/*','results/combined_fixed/merge_status.json',
 'results/main/*.audit.json','results/rescue_fixed/*.audit.json',
 'results/rescue_fixed/*.failure.json','logs/rescue_*.out','logs/rescue_*.err',
 'logs/diagnose_*.out','logs/diagnose_*.err','logs/audit_rescue_*.out',
 'logs/audit_rescue_*.err','results/verification_picasso_*.json'
]
files=set()
for pat in PATTERNS:
    files.update(p for p in ROOT.glob(pat) if p.is_file() and not p.is_symlink())
files=sorted(files)
output=ROOT/'Fase3_rescate_diagnosticos.zip'
with ZipFile(output,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for f in files:
        z.write(f,arcname=f.as_posix())
print('FASE3_RESCATE_ZIP_OK',output,len(files),'archivos, SHA256',hashlib.sha256(output.read_bytes()).hexdigest())
