"""Auditable Phase-3 recovery and partial-error analysis."""
