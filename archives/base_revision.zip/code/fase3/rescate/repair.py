"""Strict-fixed-dt continuation of FAILED phase-3 trajectories.

Preserves accepted prefix, resumes from last saved HDF5 state, attempts
more robust Newton at EXACTLY the same time step, records fallback use.
DOES NOT use adaptive/halved timesteps. Never overwrites original files.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
import sys
import time
from pathlib import Path
from dataclasses import asdict
import h5py
import numpy as np
import scipy
from absk_radau.model import PeriodicAbsK
from absk_radau.radau_mass import MassRadau5, NewtonOptions, NewtonFailure, RunStats, StepData
from absk_radau.io import H5Recorder
from fase3.design import read_manifest
from fase3.run_case import validate_h5


def prepare_prefix(path, row):
    """Read, validate and return stored snapshots and accepted step prefix."""
    n=int(row['N'])
    dt=float(row['dt'])
    sub=int(row['save_every'])
    with h5py.File(path,'r') as h:
        status=h.attrs['status']
        if status!='INCOMPLETE':
            raise RuntimeError(f'Expected INCOMPLETE original, found {status}: {path}')
        config=json.loads(h.attrs['config_json'])
        if config.get('run_id')!=row['run_id']:
            raise RuntimeError('run_id mismatch between HDF5 and manifest')
        for key in ('N','p','M','nu','family','project_half'):
            expected= row[key] if key=='family' else float(row[key])
            actual=config[key]
            if (str(actual)!=str(expected) if key=='family' else not np.isclose(float(actual),expected,rtol=1e-13,atol=1e-14)):
                raise RuntimeError(f'config mismatch {key}: {actual} != {expected}')
        t=np.asarray(h['t'][:]); fields=np.asarray(h['u'][:]);
        if t.ndim!=1 or t.size<1 or fields.shape!=(t.size,n):
            raise RuntimeError('invalid snapshot shapes')
        if not np.all(np.isfinite(fields)):
            raise RuntimeError('prefix fields nonfinite')
        prefix_steps=(t.size-1)*sub
        ideal=np.arange(t.size,dtype=float)*sub*dt
        if np.max(np.abs(t-ideal))>1e-9*max(1.,abs(t[-1])):
            raise RuntimeError('prefix times do not coincide with integer steps')
        if 'step_log' not in h:
            raise RuntimeError('no accepted step log found in INCOMPLETE HDF5')
        log=np.asarray(h['step_log'][:]);
        if log.ndim!=2 or log.shape[1]!=8 or log.shape[0]<prefix_steps:
            raise RuntimeError('insufficient step log')
        prefix_log=log[:prefix_steps]
        if not np.all(prefix_log[:,7]==1.):
            raise RuntimeError('nonaccepted steps encountered in fixed-prefix log')
        if prefix_steps and np.max(np.abs(prefix_log[:,0]-np.arange(1,prefix_steps+1)*dt))>1e-9*max(1.,t[-1]):
            raise RuntimeError('prefix step times inconsistent')
        if prefix_steps and not np.all(np.isfinite(prefix_log[:,:6])):
            raise RuntimeError('nonfinite prefix log')
        return t,fields,prefix_log,prefix_steps,config


def recover_one(row, source, destination, manifest_hash='test'):
    source=Path(source); destination=Path(destination)
    if destination.exists():
        raise FileExistsError(f'REFUSING overwrite: {destination}')
    t_saved, fields, log, k0, original_config=prepare_prefix(source,row)
    n=int(row['N']); dt=float(row['dt']); sub=int(row['save_every'])
    nblocks=int(round(float(row['tau_end'])/float(row['tau_out'])))
    nsteps=nblocks*sub
    if nsteps>int(row['max_steps']) or k0>nsteps:
        raise RuntimeError('invalid total steps')
    if not np.isclose(nsteps*dt/float(row['T_cross']),float(row['tau_end']),rtol=0,atol=1e-10):
        raise RuntimeError('incompatible final time')
    p=float(row['p']); nu=float(row['nu']); M=float(row['M']); project=bool(int(row['project_half']))
    model=PeriodicAbsK(n,2*np.pi*M*p/(p-1),p,nu)
    cfg=NewtonOptions(atol=float(row['newton_atol']),rtol=float(row['newton_rtol']),
                      max_iter=int(row['newton_max_iter']),line_search_backtracks=10,predictor='euler')
    # Same residual tolerance. Only globalization/predictor/maximum iterations vary.
    hard=NewtonOptions(atol=cfg.atol,rtol=cfg.rtol,max_iter=max(28,cfg.max_iter),
                       line_search_backtracks=20,predictor='euler')
    constant=NewtonOptions(atol=cfg.atol,rtol=cfg.rtol,max_iter=max(28,cfg.max_iter),
                           line_search_backtracks=20,predictor='constant')
    methods=[('original',MassRadau5(model,cfg,project_half=project)),
             ('extended_euler',MassRadau5(model,hard,project_half=project)),
             ('extended_constant',MassRadau5(model,constant,project_half=project))]
    config=dict(original_config)
    config['phase']='fase3_recovery'
    config['driver']='resume_from_original_snapshot_FIXED_DT'
    config['recovery']=dict(source=str(source),stored_prefix_snapshots=len(t_saved),
       prefix_steps=k0,manifest_sha256=manifest_hash,
       same_dt=True, changed_method=False,
       globalization_only=True, algorithms=[name for name,_ in methods],
       max_iterations=[cfg.max_iter,hard.max_iter,constant.max_iter])
    recorder=H5Recorder(destination,model,config,row['family'],1.)
    stats=RunStats(mode='fixed_exact_step_count_with_globalization_recovery')
    n_fallback=0
    fallback_steps=[]
    start=time.perf_counter()
    try:
        # Use validated prefix fields, *not* unverified accepted steps after last snapshot.
        for k in range(k0):
            record=log[k]
            s=StepData(int(record[2]),int(record[3]),float(record[4]),int(record[5]))
            stats.add_step(s,dt)
            stats.final_time=(k+1)*dt
            recorder.on_step(stats.final_time,dt,s,'accepted',float('nan'))
        for ti,ui in zip(t_saved,fields):
            recorder(float(ti),ui,stats)
        u=fields[-1].copy()
        print(f'REANUDACION {row["run_id"]}: ultimo_snapshot_tau={t_saved[-1]/float(row["T_cross"]):.9f} '
              f'prefix={k0} total={nsteps} dt={dt:.12g}',flush=True)
        for k in range(k0+1,nsteps+1):
            failures=[]
            for method_name,solver in methods:
                try:
                    u1,d=solver.step(u,dt)
                    break
                except NewtonFailure as exc:
                    failures.append(f'{method_name}: {exc}')
            else:
                state={'status':'FAILED_FIXED_DT', 'run_id':row['run_id'],
                       'step':k,'t':(k-1)*dt,'tau':(k-1)*dt/float(row['T_cross']),
                       'dt_unchanged':True,'last_successful_saved_tau':t_saved[-1]/float(row['T_cross']),
                       'attempts':failures, 'fallback_steps_so_far':n_fallback,
                       'source_original':str(source)}
                failure_path=destination.with_suffix('.failure.json')
                failure_path.write_text(json.dumps(state,indent=2,allow_nan=False)+'\n')
                raise NewtonFailure(f'FIXED_DT_UNRESOLVED tau={state["tau"]:.9f}: '+'; '.join(failures))
            if method_name!='original':
                n_fallback+=1
                if len(fallback_steps)<100:
                    fallback_steps.append({'step':k,'tau':k*dt/float(row['T_cross']),'variant':method_name})
            u=u1
            stats.add_step(d,dt)
            tn=k*dt
            stats.final_time=tn
            recorder.on_step(tn,dt,d,'accepted',float('nan'))
            if k%sub==0:
                recorder(tn,u,stats)
            if k%max(sub, max(1,nsteps//10))==0:
                print('FASE3_REANUDACION_PROGRESO',row['run_id'],f'{k}/{nsteps}',flush=True)
        recorder.finish(stats)
    except BaseException as exc:
        recorder.fail(exc)
        raise
    audit=validate_h5(destination,row)
    audit.update(run_id=row['run_id'],source_original=str(source),
                 status='RECOVERED_FIXED_DT',dt_changed=False,
                 fallback_steps=int(n_fallback),fallback_samples=fallback_steps,
                 original_prefix_steps=int(k0),newton_tolerance_unchanged=True,
                 nrecovered_steps=nsteps-k0,
                 wall_seconds=time.perf_counter()-start,
                 note='Fixed physical dt unchanged; globalization only. Compare to original runs before use in paper.')
    af=destination.with_suffix('.audit.json')
    if af.exists():raise FileExistsError(f'No se sobreescribe {af}')
    af.write_text(json.dumps(audit,indent=2,allow_nan=False)+'\n')
    print('FASE3_RESCATE_OK',row['run_id'],'fallback',n_fallback,
          'newton_rms',audit['max_scaled_newton_rms'],flush=True)
    return audit


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--index',type=int,required=True)
    ap.add_argument('--manifest',default='fase3/campaign_main.csv')
    ap.add_argument('--source',default='fase3/results/main')
    ap.add_argument('--output',default='fase3/results/rescue_fixed')
    a=ap.parse_args()
    rows=read_manifest(a.manifest)
    if a.index<1 or a.index>len(rows):raise ValueError('index out of range')
    row=rows[a.index-1]
    src=Path(a.source)/(row['run_id']+'.h5')
    dest=Path(a.output)/(row['run_id']+'.h5')
    dest.parent.mkdir(parents=True,exist_ok=True)
    recover_one(row,src,dest,hashlib.sha256(Path(a.manifest).read_bytes()).hexdigest())

if __name__=='__main__': main()
