import unittest
import csv
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
import h5py
import numpy as np
from fase3.design import CASES, TAU_OUT, FIELDS, make_campaigns, substeps
from fase3.verification import manufactured_defect, fourth_order_viscosity_error
from fase3.analyze import difference, observed_order

class TestPhase3(unittest.TestCase):
    def test_manifest_and_output_schedule(self):
        pilot,main=make_campaigns()
        self.assertEqual(len(pilot),4)
        self.assertEqual(len(main),26)
        self.assertEqual(len([r for r in main if r['role'].startswith('space_')]),12)
        self.assertEqual(len([r for r in main if r['role'].startswith('time_')]),8)
        self.assertEqual(len([r for r in main if r['role']=='newton_strict']),3)
        self.assertEqual(len([r for r in main if r['role'].startswith('regularized_')]),3)
        for row in main+pilot:
            self.assertAlmostEqual(row['dt']*row['save_every'],row['T_cross']*TAU_OUT,places=10)
            self.assertEqual(row['N']%2,0)
            self.assertEqual(row['max_steps']>=round(row['tau_end']/TAU_OUT)*row['save_every'],True)

    def test_main_grid_and_timestep_independence(self):
        _,main=make_campaigns()
        for case in CASES:
            by_role={r['role']:r for r in main if r['case']==case['case']}
            self.assertEqual([by_role[r]['N'] for r in ('space_low','space_mid','space_high')],case['N'])
            for role in ('space_low','space_mid','space_high'):
                self.assertAlmostEqual(by_role[role]['dt'],by_role['space_high']['dt'],places=12)
            for role,factor in [('time_x2',2),('time_x4',4)]:
                self.assertEqual(by_role[role]['N'],case['N'][-1])
                self.assertAlmostEqual(by_role[role]['dt'],by_role['space_high']['dt']*factor,places=12)

    def test_manufactured_spatial_order(self):
        for nu in (0,.003):
            e=[manufactured_defect(n,nu) for n in (32,64,128)]
            self.assertGreater(e[0]/e[1],12)
            self.assertGreater(e[1]/e[2],14)

    def test_viscosity_fourth_order(self):
        e=[fourth_order_viscosity_error(n) for n in (32,64,128)]
        self.assertGreater(e[0]/e[1],13)
        self.assertGreater(e[1]/e[2],14)

    def test_difference_exact_common_grid(self):
        # fine grid contains 2N nodes; pairwise error uses injection to coarse.
        a=dict(N=4,u=np.tile([1.,-1.,2.,-2.],(3,1)).astype(float),
               t=np.array([0.,.1,.2]),Tcross=1.,row={'run_id':'test_a'})
        b=dict(N=8,u=np.repeat(a['u'],2,axis=1),
               t=np.array([0.,.1,.2]),Tcross=1.,row={'run_id':'test_b'})
        np.testing.assert_allclose(difference(a,b),np.zeros(3))
        b['u'][:,::2]+=0.1
        np.testing.assert_allclose(difference(a,b),0.1*np.sqrt(4)/np.sqrt(10)*np.ones(3))
        b['t'][-1]+=.1
        with self.assertRaises(ValueError):difference(a,b)

    def test_exact_step_count_regression_no_microstep(self):
        # Regression for stage-2 tiny final step at p=2.25 after ~320 steps.
        pilot,_=make_campaigns()
        row=dict(pilot[2]);row['N']=64;row['task_id']=1
        with tempfile.TemporaryDirectory() as tmp:
            manifest=Path(tmp)/'tiny_campaign.csv'
            with manifest.open('w',newline='') as fh:
                writer=csv.DictWriter(fh,fieldnames=FIELDS)
                writer.writeheader();writer.writerow(row)
            out=Path(tmp)/'outputs'
            result=subprocess.run([sys.executable,'-m','fase3.run_case','--manifest',str(manifest),
                '--index','1','--output',str(out)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stdout+'\n'+result.stderr)
            with h5py.File(out/(row['run_id']+'.h5'),'r') as h:
                stats=json.loads(h.attrs['run_stats_json'])
                self.assertEqual(h['t'].shape[0],11)
                self.assertEqual(stats['accepted'],320)
                self.assertEqual(h['step_log'].shape[0],320)
                self.assertAlmostEqual(stats['min_accepted_dt'],float(row['dt']),places=12)
                tau=h['t'][:]/float(row['T_cross'])
                np.testing.assert_allclose(tau,np.arange(11)*.01,rtol=0,atol=2e-14)

    def test_budget_order_definition(self):
        self.assertAlmostEqual(observed_order(1/16,1/256),4.)
        self.assertIsNone(observed_order(0.,1.))

if __name__=='__main__':unittest.main()
