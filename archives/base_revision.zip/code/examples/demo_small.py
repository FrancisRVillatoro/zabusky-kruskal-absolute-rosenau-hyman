"""Very small smooth test: python examples/demo_small.py"""
from absk_radau import PeriodicAbsK, MassRadau5, NewtonOptions, integrate
from absk_radau.model import make_initial_data

model=PeriodicAbsK(n=32,L=50.2654824574,p=2.,nu=1.e-4)
u0=make_initial_data(model,'P')
solver=MassRadau5(model,NewtonOptions(atol=1.e-11,rtol=1.e-9))
t,uh,stats=integrate(solver,u0,t_end=.05,dt=.005,save_every=2)
print('mass initial/final:',model.mass_integral(u0),model.mass_integral(uh[-1]))
print('invariant initial/final:',model.lp_invariant(u0),model.lp_invariant(uh[-1]))
print('time points:',t)
print('stats:',stats)
