"""Optional Matplotlib plots for CNSNS phase 4. Never required by the Slurm solver."""
from __future__ import annotations
import csv
from pathlib import Path
import numpy as np


def read_table(path):
    with Path(path).open(newline='',encoding='utf8') as f:
        return list(csv.DictReader(f))


def produce_figures(outdir,timeline,returns,N):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    outdir=Path(outdir)
    Ns=sorted(timeline)
    # Figure 1: full recurrence and first-return inset range.
    fig,ax=plt.subplots(figsize=(9,4.5))
    for n in Ns:
        data=timeline[n]
        ax.plot([r['tau'] for r in data],[r['D'] for r in data],lw=1.1,label=f'N={n}')
    ax.set(xlabel=r'Normalized time $\tau$',ylabel=r'$D_{\rm rec}(\tau)$',title='Relative recurrence modulo translations')
    ax.set_xlim(0,max(r['tau'] for r in timeline[N]));ax.legend();ax.grid(alpha=.2)
    fig.tight_layout();fig.savefig(outdir/'Fig4_Recurrence_overview.pdf');fig.savefig(outdir/'Fig4_Recurrence_overview.png',dpi=160);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.2,4.5))
    for n in Ns:
        data=[r for r in timeline[n] if .975<=r['tau']<=1.045]
        ax.plot([r['tau'] for r in data],[r['D'] for r in data],lw=1.2,label=f'N={n}')
    ax.set(xlabel=r'$\tau$',ylabel=r'$D_{\rm rec}$',title='First return: dense time sampling')
    ax.legend();ax.grid(alpha=.2);fig.tight_layout()
    fig.savefig(outdir/'Fig4_First_return_zoom.pdf');fig.savefig(outdir/'Fig4_First_return_zoom.png',dpi=160);plt.close(fig)
    # Figure 2: selected spectral contents and Phi1 at finest resolution.
    data=timeline[N]
    t=np.asarray([r['tau'] for r in data])
    fig,axes=plt.subplots(2,1,figsize=(9,6.5),sharex=True)
    for key in ('e1','e3','e5','e7'):
        axes[0].plot(t,[r[key] for r in data],lw=1,label=key)
    axes[0].set(ylabel='Squared modal content (relative to initial oscillatory norm)')
    axes[0].legend(ncol=4);axes[0].grid(alpha=.2)
    axes[1].plot(t,[r['Phi1'] for r in data],lw=1.1,label='Phi1')
    axes[1].set(xlabel=r'$\tau$',ylabel=r'$\Phi_1$',ylim=(-.02,1.04))
    axes[1].grid(alpha=.2);fig.tight_layout()
    fig.savefig(outdir/'Fig4_Modal_evolution.pdf');fig.savefig(outdir/'Fig4_Modal_evolution.png',dpi=160);plt.close(fig)
    # Figure 3: actual minima by return index; no line through absent minima.
    fig,ax=plt.subplots(figsize=(7.5,4))
    for n in Ns:
        rr=[r for r in returns if r['N']==n and r['status']=='LOCAL_MIN']
        if rr:
            ax.plot([r['index'] for r in rr],[r['D'] for r in rr],marker='o',lw=1,label=f'N={n}')
    ax.set(xlabel='Return number',ylabel='Minimum sampled recurrence distance',xticks=[1,2,3,4])
    ax.legend();ax.grid(alpha=.2);fig.tight_layout()
    fig.savefig(outdir/'Fig4_Return_sequence.pdf');fig.savefig(outdir/'Fig4_Return_sequence.png',dpi=160);plt.close(fig)
    # Figure 4: profiles at returns, if the output has them.
    profiles=sorted(outdir.glob(f'profile_return*_N{N}.csv'))
    if profiles:
        fig,axs=plt.subplots(len(profiles),1,figsize=(9,3*len(profiles)),sharex=True, squeeze=False)
        for ax,p in zip(axs[:,0],profiles):
            d=read_table(p)
            ax.plot([float(r['x']) for r in d],[float(r['u']) for r in d],label='u(x,t)',lw=1)
            ax.plot([float(r['x']) for r in d],[float(r['u0_opt_shift']) for r in d],label='initial shifted',lw=1,ls='--')
            ax.set_ylabel('u');ax.set_title('Return '+d[0]['index']+', tau='+d[0]['tau']);ax.grid(alpha=.2);ax.legend()
        axs[-1,0].set_xlabel('x');fig.tight_layout()
        fig.savefig(outdir/'Fig4_Profiles_aligned.pdf');fig.savefig(outdir/'Fig4_Profiles_aligned.png',dpi=160);plt.close(fig)
    sp=outdir/f'spacetime_N{N}.csv'
    if sp.exists():
        raw=read_table(sp)
        xs=np.unique([float(r['x']) for r in raw]);ts=np.unique([float(r['tau']) for r in raw])
        Z=np.asarray([float(r['u']) for r in raw]).reshape((len(ts),len(xs)))
        fig,ax=plt.subplots(figsize=(9,4))
        im=ax.imshow(Z.T,aspect='auto',origin='lower',extent=(ts[0],ts[-1],xs[0],xs[-1]),interpolation='nearest')
        ax.set(xlabel=r'$\tau$',ylabel='x',title='Space-time evolution (downsampled from computed fields)')
        fig.colorbar(im,ax=ax,label='u');fig.tight_layout()
        fig.savefig(outdir/'Fig4_Space_time.pdf');fig.savefig(outdir/'Fig4_Space_time.png',dpi=160);plt.close(fig)
