"""CNSNS phase 4: sampled recurrence branches, not continuum proofs."""
