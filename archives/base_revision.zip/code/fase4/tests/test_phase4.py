"""Unit and mini integration tests; synthetic fixtures are NOT scientific results."""
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import h5py

from fase4.continue_radau import (K_PER_TAU,rows_for_case,save_on,
                                   fetch_checkpoint,run_one,validate_output)
from fase4.analyze import (local_returns, modal_rows, outputs)
from absk_radau.model import PeriodicAbsK,make_initial_data


class Phase4Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source_root=Path('fase3/campaign_main.csv')

    def test_manifest_consistency(self):
        r=rows_for_case(self.source_root)
        self.assertEqual([int(r[i]['N']) for i in (1,2,3)],[450,900,1800])
        self.assertEqual(K_PER_TAU,3200)
        self.assertAlmostEqual(float(r[3]['dt'])/float(r[3]['T_cross']),1/K_PER_TAU,places=13)

    def test_output_grid(self):
        self.assertTrue(save_on(100,'zoom1'))
        self.assertTrue(save_on(2*K_PER_TAU,'seg2'))
        self.assertTrue(save_on(2*K_PER_TAU+2,'seg2'))
        self.assertFalse(save_on(2*K_PER_TAU+1,'seg2'))
        self.assertTrue(save_on(40*32,'seg3'))

    def test_local_min_no_fake_boundaries(self):
        rows=[{'tau':t,'D':d,'r':1.,'Phi1':1.,'H':0.,'Qosc':1.,'I_p1':1.,'source':'seg2'}
              for t,d in [(1.76,1.2),(1.81,1.3),(1.93,.25),(2.00,.18),(2.07,.22),(2.2,.28)]]
        r=local_returns(rows,64)
        self.assertEqual(r[1]['status'],'LOCAL_MIN')
        self.assertAlmostEqual(r[1]['tau'],2.)
        self.assertEqual(r[2]['status'],'NO_DATA')

    def test_mini_fixed_step_recovery_and_h5(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp=Path(tmp)
            source=tmp/'fixture.h5'
            row=dict(rows_for_case(self.source_root)[1])
            row['N']='64'
            n=int(row['N']);tc=float(row['T_cross']);dt=float(row['dt'])
            model=PeriodicAbsK(n,2*np.pi*float(row['p'])*float(row['M'])/(float(row['p'])-1),float(row['p']),0.)
            u0=make_initial_data(model,'Z',1.)
            with h5py.File(source,'w') as h:
                h.attrs['status']='COMPLETED'
                h.attrs['n_cells']=n
                h.attrs['config_json']=json.dumps({'run_id':row['run_id'],'p':float(row['p']),
                    'M':float(row['M']),'nu':0.,'family':'Z','project_half':True})
                # Artificial stored checkpoint for pipeline testing only.
                h.create_dataset('t',data=[0.,40*dt])
                h.create_dataset('u',data=np.asarray([u0,u0]))
            self.assertTrue(np.array_equal(fetch_checkpoint(source,row,40),u0))
            dest=tmp/'result.h5'
            report=run_one(row,source,dest,40/K_PER_TAU,72/K_PER_TAU,'segTEST')
            self.assertEqual(report['n_steps'],32)
            self.assertTrue(report['max_scaled_newton_rms']<=1.)
            self.assertTrue((tmp/'result.audit.json').exists())
            with h5py.File(dest,'r') as h:
                self.assertEqual(h.attrs['status'],'COMPLETED')
                self.assertEqual(h['u'].shape[1],n)
                self.assertAlmostEqual(h['t'][-1],72*dt)
            with self.assertRaises(FileExistsError):
                # Different requested end must never overwrite a completed file.
                run_one(row,source,dest,40/K_PER_TAU,73/K_PER_TAU,'segTEST')
            with h5py.File(source,'r') as h:
                self.assertEqual(h.attrs['status'],'COMPLETED')
            # Continue from previous COMPLETED segment; state must match bitwise.
            dest2=tmp/'second.h5'
            report2=run_one(row,dest,dest2,72/K_PER_TAU,88/K_PER_TAU,'segMORE')
            self.assertEqual(report2['n_steps'],16)
            with h5py.File(dest,'r') as a, h5py.File(dest2,'r') as b:
                self.assertTrue(np.array_equal(a['u'][-1],b['u'][0]))
                self.assertEqual(b.attrs['status'],'COMPLETED')

if __name__=='__main__':unittest.main()
