"""Phase 4 scientific postprocessing: sequential recurrence, modes and profiles.

Grounded in validated HDF5 fields (phase-3 and phase-4), not just D(t).
Runs with numpy + h5py; matplotlib is OPTIONAL for images.
Never fills a missing trajectory with an invented extrapolation.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

import h5py
import numpy as np

from .continue_radau import (K_PER_TAU, MAIN, ROLES, rows_for_case, phase3_source,
                              LONG_ENDS)


def csv_out(path, headers, records):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=headers,extrasaction='ignore')
        w.writeheader();w.writerows(records)


def read_h5(path,row):
    with h5py.File(path,'r') as h:
        if h.attrs.get('status')!='COMPLETED':
            raise ValueError('INCOMPLETE H5 '+str(path))
        if int(h.attrs['n_cells']) != int(row['N']):
            raise ValueError('Malla incompatible '+str(path))
        t=np.array(h['t'][:],dtype=float)
        u=np.array(h['u'][:],dtype=float)
        d=np.array(h['diagnostics'][:],dtype=float)
        if u.shape!=(len(t),int(row['N'])) or d.shape!=(len(t),10):
            raise ValueError('Datos sin dimensiones esperadas')
        if not np.all(np.isfinite(u)) or not np.all(np.isfinite(d[:,[1,2,5,7,8,9]])):
            raise ValueError('NaN o Inf en salida')
    tc=float(row['T_cross'])
    indices=np.rint(t/tc*K_PER_TAU).astype(int)
    if not np.all(np.diff(indices)>0) or np.max(np.abs(t/tc-indices/K_PER_TAU))>1e-9:
        raise ValueError('Calendario temporal no exacto')
    return indices,u,d


def consolidate(row,base_dir,phase4_dir):
    src=phase3_source(row,[base_dir/'fase3/results/combined_fixed',
                            base_dir/'fase3/results/rescue_fixed',
                            base_dir/'fase3/results/main'])
    n=int(row['N'])
    sections=[('phase3',src)]
    zoom=phase4_dir/'results/zoom1'/f'{MAIN}_N{n}_zoom1.h5'
    if zoom.exists() and is_completed(zoom):sections.append(('zoom1',zoom))
    for seg in LONG_ENDS:
        file=phase4_dir/'results/long'/f'{MAIN}_N{n}_seg{seg}.h5'
        if file.exists() and is_completed(file):sections.append((f'seg{seg}',file))
        else:break # Never pretend a later segment is connected after a missing one.
    values={}
    seam=[]
    for role,path in sections:
        indices,fields,diagnostics=read_h5(path,row)
        for k,u,d in zip(indices,fields,diagnostics):
            if k in values and role.startswith('seg'):
                old=values[k][0]
                rel=float(np.linalg.norm(old-u)/max(np.linalg.norm(old),1e-300))
                seam.append({'N':n,'tau':k/K_PER_TAU,'segment':role,'relative_field_difference':rel})
                if rel>1e-10:
                    raise ValueError('La continuación no coincide con el checkpoint, '+str(path))
            if role=='phase3':
                values[int(k)]=(u,d,role)
            elif role=='zoom1' and k>=round(.94*K_PER_TAU) and k<=round(1.10*K_PER_TAU):
                values[int(k)]=(u,d,role)
            elif role.startswith('seg'):
                values[int(k)]=(u,d,role)
    keys=sorted(values)
    if not keys or keys[0]!=0 or any(k>round(4.25*K_PER_TAU) for k in keys):
        raise ValueError('Combinación temporal inesperada')
    U=np.stack([values[k][0] for k in keys])
    D=np.stack([values[k][1] for k in keys])
    tags=[values[k][2] for k in keys]
    return np.asarray(keys),U,D,tags,seam,[(role,str(path)) for role,path in sections]


def is_completed(path):
    try:
        with h5py.File(path,'r') as h:
            return h.attrs.get('status')=='COMPLETED'
    except (OSError,KeyError):
        return False


def modal_rows(row,ks,U,D,tags):
    n=int(row['N'])
    NMODE=12
    if n//2 < NMODE:
        raise ValueError('Malla insuficiente para armónicos solicitados')
    initial_osc=0.5 # u0 = cos(theta) with A=1
    result=[]
    for k,u,d,tag in zip(ks,U,D,tags):
        hat=np.fft.rfft(u)/n
        energy=np.abs(hat[:NMODE+1])**2
        norm_osc=(np.mean(u**2)-abs(np.mean(u))**2)/initial_osc
        share=2*energy[1]/(np.mean(u**2)-np.mean(u)**2) if norm_osc>1e-20 else float('nan')
        phase=np.angle(hat[1])
        rowout={
           'N':n,'tau':float(k)/K_PER_TAU,'source':tag,'D':float(d[5]),
           'Phi1':float(d[7]),'r':float(d[8]),'H':float(d[9]),
           'Qosc':float(d[8]**2+d[9]),'I_p1':float(d[2]),
           'mass':float(d[1]),'Ahalf':float(d[4]),
           'fundamental_phase':float(phase),
           'D2_modal_identity_residual':float(d[5]**2-(d[8]-1)**2-d[9]),
           'Phi1_fft_check':float(share),
        }
        for m in range(NMODE+1):
            rowout[f'E{m}']=float(energy[m])
            if m>=1:
                rowout[f'e{m}']=float(2*energy[m]/initial_osc)
        for m in (3,5,7):
            rowout[f'theta{m}_relative']=float(np.angle(np.exp(1j*(np.angle(hat[m])-m*phase)))) if abs(hat[m])>1e-12 and abs(hat[1])>1e-12 else None
        result.append(rowout)
    return result


def local_returns(rows,N):
    """Select a local minimum in each window (j-0.25,j+0.25), NEVER a boundary min."""
    out=[]
    for j in (1,2,3,4):
        # The first return is the independently resampled well near tau=1.
        # Later returns can move within +/-0.20 of the nominal integer.
        lo,hi=(.94,1.10) if j==1 else (j-.20,j+.20)
        idx=[i for i,r in enumerate(rows) if lo<r['tau']<hi]
        candidates=[]
        for i in idx:
            if i==0 or i+1>=len(rows):continue
            if rows[i]['D']<=rows[i-1]['D'] and rows[i]['D']<=rows[i+1]['D'] and (rows[i]['D']<rows[i-1]['D'] or rows[i]['D']<rows[i+1]['D']):
                candidates.append(i)
        status='LOCAL_MIN' if candidates else ('WINDOW_NO_MIN' if idx else 'NO_DATA')
        if candidates:
            best=min(candidates,key=lambda i:rows[i]['D'])
            if j>=2 and rows[best]['source'] not in (f'seg{j}',):
                status='NO_FULL_SEGMENT'
            rr=rows[best]
            out.append({'N':N,'index':j,'status':status,'tau':rr['tau'],
                        'D':rr['D'],'Phi1':rr['Phi1'],'r':rr['r'],'H':rr['H'],
                        'Qosc':rr['Qosc'],'I_p1':rr['I_p1'],
                        'n_candidates':len(candidates), 'source':rr['source']})
        else:
            out.append({'N':N,'index':j,'status':status,'tau':None,'D':None,
                        'Phi1':None,'r':None,'H':None,'Qosc':None,
                        'I_p1':None,'n_candidates':0,'source':None})
    return out


def outputs(root,base,archive):
    root=Path(root);base=Path(base)
    output=root/'results/analysis';output.mkdir(parents=True,exist_ok=True)
    manifest=base/'fase3/campaign_main.csv'
    rows=rows_for_case(manifest)
    allreturns=[];checks=[];seams=[]; state=[]
    profiles=[]; by_n={}; timeline={}; source_maps={}; stored_fields={}
    for case_idx in ROLES:
        row=rows[case_idx];n=int(row['N']);tc=float(row['T_cross'])
        ks,U,D,tags,s,sections=consolidate(row,base,root)
        modal=modal_rows(row,ks,U,D,tags)
        csv_out(output/f'modes_N{n}.csv',list(modal[0]),modal)
        returns=local_returns(modal,n)
        allreturns.extend(returns)
        seams.extend(s)
        by_n[n]=returns
        timeline[n]=modal
        source_maps[n]=sections
        stored_fields[n]=(ks,U)
        # Physical recovery/regularization record.
        replay=root/'results/zoom1'/f'{MAIN}_N{n}_zoom1.replay.csv'
        maxrep=None
        if replay.exists():
            with replay.open(newline='') as f:
                rec=list(csv.DictReader(f))
                maxrep=max((float(x['relative_field_diff_from_phase3']) for x in rec),default=None)
        initial_I=modal[0]['I_p1']
        invariant_drift=[abs(x['I_p1']-initial_I)/max(abs(initial_I),1e-300) for x in modal]
        check={'N':n,'max_replay_field_difference':maxrep,
               'end_tau':float(ks[-1])/K_PER_TAU,
               'n_saved_merged':len(ks),
               'invariant_max_relative_drift':max(invariant_drift),
               'invariant_final_relative_drift':invariant_drift[-1],
               'invariant_over_5pct':bool(max(invariant_drift)>0.05),
               'D2_identity_max_abs':max(abs(x['D2_modal_identity_residual']) for x in modal),
               'Phi1_fft_max_abs':max(abs(x['Phi1_fft_check']-x['Phi1']) for x in modal if np.isfinite(x['Phi1_fft_check'])),
               'phase3_source':sections[0][1]}
        checks.append(check)
        if check['invariant_over_5pct']:
            print('FASE4_ADVERTENCIA_INVARIANTE',n,'deriva',max(invariant_drift),flush=True)
        if maxrep is not None and maxrep>1e-5:
            print('FASE4_ADVERTENCIA_REPLAY',n,'diferencia_de_campo',maxrep,flush=True)
        state.append({'N':n,'end_tau':float(ks[-1])/K_PER_TAU,
                      'long_segments':sum(1 for lab,path in sections if lab.startswith('seg')),
                      'zoom_available':any(lab=='zoom1' for lab,path in sections)})
        # At a return, the optimal shift is inferred from the first Fourier mode.
        for rr in returns:
            if rr['status']!='LOCAL_MIN':continue
            target=int(round(rr['tau']*K_PER_TAU))
            ix=int(np.argmin(abs(ks-target)))
            if ks[ix]!=target:continue
            u=U[ix,:]; phase=float(np.angle(np.fft.rfft(u)[1]))
            L=2*np.pi*float(row['p'])*float(row['M'])/(float(row['p'])-1)
            shift=(-phase*L/(2*np.pi))%L
            x=np.arange(n)*L/n
            target_u=np.cos(2*np.pi*(x-shift)/L)
            # Only the finest N profile is exported; diagnostics for all N are retained.
            if n==max(int(x['N']) for x in rows.values()):
                rec=[{'N':n,'index':rr['index'],'tau':rr['tau'],'shift':shift,
                      'x':float(xx),'u':float(uu),'u0_opt_shift':float(ui),
                      'residual':float(uu-ui)} for xx,uu,ui in zip(x,u,target_u)]
                filename=output/f'profile_return{rr["index"]}_N{n}.csv'
                csv_out(filename,list(rec[0]),rec)
                profiles.append(str(filename))
        # Downsampled x-t field for a true space-time image, not an interpolated cartoon.
        if n==max(int(x['N']) for x in rows.values()):
            xi=np.arange(0,n,max(1,n//180))
            spacetime=[]
            for k,u in zip(ks,U):
                if (k%32!=0): continue # baseline sample every 0.01 tau
                tau=k/K_PER_TAU
                for j in xi:
                    spacetime.append({'tau':tau,'x':float(j*2*np.pi*float(row['p'])*float(row['M'])/(float(row['p'])-1)/n),
                                      'u':float(u[j])})
            csv_out(output/f'spacetime_N{n}.csv',['tau','x','u'],spacetime)
    csv_out(output/'retornos.csv',list(allreturns[0]),allreturns)
    csv_out(output/'replay_checks.csv',list(checks[0]),checks)
    csv_out(output/'checkpoint_seams.csv',['N','tau','segment','relative_field_difference'],seams)
    comparisons=[]
    ordered=sorted(by_n)
    for j in (1,2,3,4):
        a=[next(v for v in by_n[n] if v['index']==j) for n in ordered]
        if all(v['status']=='LOCAL_MIN' for v in a):
            comparisons.append({'index':j,'N':','.join(map(str,ordered)),
                'D':';'.join(f'{v["D"]:.12g}' for v in a),
                'tau':';'.join(f'{v["tau"]:.12g}' for v in a),
                'delta_D_low_mid':a[1]['D']-a[0]['D'],
                'delta_D_mid_high':a[2]['D']-a[1]['D'],
                'delta_tau_low_mid':a[1]['tau']-a[0]['tau'],
                'delta_tau_mid_high':a[2]['tau']-a[1]['tau'],
                'fully_available':True})
        else:
            comparisons.append({'index':j,'N':','.join(map(str,ordered)),
                'D':None,'tau':None,'delta_D_low_mid':None,
                'delta_D_mid_high':None,'delta_tau_low_mid':None,
                'delta_tau_mid_high':None,'fully_available':False})
    csv_out(output/'refinement_returns.csv',list(comparisons[0]),comparisons)
    # Independent full-field differences on exact, shared time/nodal grids.
    # Also remove a common Fourier phase to distinguish pure drift from shape.
    field_rows=[]; field_summary=[]
    for n0,n1 in zip(ordered[:-1],ordered[1:]):
        if n1 != 2*n0:
            raise RuntimeError('La comparacion de mallas requiere N y 2N')
        k0,U0=stored_fields[n0];k1,U1=stored_fields[n1]
        intersection,a,b=np.intersect1d(k0,k1,return_indices=True)
        norm_initial=float(np.linalg.norm(U0[0]))
        if norm_initial<=0:raise RuntimeError('Norma inicial cero')
        ds=[];das=[]
        for kk,ia,ib in zip(intersection,a,b):
            ua=U0[ia]
            ub=U1[ib,::2]
            if ua.shape!=ub.shape:raise RuntimeError('Mallas no alineadas por nodos')
            diff=float(np.linalg.norm(ua-ub)/norm_initial)
            phasea=float(np.angle(np.fft.rfft(ua)[1]))
            phaseb=float(np.angle(np.fft.rfft(ub)[1]))
            modes=np.fft.rfft(ub)
            phasefix=np.exp(1j*np.arange(len(modes))*(phasea-phaseb))
            ubalign=np.fft.irfft(modes*phasefix,n=n0)
            align=float(np.linalg.norm(ua-ubalign)/norm_initial)
            field_rows.append({'Ncoarse':n0,'Nfine':n1,'tau':kk/K_PER_TAU,
                              'L2_unaligned':diff,'L2_aligned_fundamental':align})
            ds.append(diff);das.append(align)
        for j in (1,2,3,4):
            relevant=[r for r in field_rows if r['Ncoarse']==n0 and j-.1<=r['tau']<=j+.1]
            if relevant:
                field_summary.append({'Ncoarse':n0,'Nfine':n1,'return':j,
                    'max_L2_window':max(r['L2_unaligned'] for r in relevant),
                    'max_L2_aligned_window':max(r['L2_aligned_fundamental'] for r in relevant),
                    'L2_at_nearest_integer':min(relevant,key=lambda r:abs(r['tau']-j))['L2_unaligned'],
                    'coverage':f'{relevant[0]["tau"]:.5f}..{relevant[-1]["tau"]:.5f}'})
    csv_out(output/'field_comparisons.csv',list(field_rows[0]),field_rows)
    csv_out(output/'field_budget.csv',list(field_summary[0]),field_summary)
    complete=all(x['long_segments']==3 and x['zoom_available'] for x in state)
    report={'status':'DATA_COMPLETE_ANALYSIS_PENDING_INTERPRETATION' if complete else 'PARTIAL',
            'n_requested':3,'cases':state,'branches':comparisons,
            'checks':checks,'sources':source_maps,'field_budget':field_summary,
            'warning':'No proof of PDE well-posedness/convergence; local minima are sampled, not fitted. '
                      'The Z half-wave projection is imposed. '
                      'A return of D does not imply full-field convergence.'}
    (output/'status.json').write_text(json.dumps(report,indent=2,allow_nan=False,ensure_ascii=False)+'\n')
    # Figures are optional and must not cause a correct data analysis to fail.
    try:
        from .figures import produce_figures
        produce_figures(output, timeline, allreturns, ordered[-1])
        print('FASE4_FIGURAS_OK',flush=True)
    except ImportError as exc:
        print('FASE4_FIGURAS_OMITIDAS falta matplotlib:',exc,flush=True)
    archive=Path(archive);archive.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(output.iterdir()):
            if f.is_file(): z.write(f,arcname=f.name)
        for f in sorted((root/'results/zoom1').glob('*.audit.json')):z.write(f,arcname='audits/'+f.name)
        for f in sorted((root/'results/long').glob('*.audit.json')):z.write(f,arcname='audits/'+f.name)
        for f in sorted((root/'results/long').glob('*.failure.json')):z.write(f,arcname='failures/'+f.name)
    print('FASE4_ANALISIS_'+('COMPLETO' if complete else 'PARCIAL'),archive,flush=True)
    return report


def main():
    a=argparse.ArgumentParser()
    a.add_argument('--root',default='fase4')
    a.add_argument('--base',default='.')
    a.add_argument('--zip',default='fase4/Fase4_CNSNS_resultados_20261118.zip')
    b=a.parse_args()
    outputs(b.root,b.base,b.zip)

if __name__=='__main__': main()
