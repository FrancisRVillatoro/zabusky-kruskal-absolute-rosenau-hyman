"""Phase 4 fixed-dt Radau continuation from VERIFIED phase-3 checkpoints.

The source phase-3 HDF5 is read-only. This script NEVER changes dt,
spatial operators, stage tolerances, or the half-wave projection.

zoom1: replay 0.94 -> 1.10 from phase-3 snapshot at tau=0.94,
       storing D and fields every 0.0003125 tau.
long:  stage 2: 1.25 -> 2.25, stage 3: 2.25 -> 3.25,
       stage 4: 3.25 -> 4.25, each a separate checkpointed HDF5.

Each attempted step uses the original stage solve, then stronger Newton
with the EXACT same residual tolerance (changed globalization only).
On unresolved step, abort and keep the HDF5 marked INCOMPLETE.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from dataclasses import asdict
from pathlib import Path

import h5py
import numpy as np
import scipy

from absk_radau.model import PeriodicAbsK
from absk_radau.radau_mass import MassRadau5, NewtonOptions, NewtonFailure, RunStats
from absk_radau.io import H5Recorder

MAIN = 'Z_p225_M4'
ROLES = {1:'space_low', 2:'space_mid', 3:'space_high'}
K_PER_TAU = 3200
ZOOM_START = 0.94
ZOOM_END = 1.10
LONG_ENDS = {2:(1.25,2.25), 3:(2.25,3.25), 4:(3.25,4.25)}
PY_FIXED = '/mnt/home/soft/python/programs/x86_64_sles156/3.14.3/bin/python3'


def rows_for_case(manifest):
    with open(manifest, newline='', encoding='utf8') as fd:
        rows = list(csv.DictReader(fd))
    result = {}
    for i, role in ROLES.items():
        matches = [r for r in rows if r['case']==MAIN and r['role']==role]
        if len(matches)!=1:
            raise RuntimeError(f'No hay una entrada única {role} en {manifest}')
        row = matches[0]
        if float(row['nu']) != 0 or row['family'] != 'Z' or int(row['project_half']) != 1:
            raise RuntimeError('La configuración debe ser Z proyectado sin regularización')
        if not np.isclose(float(row['dt'])/float(row['T_cross']),1/K_PER_TAU,rtol=0,atol=1e-14):
            raise RuntimeError('La malla temporal no es un divisor de 0.0003125 tau')
        if int(row['save_every'])!=32 or not np.isclose(float(row['tau_end']),1.25):
            raise RuntimeError('Fase 4 presupone los checkpoints de fase 3 en tau=0.01 hasta 1.25')
        result[i] = row
    return result


def readable_status(path):
    try:
        with h5py.File(path,'r') as h:
            return str(h.attrs.get('status', 'UNKNOWN'))
    except OSError:
        return 'UNREADABLE'


def phase3_source(row, folders):
    name=row['run_id']+'.h5'
    for folder in folders:
        f=Path(folder)/name
        if f.is_file() and readable_status(f)=='COMPLETED':
            with h5py.File(f,'r') as h:
                cfg=json.loads(h.attrs['config_json'])
                if cfg.get('run_id')!=row['run_id'] or int(h.attrs['n_cells'])!=int(row['N']):
                    raise RuntimeError('No coincide la configuración de fase 3: '+str(f))
                if abs(float(h['t'][-1])/float(row['T_cross'])-1.25)>2e-10:
                    raise RuntimeError('Fase 3 no termina en tau=1.25: '+str(f))
            return f
    raise FileNotFoundError(f'Falta el checkpoint COMPLETED para {name}; buscar en {folders}')


def fetch_checkpoint(path, row, k):
    dt=float(row['dt'])
    tc=float(row['T_cross'])
    tau=k/K_PER_TAU
    with h5py.File(path,'r') as h:
        if h.attrs['status']!='COMPLETED':
            raise RuntimeError('Checkpoint no completado: '+str(path))
        t=h['t'][:]
        ix=int(np.argmin(abs(t-k*dt)))
        if abs(t[ix]/tc-tau)>5e-10:
            raise RuntimeError(f'Checkpoint tau={tau} no disponible en {path}')
        u=h['u'][ix,:]
        n=int(h.attrs['n_cells'])
        if n!=int(row['N']) or u.shape!=(n,) or not np.all(np.isfinite(u)):
            raise RuntimeError('Campo de checkpoint inválido')
        cfg=json.loads(h.attrs['config_json'])
        for key in ('p','M','nu'):
            if not np.isclose(float(cfg[key]),float(row[key]),rtol=0,atol=1e-13):
                raise RuntimeError(f'Parámetro {key} no coincide')
        if bool(cfg['project_half'])!=bool(int(row['project_half'])):
            raise RuntimeError('Se ha cambiado la proyección durante la continuación')
        return u.copy()


def make_solvers(row):
    model=PeriodicAbsK(int(row['N']), 2*np.pi*float(row['p'])*float(row['M'])/(float(row['p'])-1),
                       float(row['p']),float(row['nu']))
    orig=NewtonOptions(atol=float(row['newton_atol']),rtol=float(row['newton_rtol']),
                       max_iter=int(row['newton_max_iter']),
                       line_search_backtracks=10,predictor='euler')
    ext=NewtonOptions(atol=orig.atol,rtol=orig.rtol,max_iter=max(orig.max_iter,28),
                      line_search_backtracks=20,predictor='euler')
    const=NewtonOptions(atol=orig.atol,rtol=orig.rtol,max_iter=max(orig.max_iter,28),
                        line_search_backtracks=20,predictor='constant')
    variants=[('original',orig),('extended_euler',ext),('extended_constant',const)]
    return model, [(name,MassRadau5(model,opt,project_half=True)) for name,opt in variants]


def save_on(k, mode):
    if mode=='zoom1':
        return (True)
    # Keep a 0.01 baseline for every tau, and 0.000625 near integer returns.
    is_dense=any(abs(k/K_PER_TAU-j)<=0.075000001 for j in (2,3,4))
    return k%40 == 0 or (is_dense and k%2==0)


def completed_output(path, row, start, end, mode):
    try:
        with h5py.File(path,'r') as h:
            if h.attrs.get('status')!='COMPLETED' or int(h.attrs['n_cells'])!=int(row['N']):
                return False
            cfg=json.loads(h.attrs['config_json'])
            if cfg['phase']!='fase4' or cfg['mode']!=mode or cfg['phase3_run_id']!=row['run_id']:
                return False
            if abs(h['t'][0]/float(row['T_cross'])-start)>1e-9 or abs(h['t'][-1]/float(row['T_cross'])-end)>1e-9:
                return False
            return True
    except (OSError, KeyError, ValueError):
        return False


def run_one(row, source, dest, start_tau, end_tau, mode, overwrite=False):
    """Run a single EXACT fixed-step block and write H5+audit, never overwriting."""
    dest=Path(dest)
    if dest.exists():
        if completed_output(dest,row,start_tau,end_tau,mode) and dest.with_suffix('.audit.json').exists():
            print('FASE4_REUTILIZADA',mode,row['N'],dest,flush=True)
            return json.loads(dest.with_suffix('.audit.json').read_text())
        raise FileExistsError('Salida previa no válida o incompleta; NO se sobreescribe: '+str(dest))
    dt=float(row['dt'])
    tc=float(row['T_cross'])
    k0=round(start_tau*K_PER_TAU)
    k1=round(end_tau*K_PER_TAU)
    if k0 >= k1 or not np.isclose(dt*K_PER_TAU,tc,rtol=0,atol=1e-9):
        raise RuntimeError('Calendario de pasos incompatible con fase 3')
    model,solvers=make_solvers(row)
    u=fetch_checkpoint(source,row,k0)
    config={
        'phase':'fase4','mode':mode,'phase3_run_id':row['run_id'],'source_h5':str(source.resolve()),
        'p':float(row['p']),'M':float(row['M']),'family':'Z','N':int(row['N']),
        'nu':0.,'project_half':True,'T_cross':tc,'dt':dt,
        'tau_start':start_tau,'tau_end':end_tau,'first_step':k0,'last_step':k1,
        'calendar':'k/3200 tau','output':'0.01 tau and 0.000625 tau near integers',
        'methods':['original','extended_euler','extended_constant'],
        'newton_atol':float(row['newton_atol']),'newton_rtol':float(row['newton_rtol']),
        'fixed_dt':True,'changes_to_spatial_operator':False,'python':sys.version.split()[0],
        'numpy':np.__version__,'scipy':scipy.__version__,'h5py':h5py.__version__,
        'platform':platform.platform(),
    }
    dest.parent.mkdir(parents=True,exist_ok=True)
    recorder=H5Recorder(dest,model,config,'Z',1.)
    stats=RunStats(mode='fase4_fixed_dt')
    fallback={name:0 for name,_ in solvers}
    replay=[]
    compare_k={}
    if mode=='zoom1':
        with h5py.File(source,'r') as h:
            for i,t in enumerate(h['t'][:]):
                kk=int(round(float(t)/dt))
                if k0<=kk<=k1:
                    compare_k[kk]=h['u'][i,:]
    begin=time.perf_counter()
    try:
        recorder(k0*dt,u,stats)
        if k0 in compare_k:
            replay.append([k0/K_PER_TAU,0.])
        for k in range(k0+1,k1+1):
            failures=[]
            for name,solver in solvers:
                try:
                    un,info=solver.step(u,dt)
                    break
                except NewtonFailure as exc:
                    failures.append(f'{name}: {exc}')
            else:
                failure={'status':'FAILED_FIXED_DT','run_id':row['run_id'],
                         'mode':mode,'tau':(k-1)/K_PER_TAU,'step':k,'dt':dt,
                         'fixed_dt':True,'tried':failures,'fallback_use':fallback,
                         'last_saved_tau':recorder.h5['t'][-1]/tc}
                dest.with_suffix('.failure.json').write_text(json.dumps(failure,indent=2)+'\n')
                raise NewtonFailure('FASE4_NEWTON_UNRESOLVED '+str(failure))
            u=un
            fallback[name]+=1
            stats.add_step(info,dt)
            stats.final_time=k*dt
            recorder.on_step(k*dt,dt,info,'accepted',float('nan'))
            if save_on(k,mode) or k==k1:
                recorder(k*dt,u,stats)
                if k in compare_k:
                    orig=compare_k[k]
                    replay.append([k/K_PER_TAU, float(np.linalg.norm(u-orig)/max(np.linalg.norm(orig),1e-300))])
            if (k-k0) % max(1,(k1-k0)//10)==0:
                print('FASE4_PROGRESO',mode,'N',row['N'],'tau',f'{k/K_PER_TAU:.5f}',
                      'fallback',sum(c for n,c in fallback.items() if n!='original'),flush=True)
        recorder.finish(stats)
    except BaseException as exc:
        recorder.fail(exc)
        raise
    verify=validate_output(dest,row,start_tau,end_tau,mode)
    verify.update(wall_seconds=time.perf_counter()-begin,fallback_counts=fallback,
                  python=sys.version.split()[0],source=str(source.resolve()),
                  resume_same_dt=True)
    if mode=='zoom1':
        verify['replay_compared_snapshots']=len(replay)
        verify['replay_max_field_relative_difference']=max((e for _,e in replay),default=None)
        verify['replay_at_tau_1p01']=next((e for tau,e in replay if abs(tau-1.01)<1e-10),None)
        with dest.with_suffix('.replay.csv').open('w',newline='') as fh:
            w=csv.writer(fh);w.writerow(['tau','relative_field_diff_from_phase3']);w.writerows(replay)
    audit=dest.with_suffix('.audit.json')
    if audit.exists():
        raise FileExistsError(str(audit))
    audit.write_text(json.dumps(verify,indent=2,allow_nan=False)+'\n')
    print('FASE4_BLOQUE_OK',mode,'N',row['N'],'tau_fin',end_tau,
          'fallback',verify['fallback_counts'],'residuo_max',verify['max_scaled_newton_rms'],flush=True)
    return verify


def validate_output(dest,row,start_tau,end_tau,mode):
    with h5py.File(dest,'r') as h:
        if h.attrs['status']!='COMPLETED':
            raise RuntimeError('El archivo HDF5 no está COMPLETED')
        t=h['t'][:]; D=h['diagnostics'][:]; U=h['u']; logs=h['step_log'][:]
        n=int(row['N']); dt=float(row['dt']); tc=float(row['T_cross'])
        if U.ndim!=2 or U.shape!=(len(t),n) or len(t)<2 or D.shape!=(len(t),10):
            raise RuntimeError('Dimensiones de HDF5 incorrectas')
        if not np.all(np.diff(t)>0) or not np.all(np.isfinite(D[:,[1,2,5,7,8,9]])):
            raise RuntimeError('Tiempos o diagnósticos inválidos')
        if not np.all(np.isfinite(U[:])):
            raise RuntimeError('Campos no finitos')
        if abs(t[0]/tc-start_tau)>1e-10 or abs(t[-1]/tc-end_tau)>1e-10:
            raise RuntimeError('Extremos temporales incorrectos')
        if len(logs)!=round((end_tau-start_tau)*K_PER_TAU):
            raise RuntimeError('Número de pasos inesperado')
        if not np.all(logs[:,7]==1.) or not np.all(logs[:,4]<=1.+1e-12):
            raise RuntimeError('Se aceptaron pasos sin convergencia')
        if not np.allclose(logs[:,1],dt,atol=1e-13,rtol=0):
            raise RuntimeError('Variación silenciosa del paso temporal')
        stats=json.loads(h.attrs['run_stats_json'])
        if int(stats['accepted'])!=len(logs):
            raise RuntimeError('Contador de pasos incompatible')
        return {'status':'COMPLETED','run_id':row['run_id'],'mode':mode,'N':n,
                'tau_start':start_tau,'tau_end':end_tau,'n_saved':len(t),
                'n_steps':len(logs),'max_scaled_newton_rms':float(stats['max_scaled_residual']),
                'max_newton_iterations':int(np.max(logs[:,2])),
                'invariant_relative_drift':float(abs(D[-1,2]-D[0,2])/max(abs(D[0,2]),1e-300)),
                'mass_absolute_drift':float(abs(D[-1,1]-D[0,1]))}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case-index',type=int,required=True,choices=(1,2,3))
    parser.add_argument('--mode',choices=('zoom1','long'),required=True)
    parser.add_argument('--manifest',default='fase3/campaign_main.csv')
    parser.add_argument('--outdir',default='fase4/results')
    parser.add_argument('--phase3-sources',nargs='*',default=['fase3/results/combined_fixed',
                         'fase3/results/rescue_fixed','fase3/results/main'])
    args=parser.parse_args()
    row=rows_for_case(args.manifest)[args.case_index]
    source=phase3_source(row,args.phase3_sources)
    out=Path(args.outdir)
    if args.mode=='zoom1':
        target=out/'zoom1'/f'{MAIN}_N{row["N"]}_zoom1.h5'
        run_one(row,source,target,ZOOM_START,ZOOM_END,'zoom1')
        print('FASE4_ZOOM_OK',row['N'],flush=True)
    else:
        prev=source
        for seg,(start,end) in LONG_ENDS.items():
            target=out/'long'/f'{MAIN}_N{row["N"]}_seg{seg}.h5'
            run_one(row,prev,target,start,end,f'seg{seg}')
            prev=target
        print('FASE4_LARGA_OK',row['N'],flush=True)

if __name__=='__main__':
    main()
