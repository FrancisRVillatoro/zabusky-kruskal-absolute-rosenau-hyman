"""Audit fourth-return time-step/spatial refinements from completed HDF5s.

No synthetic estimates of unavailable trajectories or returns. A local
restart at tau=3.25 does NOT establish whole-trajectory temporal order.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

import h5py
import numpy as np

from .run_block import (CASE, TAU_BEGIN, TAU_END, BASE_STEPS_TAU,
                        rows_for_case, source_for, is_completed)

TICKS=BASE_STEPS_TAU*4       # finest quarter-step lattice
TOL=1e-9


def save_csv(path, fields, rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore')
        w.writeheader();w.writerows(rows)


def read_h5(path,row,*,allow_incomplete=False):
    with h5py.File(path,'r') as h:
        st=str(h.attrs.get('status'))
        if st!='COMPLETED' and not allow_incomplete:
            raise ValueError('HDF5 no COMPLETED: '+str(path))
        if int(h.attrs['n_cells'])!=int(row['N']):
            raise ValueError('N incorrecto: '+str(path))
        t=h['t'][:]/float(row['T_cross'])
        u=h['u'][:]
        d=h['diagnostics'][:]
        if u.ndim!=2 or d.shape!=(len(t),10) or u.shape!=(len(t),int(row['N'])):
            raise ValueError('Dimensiones incompatibles: '+str(path))
        if len(t)<2 or not np.all(np.isfinite(u)) or not np.all(np.isfinite(d[:,[1,2,5,7,8,9]])):
            raise ValueError('Datos no finitos: '+str(path))
        ticks=np.rint(t*TICKS).astype(np.int64)
        if np.max(np.abs(t-ticks/TICKS))>1e-8 or np.any(np.diff(ticks)<=0):
            raise ValueError('Calendario temporal incoherente: '+str(path))
        d2=np.abs(d[:,5]**2-(d[:,8]-1)**2-d[:,9])
        if np.max(d2)>1e-8:
            raise ValueError('La identidad modal no se satisface: '+str(path))
        return {'ticks':ticks,'u':u,'d':d, 'status':st,
                'path':str(path), 'identity_max':float(np.max(d2)),
                'max_mean_abs':float(np.max(np.abs(d[:,1]))),
                'relative_invariant_drift':float(np.max(np.abs(d[:,2]-d[0,2]))/max(abs(d[0,2]),1e-300))}


def fourth_return(data):
    ticks=data['ticks']; y=data['d'][:,5]
    inside=np.where((ticks/TICKS>3.8)&(ticks/TICKS<4.2))[0]
    inds=[int(i) for i in inside if i>0 and i<len(y)-1 and y[i]<=y[i-1]
          and y[i]<=y[i+1] and (y[i]<y[i-1] or y[i]<y[i+1])]
    if not inds:
        return {'status':'NO_INTERIOR_LOCAL_MIN','tau':None,'D':None}
    i=min(inds,key=lambda i:y[i])
    u=data['u'][i]; n=len(u)
    hat=np.fft.rfft(u)/n
    e5=4*float(abs(hat[5])**2)
    e3=4*float(abs(hat[3])**2)
    H=float(data['d'][i,9]);r=float(data['d'][i,8])
    return {
        'status':'LOCAL_MIN','tau':float(ticks[i]/TICKS),'D':float(y[i]),
        'r':r,'H':H,'Phi1':float(data['d'][i,7]),'Qosc':float(r*r+H),
        'e3':e3,'e5':e5,'e5_over_H':float(e5/H) if H>0 else None,
        'invariant_relative_drift_from_block_start':data['relative_invariant_drift'],
        'sample_resolution_tau':1/3200,
    }


def compare_fields(a,b,coarse_n,*,tau_lo=3.9,tau_hi=4.1):
    na=a['u'].shape[1];nb=b['u'].shape[1]
    if na!=coarse_n or nb not in (coarse_n,2*coarse_n):
        raise ValueError('N de comparación no coincidente')
    inds,ia,ib=np.intersect1d(a['ticks'],b['ticks'],return_indices=True)
    rows=[]; denom=np.sqrt(coarse_n/2)  # A=1 initial cos(theta)
    for tick,i,j in zip(inds,ia,ib):
        tau=float(tick/TICKS)
        if not tau_lo-1e-10<=tau<=tau_hi+1e-10:continue
        ua=a['u'][i];ub=b['u'][j,::nb//na]
        error=float(np.linalg.norm(ua-ub)/denom)
        phase_a=float(np.angle(np.fft.rfft(ua)[1]))
        phase_b=float(np.angle(np.fft.rfft(ub)[1]))
        fftb=np.fft.rfft(ub)
        phased=np.exp(1j*np.arange(len(fftb))*(phase_a-phase_b))
        ua_b=np.fft.irfft(fftb*phased,n=na)
        e_shift=float(np.linalg.norm(ua-ua_b)/denom)
        rows.append({'tau':tau,'L2':error,'L2_fundamental_phase_aligned':e_shift})
    if not rows:return {'n_shared':0,'max_L2':None,'max_L2_phase_aligned':None},[]
    return {'n_shared':len(rows),'max_L2':max(r['L2'] for r in rows),
            'max_L2_phase_aligned':max(r['L2_fundamental_phase_aligned'] for r in rows),
            'at_tau4_L2':min(rows,key=lambda r:abs(r['tau']-4.0))['L2'],
            'at_tau4p034_L2':min(rows,key=lambda r:abs(r['tau']-4.034))['L2']},rows


def main_analysis(base, results, analysis, outzip):
    base=Path(base);results=Path(results);analysis=Path(analysis)
    analysis.mkdir(parents=True,exist_ok=True)
    rows=rows_for_case(base/'fase3/campaign_main.csv')
    data={}; returns=[]; inventory=[]; audits=[]
    for divisor in (2,4):
        for index in (2,3):
            row=rows[index];n=int(row['N'])
            f=results/f'dt_divisor_{divisor}'/f'{CASE}_N{n}_seg4_dtdiv{divisor}.h5'
            ready=is_completed(f,row,divisor,TAU_END)
            issue=''
            if ready:
                try:
                    v=read_h5(f,row)
                    data[(n,divisor)]=v
                    r=fourth_return(v)
                    returns.append({'N':n,'dt_divisor':divisor,'source':'fase4b',**r})
                    auditfile=f.with_suffix('.audit.json')
                    audits.append(json.loads(auditfile.read_text()))
                except Exception as exc:
                    ready=False;issue=str(exc)
            else:
                ff=f.with_suffix('.failure.json')
                issue='FAILED_FIXED_DT: '+ff.read_text()[:2000] if ff.exists() else 'MISSING_H5'
            inventory.append({'N':n,'dt_divisor':divisor,'complete':ready,
                              'path':str(f) if ready else None,'issue':issue})
    # Main controls: same grid baseline N=900, and same time step N=900,1800.
    comparisons=[];profiles=[]
    baseline900=base/'fase4/results/long'/f'{CASE}_N900_seg4.h5'
    legacy=None
    if baseline900.exists():
        try:legacy=read_h5(baseline900,rows[2])
        except Exception as exc:inventory.append({'N':900,'dt_divisor':1,'complete':False,'issue':str(exc)})
    if legacy is not None:
        r=fourth_return(legacy)
        returns.append({'N':900,'dt_divisor':1,'source':'fase4_baseline','status':r['status'],
                        **{k:v for k,v in r.items() if k!='status'}})
    for n in (900,1800):
        for div1,div2 in ((1,2),(2,4)):
            if n==1800 and div1==1: continue  # Baseline seg4 N1800 never COMPLETED.
            x=legacy if n==900 and div1==1 else data.get((n,div1))
            y=data.get((n,div2))
            if x is not None and y is not None:
                metrics,curve=compare_fields(x,y,n)
                comparisons.append({'type':'temporal','Ncoarse':n,'Nfine':n,'dt_divisor_a':div1,
                                    'dt_divisor_b':div2,**metrics})
    for divisor in (2,4):
        x=data.get((900,divisor));y=data.get((1800,divisor))
        if x is not None and y is not None:
            metrics,curve=compare_fields(x,y,900)
            comparisons.append({'type':'spatial','Ncoarse':900,'Nfine':1800,'dt_divisor_a':divisor,
                                'dt_divisor_b':divisor,**metrics})
            for xrow in curve:
                profiles.append({'comparison_type':'spatial','Ncoarse':900,'Nfine':1800,'dt_divisor':divisor,**xrow})
    save_csv(analysis/'retornos4b.csv',
             ['N','dt_divisor','source','status','tau','D','r','H','Phi1','Qosc','e3','e5','e5_over_H',
              'invariant_relative_drift_from_block_start','sample_resolution_tau'],returns)
    save_csv(analysis/'field_budget4b.csv',
             ['type','Ncoarse','Nfine','dt_divisor_a','dt_divisor_b','n_shared','max_L2',
              'max_L2_phase_aligned','at_tau4_L2','at_tau4p034_L2'],comparisons)
    valid={(r['N'],r['dt_divisor']):r for r in returns if r.get('status')=='LOCAL_MIN'}
    return_differences=[]
    for da,db,na,nb,typ in [(2,2,900,1800,'spatial'),(4,4,900,1800,'spatial'),
                           (1,2,900,900,'temporal'),(2,4,900,900,'temporal'),
                           (2,4,1800,1800,'temporal')]:
        a=valid.get((na,da));b=valid.get((nb,db))
        if a and b:
            return_differences.append({'type':typ,'Na':na,'Nb':nb,'dt_divisor_a':da,
                   'dt_divisor_b':db,'delta_D_b_minus_a':b['D']-a['D'],
                   'delta_tau_b_minus_a':b['tau']-a['tau'],
                   'delta_e5_over_H_b_minus_a':b['e5_over_H']-a['e5_over_H']})
    save_csv(analysis/'return_differences4b.csv',
        ['type','Na','Nb','dt_divisor_a','dt_divisor_b','delta_D_b_minus_a',
         'delta_tau_b_minus_a','delta_e5_over_H_b_minus_a'],return_differences)
    save_csv(analysis/'spatial_curves4b.csv',
             ['comparison_type','Ncoarse','Nfine','dt_divisor','tau','L2','L2_fundamental_phase_aligned'],profiles)
    save_csv(analysis/'inventory4b.csv',
             ['N','dt_divisor','complete','path','issue'],inventory)
    chosen_divisor=2 if (900,2) in data and (1800,2) in data else (4 if (900,4) in data and (1800,4) in data else None)
    if chosen_divisor is None:
        status='PARTIAL: no existe una pareja N=900/1800 COMPLETED con el mismo dt'
    else:
        ma={n:next((x for x in returns if x['N']==n and x['dt_divisor']==chosen_divisor),None) for n in (900,1800)}
        same=[x for x in comparisons if x['type']=='spatial' and x['dt_divisor_a']==chosen_divisor]
        if all(v and v['status']=='LOCAL_MIN' for v in ma.values()) and same and same[0]['n_shared']>0:
            status='DATOS_4B_COMPLETOS: cuarto retorno resuelto en dos mallas; interpretar el presupuesto'
        else:
            status='PARTIAL: trayectorias completas pero retorno/comparación sin validación'
    report={
        'status':status,'selected_common_dt_divisor':chosen_divisor,
        'inventory':inventory,'fourth_returns':returns,
        'full_field_budget':comparisons,'return_differences':return_differences,'audits':audits,
        'historical_baseline_return_D_N900':0.24006354909988273,
        'interpretation_limits':[
            'La comparación temporal de 4B comienza en el mismo campo guardado en tau=3.25: no demuestra convergencia temporal de la órbita completa desde tau=0.',
            'Los perfiles de fase 4B son los de la dinámica semidiscreta proyectada al subespacio antisimétrico.',
            'Los errores de campo entre mallas no se sustituyen por los errores en D_rec.',
            'La acumulación de e5 en los mínimos es una observación modal, no prueba de resonancia.',
            'Sin existencia, unicidad y convergencia demostrada, no se atribuye el resultado directamente a la PDE no regularizada.'
        ]}
    (analysis/'status4b.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(8,4))
        for (n,div),v in sorted(data.items()):
            tau=v['ticks']/TICKS
            mask=(tau>=3.9)&(tau<=4.1)
            ax.plot(tau[mask],v['d'][mask,5],label=f'N={n}, dt/{div}')
        if legacy is not None:
            tau=legacy['ticks']/TICKS;mask=(tau>=3.9)&(tau<=4.1)
            ax.plot(tau[mask],legacy['d'][mask,5],linestyle='--',label='N=900, dt base')
        ax.set(xlabel=r'$\tau$',ylabel=r'$D_{rec}$',title='Fourth return: fixed-step refinement')
        ax.legend(fontsize=8);fig.tight_layout()
        fig.savefig(analysis/'return4_zoom.png',dpi=180);plt.close(fig)
    except ImportError:
        pass
    with ZipFile(outzip,'w',ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(analysis.iterdir()):
            if f.is_file():z.write(f,arcname=f.name)
        for f in results.glob('dt_divisor_*/*.audit.json'):
            z.write(f,arcname='audits/'+f.name)
        for f in results.glob('dt_divisor_*/*.failure.json'):
            z.write(f,arcname='failures/'+f.name)
    print('FASE4B_INFORME',status,flush=True)
    print('FASE4B_ZIP',outzip,flush=True)
    for r in returns:
        if r.get('status')=='LOCAL_MIN':
            print('FASE4B_RETORNO',r['N'],r['dt_divisor'],r['tau'],r['D'],r.get('e5_over_H'),flush=True)
    for c in comparisons:
        print('FASE4B_CAMPO',c,flush=True)
    return report


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--base',default='.')
    ap.add_argument('--results',default='fase4b/results')
    ap.add_argument('--analysis',default='fase4b/results/analysis')
    ap.add_argument('--zip',default='fase4b/Fase4B_CNSNS_resultados_20261118.zip')
    a=ap.parse_args()
    main_analysis(a.base,a.results,a.analysis,a.zip)

if __name__=='__main__':main()
