"""Reintegrate the fourth return from an independently validated tau=3.25 HDF5.

Half dt (baseline/2) for N=900 and N=1800 is the principal experiment.
Quarter dt (baseline/4) is an explicit second-tier control, never a
silent fallback. All solvers use identical stage equations and tolerances.
Nothing is written into phase3/ or phase4/; no source HDF5 is modified.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import platform
import sys
import time
from dataclasses import asdict
from pathlib import Path

import h5py
import numpy as np
import scipy

from absk_radau.io import H5Recorder
from absk_radau.radau_mass import NewtonFailure, RunStats
from fase4.continue_radau import rows_for_case, fetch_checkpoint, make_solvers

CASE = 'Z_p225_M4'
HALF_BAND = (3.8, 4.2)
TAU_BEGIN = 3.25
TAU_END = 4.25
BASE_STEPS_TAU = 3200


def source_for(row, root):
    n = int(row['N'])
    src = Path(root) / 'fase4' / 'results' / 'long' / f'{CASE}_N{n}_seg3.h5'
    if not src.is_file():
        raise FileNotFoundError('No existe el checkpoint COMPLETED de fase4/seg3: ' + str(src))
    with h5py.File(src, 'r') as h:
        if str(h.attrs.get('status')) != 'COMPLETED':
            raise RuntimeError('El origen no está COMPLETED: ' + str(src))
        c = json.loads(h.attrs['config_json'])
        if c.get('phase') != 'fase4' or c.get('mode') != 'seg3':
            raise RuntimeError('El archivo origen no es fase4 seg3')
        if c.get('phase3_run_id') != row['run_id']:
            raise RuntimeError('Run ID de origen no coincide')
        if abs(float(h['t'][-1]) / float(row['T_cross']) - TAU_BEGIN) > 2e-10:
            raise RuntimeError('El archivo origen no termina en tau=3.25')
        if int(h.attrs['n_cells']) != n:
            raise RuntimeError('El N del checkpoint no corresponde al manifiesto')
        if abs(float(c['dt']) - float(row['dt'])) > 1e-12:
            raise RuntimeError('El dt original no coincide')
    return src


def is_completed(path, row, divisor, tau_end):
    if not Path(path).is_file() or not Path(path).with_suffix('.audit.json').is_file():
        return False
    try:
        with h5py.File(path, 'r') as h:
            cfg = json.loads(h.attrs['config_json'])
            return (str(h.attrs.get('status')) == 'COMPLETED'
                    and int(h.attrs['n_cells']) == int(row['N'])
                    and cfg.get('phase') == 'fase4b'
                    and cfg.get('mode') == f'dt_divisor_{divisor}'
                    and abs(float(h['t'][0])/float(row['T_cross'])-TAU_BEGIN) < 1e-10
                    and abs(float(h['t'][-1])/float(row['T_cross'])-tau_end) < 1e-10)
    except (KeyError, OSError, ValueError):
        return False


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def should_save(step, steps_per_tau):
    # 0.01 tau baseline; 0.0003125 tau near return 4.
    on_regular = step % (steps_per_tau//100) == 0
    on_dense = (abs(step/steps_per_tau-4.0) <= 0.120000001
                and step % (steps_per_tau//3200) == 0)
    return on_regular or on_dense


def validate_result(dest, row, divisor, tau_end):
    steps_tau = BASE_STEPS_TAU * divisor
    expected_steps = round((tau_end-TAU_BEGIN)*steps_tau)
    h_expected = float(row['dt'])/divisor
    with h5py.File(dest, 'r') as h:
        assert str(h.attrs['status']) == 'COMPLETED'
        t = h['t'][:]; u = h['u'][:]; d = h['diagnostics'][:]; steps=h['step_log'][:]
        assert u.shape == (len(t), int(row['N']))
        assert d.shape == (len(t), 10)
        assert len(steps) == expected_steps
        assert len(t)>=2 and abs(t[0]/float(row['T_cross'])-TAU_BEGIN) < 1e-10
        assert abs(t[-1]/float(row['T_cross']) - tau_end) < 1e-10
        assert np.all(np.diff(t)>0) and np.all(np.isfinite(u))
        assert np.all(np.isfinite(d[:,[1,2,5,7,8,9]]))
        assert np.all(steps[:,7] == 1.0), 'Cada paso debe estar aceptado'
        assert np.allclose(steps[:,1],h_expected,atol=1e-13,rtol=0), 'dt fijo'
        assert np.max(steps[:,4])<=1+1e-12, 'Residuo de Newton superior al umbral'
        cfg=json.loads(h.attrs['config_json'])
        assert cfg['dt_divisor'] == divisor and cfg['project_half'] is True
        mass=float(np.max(np.abs(d[:,1]-d[0,1])))
        inv=float(np.max(np.abs(d[:,2]-d[0,2]))/max(abs(d[0,2]),1e-300))
        rec_err=float(np.max(np.abs(d[:,5]**2-(d[:,8]-1)**2-d[:,9])))
        stats=json.loads(h.attrs['run_stats_json'])
        assert int(stats['accepted']) == expected_steps
        return dict(n_steps=expected_steps, n_saved=len(t), max_scaled_newton_rms=float(np.max(steps[:,4])),
                    max_newton_iterations=int(np.max(steps[:,2])), mass_max_absolute_drift=mass,
                    invariant_max_relative_drift=inv, recurrence_identity_max_abs=rec_err)


def run(row, *, base='.', divisor=2, output='fase4b/results', end_tau=TAU_END):
    if divisor not in (2,4):
        raise ValueError('4B solo admite divisores explícitos 2 o 4')
    if int(row['N']) not in (900,1800):
        raise ValueError('4B se ejecuta solo para N=900 y 1800')
    period=float(row['T_cross']); base_dt=float(row['dt'])
    steps_tau=BASE_STEPS_TAU*divisor
    dt=base_dt/divisor
    if not np.isclose(dt*steps_tau,period,atol=1e-9,rtol=0):
        raise RuntimeError('El calendario de tiempos no reproduce T_cross')
    k0=round(TAU_BEGIN*steps_tau);k1=round(end_tau*steps_tau)
    if abs(k1/steps_tau-end_tau)>1e-10 or k1<=k0:
        raise RuntimeError('Fin de tiempo incompatible con dt')
    origin=source_for(row, base)
    u=fetch_checkpoint(origin,row, round(TAU_BEGIN*BASE_STEPS_TAU))
    model, solvers=make_solvers(row)
    output=Path(output)/f'dt_divisor_{divisor}'/f'{CASE}_N{row["N"]}_seg4_dtdiv{divisor}.h5'
    if output.exists():
        if is_completed(output,row,divisor,end_tau):
            print('FASE4B_REUTILIZADA',int(row['N']),divisor,output,flush=True)
            return json.loads(output.with_suffix('.audit.json').read_text())
        raise FileExistsError('Existe archivo previo NO COMPLETADO. No sobreescribir: '+str(output))
    config={
        'phase':'fase4b','mode':f'dt_divisor_{divisor}','phase3_run_id':row['run_id'],
        'source_phase4_seg3':str(origin.resolve()),'source_sha256':sha256(origin),
        'p':float(row['p']),'M':float(row['M']),'family':'Z','N':int(row['N']),
        'nu':0.0,'project_half':True,'T_cross':period,'dt_original':base_dt,
        'dt':dt,'dt_divisor':divisor,'tau_start':TAU_BEGIN,'tau_end':end_tau,
        'first_step':k0,'last_step':k1,'steps_per_tau':steps_tau,'fixed_dt':True,
        'newton_atol':float(row['newton_atol']),'newton_rtol':float(row['newton_rtol']),
        'newton_max_iter_original':int(row['newton_max_iter']),
        'fallback_variants':['original','extended_euler','extended_constant'],
        'changes_to_model':False,'changes_to_spatial_operator':False,
        'origin_does_not_include_half_dt':True,
        'python':sys.version.split()[0], 'numpy':np.__version__,
        'scipy':scipy.__version__,'h5py':h5py.__version__, 'platform':platform.platform(),
    }
    output.parent.mkdir(parents=True,exist_ok=True)
    recorder=H5Recorder(output,model,config,'Z',1.)
    stats=RunStats(mode=f'fase4b_dt_divisor_{divisor}')
    fallback={name:0 for name,_ in solvers}
    beginning=time.perf_counter()
    try:
        recorder(k0*dt,u,stats)
        for k in range(k0+1,k1+1):
            failures=[]
            for name,solver in solvers:
                try:
                    new_u,info=solver.step(u,dt)
                    break
                except NewtonFailure as e:
                    failures.append(f'{name}: {e}')
            else:
                info_fail={
                    'status':'FAILED_FIXED_DT','N':int(row['N']),'dt_divisor':divisor,
                    'tau_before_step':(k-1)/steps_tau, 'tau_failed_step':k/steps_tau,
                    'dt_physical':dt,'tried':failures,'fallback_counts':fallback,
                    'last_saved_tau':float(recorder.h5['t'][-1])/period,
                    'source_seg3':str(origin), 'partial_HDF5':str(output),
                }
                output.with_suffix('.failure.json').write_text(json.dumps(info_fail,indent=2,ensure_ascii=False)+'\n')
                raise NewtonFailure('FASE4B_FIXED_DT_UNRESOLVED '+json.dumps(info_fail,ensure_ascii=False))
            u=new_u
            fallback[name]+=1
            stats.add_step(info,dt)
            stats.final_time=k*dt
            recorder.on_step(k*dt,dt,info,'accepted',float('nan'))
            if should_save(k,steps_tau) or k==k1:
                recorder(k*dt,u,stats)
            if (k-k0)%max(1,(k1-k0)//10)==0:
                print('FASE4B_PROGRESO','N',row['N'],'divisor',divisor,
                      'tau',f'{k/steps_tau:.6f}','fallback',fallback,flush=True)
        recorder.finish(stats)
    except BaseException as e:
        recorder.fail(e)
        raise
    metrics=validate_result(output,row,divisor,end_tau)
    audit={
        'status':'COMPLETED','N':int(row['N']),'dt_divisor':divisor,
        'source_checkpoint':str(origin),'source_sha256':config['source_sha256'],
        'tau_start':TAU_BEGIN,'tau_end':end_tau,'dt':dt,
        'elapsed_seconds':time.perf_counter()-beginning,
        'fallback_counts':fallback,
        **metrics,
    }
    output.with_suffix('.audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n')
    print('FASE4B_BLOQUE_OK','N',int(row['N']),'divisor',divisor,
          'tau_fin',end_tau,'fallback',fallback,'rms_max',metrics['max_scaled_newton_rms'],flush=True)
    return audit


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case-index',type=int,required=True,choices=(2,3))
    p.add_argument('--dt-divisor',type=int,required=True,choices=(2,4))
    p.add_argument('--manifest',default='fase3/campaign_main.csv')
    p.add_argument('--base',default='.')
    p.add_argument('--output',default='fase4b/results')
    p.add_argument('--end-tau',type=float,default=TAU_END)
    args=p.parse_args()
    row=rows_for_case(args.manifest)[args.case_index]
    run(row,base=args.base,divisor=args.dt_divisor,output=args.output,end_tau=args.end_tau)

if __name__=='__main__':main()
