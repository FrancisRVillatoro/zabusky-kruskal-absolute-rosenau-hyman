"""CNSNS phase 4B: fixed-step, half-dt restart and fourth-return comparison."""
