import csv
import json
import tempfile
import unittest
from pathlib import Path

import h5py
import numpy as np

from absk_radau.model import PeriodicAbsK
from absk_radau.io import H5Recorder
from absk_radau.radau_mass import RunStats
from fase4b.run_block import (run, source_for, is_completed, should_save, validate_result)
from fase4b.analyze import (fourth_return, compare_fields, TICKS, main_analysis)


def row(n):
    p=2.25; M=4.;T_cross=2*np.pi*M*p/(p-1)/((p+1)/(2*p))
    return dict(N=str(n),p=str(p),M=str(int(M)),nu='0',dt=str(T_cross/3200),T_cross=str(T_cross),
                newton_atol='1e-11',newton_rtol='1e-9',newton_max_iter='12',
                run_id=('Z_p225_M4__space_low' if n==450 else ('Z_p225_M4__space_mid' if n==900 else 'Z_p225_M4__space_high')),
                family='Z',project_half='1',save_every='32',tau_end='1.25')


def fixture(root,r):
    n=int(r['N']);p=float(r['p']);M=float(r['M']);L=2*np.pi*M*p/(p-1)
    model=PeriodicAbsK(n,L,p,0)
    f=root/'fase4'/'results'/'long'/f'Z_p225_M4_N{n}_seg3.h5'
    cfg={'phase':'fase4','mode':'seg3','phase3_run_id':r['run_id'],
         'dt':float(r['dt']),'p':p,'M':M,'nu':0,'project_half':True}
    record=H5Recorder(f,model,cfg,'Z',1.)
    u=np.cos(2*np.pi*model.x/L)
    record(3.25*float(r['T_cross']),u,RunStats())
    record.finish(RunStats())
    return f


class Tests(unittest.TestCase):
    def test_sample_grid(self):
        self.assertTrue(should_save(4*6400,6400))
        self.assertTrue(should_save(round(4.001*6400),6400))
        self.assertFalse(should_save(round(3.5*6400)+1,6400))

    def test_local_min_and_modal_fingerprint(self):
        tau=np.arange(3.85,4.15,.0003125)
        n=64
        x=np.linspace(0,2*np.pi,n,endpoint=False)
        fields=np.array([np.cos(x)+.05*np.cos(5*x) for t in tau])
        d=np.zeros((len(tau),10))
        # This is a synthetic diagnostic used ONLY to test local-min selection.
        d[:,5]=.21+2*(tau-4.03375)**2
        d[:,8]=.97
        d[:,9]=d[:,5]**2-(d[:,8]-1)**2
        d[:,7]=.93
        data={'ticks':np.rint(tau*TICKS).astype(int),'d':d,'u':fields,
              'relative_invariant_drift':0.0}
        ret=fourth_return(data)
        self.assertEqual(ret['status'],'LOCAL_MIN')
        self.assertAlmostEqual(ret['tau'],4.03375,delta=.0003125)
        self.assertTrue(np.isfinite(ret['e5_over_H']))

    def test_identical_fields_difference_zero(self):
        n=64;times=np.array([4.0,4.01,4.02]);ticks=np.rint(times*TICKS).astype(int)
        x=np.linspace(0,2*np.pi,n,endpoint=False)
        u=np.array([np.cos(x+q) for q in range(3)])
        data={'ticks':ticks,'u':u}
        c,records=compare_fields(data,data,n)
        self.assertEqual(c['n_shared'],3)
        self.assertLess(c['max_L2'],1e-13)
        self.assertEqual(len(records),3)

    def test_checkpoint_and_actual_radau_short_run_and_reuse(self):
        # This is a synthetic checkpoint at tau=3.25, NOT a physical phase-4 solution.
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            r=row(900)
            f=fixture(root,r)
            self.assertEqual(source_for(r,root),f)
            out=root/'fase4b'/'results'
            audit=run(r,base=root,output=out,divisor=2,end_tau=3.25125) # 8 Radau steps
            self.assertEqual(audit['n_steps'],8)
            target=out/'dt_divisor_2'/'Z_p225_M4_N900_seg4_dtdiv2.h5'
            self.assertTrue(is_completed(target,r,2,3.25125))
            self.assertLess(audit['max_scaled_newton_rms'],1.000001)
            reused=run(r,base=root,output=out,divisor=2,end_tau=3.25125)
            self.assertEqual(reused['n_steps'],8)
            self.assertRaises(FileExistsError,run,r,base=root,output=out,divisor=2,end_tau=3.2525)

    def test_actual_short_quarter_N1800(self):
        # Numerical smoke only: arbitrary synthetic restart state at tau=3.25.
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            r=row(1800)
            fixture(root,r)
            a=run(r,base=root,output=root/'fase4b/results',divisor=4,end_tau=3.250625)
            self.assertEqual(a['n_steps'],8)
            self.assertEqual(a['dt_divisor'],4)
            self.assertLessEqual(a['max_scaled_newton_rms'],1.00000001)

    def test_analysis_complete_on_synthetic_h5s(self):
        # These artificial fields test report mechanics only: not a PDE result.
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)
            man=base/'fase3'/'campaign_main.csv'
            man.parent.mkdir(parents=True)
            cfg_rows=[]
            for n,role in [(450,'space_low'),(900,'space_mid'),(1800,'space_high')]:
                a=row(n)
                a.update(case='Z_p225_M4',role=role)
                cfg_rows.append(a)
            with man.open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(cfg_rows[0].keys()))
                w.writeheader();w.writerows(cfg_rows)
            for div in (2,4):
                for n in (900,1800):
                    r=row(n);p=float(r['p']);L=2*np.pi*p*4/(p-1)
                    model=PeriodicAbsK(n,L,p,0)
                    out=base/'fase4b'/'results'/f'dt_divisor_{div}'/f'Z_p225_M4_N{n}_seg4_dtdiv{div}.h5'
                    conf={'phase':'fase4b','mode':f'dt_divisor_{div}','dt_divisor':div,
                          'project_half':True}
                    rec=H5Recorder(out,model,conf,'Z',1.)
                    xi=2*np.pi*np.arange(n)/n
                    for tau in (3.25,3.9,4.0,4.02,4.03,4.04,4.1,4.25):
                        amp=.15+.1*(tau-4.03)**2
                        u=np.cos(xi)+amp*np.cos(5*xi)
                        rec(tau*float(r['T_cross']),u,RunStats())
                    rec.finish(RunStats())
                    out.with_suffix('.audit.json').write_text(json.dumps({'status':'COMPLETED'}))
            output=base/'phase4b_out.zip'
            report=main_analysis(base,base/'fase4b/results',base/'fase4b/results/analysis',output)
            self.assertIn('DATOS_4B_COMPLETOS',report['status'])
            self.assertTrue(output.exists())
            self.assertEqual(len([x for x in report['fourth_returns'] if x['status']=='LOCAL_MIN']),4)
            self.assertEqual(len([x for x in report['full_field_budget'] if x['type']=='spatial']),2)

if __name__=='__main__':unittest.main()
