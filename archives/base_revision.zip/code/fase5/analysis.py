"""Read-only quantitative classification of the P family for CNSNS.

Inputs: actual Phase-3 P,M=4 HDF5 and new Phase-5 P,M=8 HDF5.
No integration takes place here, and no original HDF5 is modified.
Outputs: timewise peak counts, local valley/fwhm, three template fits,
spatial and temporal budgets, phase-space profiles, figures and a report.
"""
from __future__ import annotations
import argparse,csv,json,math,hashlib,platform,sys
from pathlib import Path
import numpy as np
import h5py
from .classification import (profile_metrics,fit_compacton_train,morphology_label,
                             compacton_width,theoretical_half_prominence_ratio)

SELECT_TAU=(0.,.25,.5,1.,2.)
CASES={
 'P_p2_M4':{'M':4,'p':2.,'N':(500,1000,2000),'source':'fase3/results/main'},
 'P_p2_M8':{'M':8,'p':2.,'N':(1000,2000,4000),'source':'fase5/results/m8'},
}
ROLES=('space_low','space_mid','space_high','time_x2','time_x4')

def crossing(p,M):
    return (2*np.pi*M*p/(p-1.))/((p+1.)/(2*p))

def _obj(v):
    if isinstance(v,dict):return {str(k):_obj(z) for k,z in v.items()}
    if isinstance(v,(list,tuple)):return [_obj(z) for z in v]
    if isinstance(v,np.ndarray):return _obj(v.tolist())
    if isinstance(v,np.generic):return _obj(v.item())
    if isinstance(v,float) and not np.isfinite(v):return None
    return v

def _csv(path,rows,columns=None):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if columns is None:
        columns=[]
        for r in rows:
            for k in r:
                if k not in columns:columns.append(k)
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,columns,extrasaction='ignore');w.writeheader();w.writerows(rows)

def load_hdf5(path,p,M,N,*,allow_short=False):
    path=Path(path)
    with h5py.File(path,'r') as h:
        status=str(h.attrs['status'])
        if status!='COMPLETED':raise ValueError(f'incomplete HDF5: {path}: {status}')
        if str(h.attrs['family']).upper()!='P':raise ValueError(f'non-P case: {path}')
        if abs(float(h.attrs['p'])-p)>1e-10 or int(h.attrs['n_cells'])!=N:
            raise ValueError(f'wrong p/N in {path}')
        if float(h.attrs['nu'])!=0.:raise ValueError(f'nu not zero in {path}')
        L=2*np.pi*M*p/(p-1.)
        if not np.isclose(float(h.attrs['period']),L,rtol=0,atol=1e-9):
            raise ValueError(f'wrong L in {path}')
        t=np.array(h['t'][:]);U=np.array(h['u'][:]);x=np.array(h['x'][:])
        diag=np.array(h['diagnostics'][:]) if 'diagnostics' in h else None
        cfg=json.loads(h.attrs['config_json']) if 'config_json' in h.attrs else {}
    if len(t)!=len(U) or U.shape[1]!=N or not np.all(np.isfinite(U)):
        raise ValueError(f'bad dataset dimensions or NaN in {path}')
    if len(t)<2 or np.any(np.diff(t)<=0):raise ValueError('invalid time vector')
    tau=t/crossing(p,M)
    if not allow_short:
        if len(tau)!=201 or max(abs(float(tau[-1])-2.),abs(float(tau[0])))>2e-9:
            raise ValueError(f'Expected tau=0:0.01:2 (201 snapshots): {path}')
        if np.max(abs(tau-np.arange(201)*.01))>1e-8:
            raise ValueError(f'Not aligned with 0.01 tau sampling: {path}')
    if not np.allclose(x,np.arange(N)*L/N,atol=1e-9,rtol=0):
        raise ValueError(f'incorrect mesh {path}')
    masses=(L/N)*np.sum(U,axis=1)
    invariants=(L/N)*np.sum(np.abs(U)**(p+1)/(p+1),axis=1)
    return dict(tau=tau,u=U,x=x,L=L,p=p,M=M,N=N,diag=diag,config=cfg,
                masses=masses,invariants=invariants,
                filename=str(path),size_bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def _spatial_field_difference(a,b):
    """Exact node subsampling; no interpolation for nested meshes."""
    na,nb=a['N'],b['N']
    if nb%na:raise ValueError('grids are not nested')
    if a['u'].shape[0]!=b['u'].shape[0] or not np.allclose(a['tau'],b['tau'],atol=1e-10,rtol=0):
        raise ValueError('time vectors not aligned')
    coarse=a['u'];fine=b['u'][:,::nb//na]
    norms=np.linalg.norm(coarse[0]);norms=max(norms,1.e-15)
    diff=np.linalg.norm(fine-coarse,axis=1)/norms
    return diff

def _write_figure(fig,path):
    fig.savefig(path+'.png',dpi=180,bbox_inches='tight')
    fig.savefig(path+'.pdf',bbox_inches='tight')
    import matplotlib.pyplot as plt
    plt.close(fig)

def _plot(all_data,snap_rows,fit_profiles,comparisons,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    out=Path(out)
    for case,info in CASES.items():
        main=all_data.get((case,'space_high'))
        if main is None:continue
        M=info['M'];L=main['L']
        fig,ax=plt.subplots(figsize=(9.4,4.6),constrained_layout=True)
        for tau in SELECT_TAU:
            k=int(round(tau/.01))
            ax.plot(main['x']/L,main['u'][k],lw=1.35,label=rf'$\tau={tau:g}$')
        ax.set(xlabel=r'$x/L$',ylabel='$u$',title=f'P: p=2, M={M} — perfiles (N={main["N"]})',xlim=(0,1))
        ax.grid(alpha=.2);ax.legend(ncol=5,fontsize=8)
        _write_figure(fig,str(out/f'Fig5_P_M{M}_profiles'))
    fig,axes=plt.subplots(2,2,figsize=(11.2,7.8),constrained_layout=True)
    for i,case in enumerate(CASES):
        rlist=[r for r in snap_rows if r['case']==case and r['role'] in ('space_low','space_mid','space_high')]
        for role in ('space_low','space_mid','space_high'):
            z=sorted((a for a in rlist if a['role']==role),key=lambda q:q['tau'])
            if not z:continue
            axes[i,0].plot([a['tau'] for a in z],[a['n_peaks'] for a in z],
                           lw=1.1,label=role)
            axes[i,1].plot([a['tau'] for a in z],[a['q01_over_peak'] for a in z],
                           lw=1.1,label=role)
        axes[i,0].set(ylabel=f'{case}: número de máximos',xlabel=r'$\tau$',ylim=(-.5,None))
        axes[i,1].set(ylabel=f'{case}: cuantil 1% / amplitud',xlabel=r'$\tau$')
        for a in axes[i]:a.grid(alpha=.2);a.legend(fontsize=7)
    _write_figure(fig,str(out/'Fig5_peakcount_background'))
    for case,info in CASES.items():
        d=all_data.get((case,'space_high'))
        if d is None:continue
        fig,ax=plt.subplots(figsize=(9.2,4.6),constrained_layout=True)
        # Plot time-space evolution of the actual unfiltered solution.
        im=ax.imshow(d['u'],origin='lower',aspect='auto',interpolation='nearest',
                     extent=(0,1,d['tau'][0],d['tau'][-1]),cmap='viridis')
        fig.colorbar(im,ax=ax,label='$u$')
        ax.set(xlabel=r'$x/L$',ylabel=r'$\tau$',title=f'P: p=2, M={info["M"]}, N={d["N"]}')
        _write_figure(fig,str(out/f'Fig5_P_M{info["M"]}_spacetime'))
    for case,info in CASES.items():
        dat=all_data.get((case,'space_high'))
        if dat is None:continue
        selected=[(tau,fit_profiles.get((case,'space_high',tau))) for tau in (.5,2.)]
        fig,axes=plt.subplots(1,2,figsize=(11.5,3.8),constrained_layout=True)
        for ax,(tau,fp) in zip(axes,selected):
            idx=int(round(tau/.01));ax.plot(dat['x']/dat['L'],dat['u'][idx],lw=1.6,label='Campo numérico')
            if fp is not None:
                for model,label in (('zero','Compactones exactos (b=0)'),
                                    ('pedestal','Perfil compacto + fondo'),
                                    ('free_width','Anchura libre + fondo')):
                    if fp.get(model) is not None:
                        ax.plot(dat['x']/dat['L'],fp[model],lw=1.1,ls='--',label=label)
            ax.set(xlabel=r'$x/L$',ylabel='$u$',title=rf'$M={info["M"]},\ \tau={tau:g}$',xlim=(0,1))
            ax.grid(alpha=.2)
        axes[0].legend(fontsize=7,frameon=False)
        _write_figure(fig,str(out/f'Fig5_P_M{info["M"]}_compacton_fits'))
    fig,axes=plt.subplots(1,2,figsize=(10.6,4.),constrained_layout=True)
    for case in CASES:
        dat=all_data.get((case,'space_high'))
        if dat is None:continue
        vals=[r for r in snap_rows if r['case']==case and r['role']=='space_high']
        vals=sorted(vals,key=lambda z:z['tau'])
        axes[0].plot([r['tau'] for r in vals],[r['fwhm_median_Wp'] for r in vals],label=case)
    axes[0].axhline(theoretical_half_prominence_ratio(2.),ls='--',color='gray',label='Compactón p=2')
    axes[0].set(xlabel=r'$\tau$',ylabel=r'Mediana FWHM/$W_p$',title='Anchura de los máximos')
    axes[0].legend(fontsize=8)
    for r in comparisons:
        if r.get('metric')=='field_L2':
            vals=r.get('_curve')
            if vals is not None:axes[1].plot(r['_tau'],vals,label=r['comparison'])
    axes[1].set(xlabel=r'$\tau$',ylabel=r'$\|u_{h}-u_{h/2}\|_2/\|u_0\|_2$',
                title='Acuerdo entre campos')
    axes[1].legend(fontsize=7)
    for a in axes:a.grid(alpha=.2)
    _write_figure(fig,str(out/'Fig5_width_and_refinement'))

def analyze(root,output,*,only_cases=None):
    root=Path(root);out=Path(output);out.mkdir(parents=True,exist_ok=True)
    datasets={};inventory=[]
    for case,info in CASES.items():
        if only_cases is not None and case not in only_cases:continue
        for role,n in zip(('space_low','space_mid','space_high'),info['N']):
            f=root/info['source']/(case+'__'+role+'.h5')
            if f.exists():
                try:
                    dat=load_hdf5(f,info['p'],info['M'],n)
                    datasets[(case,role)]=dat
                    inventory.append(dict(case=case,role=role,N=n,status='VALID',
                                          file=str(f),sha256=dat['sha256'],size_bytes=dat['size_bytes'],
                                          max_mass_drift_abs=float(np.max(abs(dat['masses']-dat['masses'][0]))),
                                          max_invariant_drift_rel=float(np.max(abs(dat['invariants']-dat['invariants'][0]))/max(abs(dat['invariants'][0]),1e-15))))
                    print('FASE5_HDF5_VALIDO',case,role,'N',n,flush=True)
                except Exception as e:
                    inventory.append(dict(case=case,role=role,N=n,status='INVALID',file=str(f),error=str(e)))
            else:
                inventory.append(dict(case=case,role=role,N=n,status='MISSING',file=str(f)))
        if case=='P_p2_M8':
            for role in ('time_x2','time_x4'):
                n=info['N'][-1];f=root/info['source']/(case+'__'+role+'.h5')
                if f.exists():
                    try:
                        dat=load_hdf5(f,info['p'],info['M'],n)
                        datasets[(case,role)]=dat
                        inventory.append(dict(case=case,role=role,N=n,status='VALID',
                                              file=str(f),sha256=dat['sha256'],size_bytes=dat['size_bytes'],
                                              max_mass_drift_abs=float(np.max(abs(dat['masses']-dat['masses'][0]))),
                                              max_invariant_drift_rel=float(np.max(abs(dat['invariants']-dat['invariants'][0]))/max(abs(dat['invariants'][0]),1e-15))))
                    except Exception as e:
                        inventory.append(dict(case=case,role=role,N=n,status='INVALID',file=str(f),error=str(e)))
                else:inventory.append(dict(case=case,role=role,N=n,status='MISSING',file=str(f)))
    if not datasets:
        _csv(out/'inventory.csv',inventory)
        raise RuntimeError('There are no VALID P-profile HDF5 inputs')
    metrics=[];peaks=[];sens_rows=[];fit_rows=[];fit_profiles={};classified=[];prof_rows=[]
    for (case,role),dat in datasets.items():
        tauvec=dat['tau'];U=dat['u'];p=dat['p'];L=dat['L'];N=dat['N'];
        print('FASE5_MIDIENDO',case,role,len(tauvec),'snapshots',flush=True)
        for k,(tau,u) in enumerate(zip(tauvec,U)):
            sm,pk,se=profile_metrics(u,L,p,tau=float(tau))
            short=dict(case=case,role=role,snapshot=k,N=N,tau=float(tau))
            metrics.append(dict(**short,**{a:v for a,v in sm.items() if a not in ('N','tau')},
                                mass=float(dat['masses'][k]),
                                mass_drift_abs=float(abs(dat['masses'][k]-dat['masses'][0])),
                                I_pplus1=float(dat['invariants'][k]),
                                I_pplus1_drift_rel=float(abs(dat['invariants'][k]-dat['invariants'][0])/max(abs(dat['invariants'][0]),1e-15))))
            peaks.extend(dict(**short,**a) for a in pk)
            sens_rows.extend(dict(**short,**a) for a in se)
            if k not in (0,25,50,100,200):continue
            models={};fitdata={}
            for fitname in ('zero','pedestal','free_width'):
                fr,pred=fit_compacton_train(u,L,p,[a['peak_index'] for a in pk],model=fitname)
                fit_rows.append(dict(**short,**fr))
                models[fitname]=fr;fitdata[fitname]=pred
            fit_profiles[(case,role,float(round(tau,4)))]=fitdata
            label=morphology_label(sm,models.get('zero'),models.get('pedestal'),models.get('free_width'))
            classified.append(dict(**short,classification=label,peak_count=sm['n_peaks'],
                                   robust=sm['count_robust'],min_over_peak=sm['minimum_over_peak'],
                                   q01_over_peak=sm['q01_over_peak'],
                                   median_FWHM_Wp=sm['fwhm_median_Wp'],
                                   rms_compacton_zero=models['zero'].get('rms_over_peak'),
                                   fitted_pedestal_over_peak=models['pedestal'].get('background_over_peak'),
                                   rms_fit_pedestal=models['pedestal'].get('rms_over_peak'),
                                   free_width_over_Wp=models['free_width'].get('width_over_Wp')))
            if role=='space_high':
                stride=max(1,N//800)
                for j in range(0,N,stride):
                    prof_rows.append(dict(case=case,tau=float(tau),x=float(dat['x'][j]),
                                          x_over_L=j/N,u=float(u[j]),
                                          comp_zero=float(fitdata['zero'][j]) if fitdata['zero'] is not None else None,
                                          comp_pedestal=float(fitdata['pedestal'][j]) if fitdata['pedestal'] is not None else None,
                                          comp_free_width=float(fitdata['free_width'][j]) if fitdata['free_width'] is not None else None))
    comparisons=[]
    def compare(case,role_a,role_b):
        a=datasets.get((case,role_a));b=datasets.get((case,role_b))
        if a is None or b is None:return
        diff=_spatial_field_difference(a,b)
        row=dict(case=case,comparison=role_a+'_vs_'+role_b,metric='field_L2',
                 Ncoarse=a['N'],Nfine=b['N'],norm_final=float(diff[-1]),
                 norm_max=float(max(diff)),norm_mean=float(np.mean(diff)),
                 delta_tau=.01,_curve=diff,_tau=a['tau'])
        comparisons.append(row)
        for i,tau in enumerate(a['tau']):
            # pointwise raw profile difference curves, not just the final norm
            comparison_curves.append(dict(case=case,comparison=row['comparison'],
                                          tau=float(tau),norm_L2=float(diff[i])))
    comparison_curves=[]
    for case in CASES:
        if only_cases is not None and case not in only_cases:continue
        compare(case,'space_low','space_mid');compare(case,'space_mid','space_high')
    compare('P_p2_M8','time_x2','space_high');compare('P_p2_M8','time_x4','time_x2')
    grid_consistency=[]
    findrow={(r['case'],r['role'],round(r['tau'],4)):r for r in metrics}
    for case in CASES:
        if only_cases is not None and case not in only_cases:continue
        for t in SELECT_TAU:
            ref=[findrow.get((case,role,t)) for role in ('space_low','space_mid','space_high')]
            if any(r is None for r in ref):
                grid_consistency.append(dict(case=case,tau=t,available=False))
                continue
            low,mid,hi=ref
            nums=(low['n_peaks'],mid['n_peaks'],hi['n_peaks'])
            rob=all(q['count_robust'] for q in ref)
            row=dict(case=case,tau=t,available=True,counts=';'.join(map(str,nums)),
                     counts_equal=(len(set(nums))==1),threshold_robust_on_all=rob,
                     q01_ratio_low=float(low['q01_over_peak']),q01_ratio_mid=float(mid['q01_over_peak']),
                     q01_ratio_high=float(hi['q01_over_peak']),
                     delta_q01_mid_high=float(hi['q01_over_peak']-mid['q01_over_peak']),
                     min_ratio_high=float(hi['minimum_over_peak']),
                     width_median_low=low['fwhm_median_Wp'],width_median_mid=mid['fwhm_median_Wp'],
                     width_median_high=hi['fwhm_median_Wp'])
            grid_consistency.append(row)
    _csv(out/'inventory.csv',inventory)
    _csv(out/'snapshots.csv',metrics)
    _csv(out/'conservation.csv',[{k:r[k] for k in ('case','role','N','tau','mass','mass_drift_abs','I_pplus1','I_pplus1_drift_rel')}
                                 for r in metrics])
    _csv(out/'peaks.csv',peaks)
    _csv(out/'count_threshold_sweep.csv',sens_rows)
    _csv(out/'compacton_fits.csv',fit_rows)
    _csv(out/'morphological_classification.csv',classified)
    _csv(out/'profile_fits.csv',prof_rows)
    _csv(out/'grid_consistency.csv',grid_consistency)
    _csv(out/'field_comparisons.csv',[{k:v for k,v in r.items() if not k.startswith('_')} for r in comparisons])
    _csv(out/'field_curves.csv',comparison_curves)
    _plot(datasets,metrics,fit_profiles,comparisons,out)
    expected=8
    valid=sum(r['status']=='VALID' for r in inventory)
    core=[r for r in grid_consistency if r['tau'] in (.5,1.,2.)]
    robust=bool(core) and all(r['available'] and r.get('counts_equal') and
                                  r.get('threshold_robust_on_all') for r in core)
    status=dict(phase='Fase5',valid_runs=valid,expected_runs=expected,
                status='COMPLETE' if valid==expected else 'PARTIAL',
                reviewer_panel='P,p=2,M=8; old Figure 1',
                control_case='P,p=2,M=4 from Phase 3',
                counts_robust_on_both_M_over_tau_p5_1_2=robust,
                phase5_scientifically_closed=bool(valid==expected and robust),
                warning=('Even complete, robust numerical morphology does not certify compact support '
                         'or well-posed PDE dynamics.'),
                exact_support_width_p2=float(compacton_width(2.)),
                exact_FWHM_over_support_p2=float(theoretical_half_prominence_ratio(2.)),
                environment=dict(python=sys.version.split()[0],numpy=np.__version__,h5py=h5py.__version__,platform=platform.platform()),
                selected_tau=SELECT_TAU,threshold_sweep=dict(prominence=(.04,.08,.12,.16),
                                                             separation_Wp=(.2,.3,.4)))
    (out/'status.json').write_text(json.dumps(_obj(status),indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    # Generate a small, data-driven audit and table. The text intentionally
    # avoids categorical compacton claims, regardless of fit quality.
    lines=[
        '# Fase 5 — Clasificación de estructuras P (CNSNS)', '',
        f"- Estado computacional: **{status['status']}** ({valid}/{expected} HDF5 válidos).",
        '- Familia exacta analizada: P(x,0) = (1+cos(2πx/L))/2; p=2; ν=0.',
        '- En el manuscrito rechazado, la Figura 1 mostraba M=8. M=4 es control independiente.',
        f"- Anchura del compactón teórico W_p={compacton_width(2.):.10g}; "
        f"FWHM/W_p={theoretical_half_prominence_ratio(2.):.8f} para p=2.",
        '- Compactón estricto: perfil exacto, nulo fuera de su soporte; un ajuste discreto no demuestra soporte compacto.',
        '- Conteo: máximos prominentes sobre perfil suavizado con escala física Wp/120, más auditoría en 12 elecciones de umbral/separación.',
        '- Fondo: mínimo de malla, cuantil 1%, valles entre máximos, medida de los intervalos casi nulos.',
        '- Conservación: media y semidiscreto I_{p+1}, con deriva absoluta y relativa en cada instante.',
        '- Forma: mínimos cuadrados globales para suma de compactones de anchura Wp sobre fondo 0, sobre pedestal, y con anchura libre.',
        '', '## Conteos y clasificación en instantes de la figura', '',
        '| Caso | τ | Conteos N baja/media/alta | Robusto | q01/max alta | Clasificación (malla alta) |',
        '|---|---:|---|---|---:|---|']
    classification_lookup={(r['case'],r['role'],round(r['tau'],4)):r for r in classified}
    for r in grid_consistency:
        if r['tau'] not in SELECT_TAU:continue
        z=classification_lookup.get((r['case'],'space_high',r['tau']))
        qs=f"{r.get('q01_ratio_high',float('nan')):.6g}" if r.get('available') else '—'
        lines.append(f"| {r['case']} | {r['tau']:.2f} | {r.get('counts','—')} | "
                     f"{'sí' if r.get('counts_equal') and r.get('threshold_robust_on_all') else 'no/pendiente'} | "
                     f"{qs} | {z['classification'] if z else 'pendiente'} |")
    lines.extend(['','## Discrepancias de campo entre discretizaciones','',
                  '| Caso | Comparación | Diferencia final | Máximo temporal |',
                  '|---|---|---:|---:|'])
    for r in comparisons:
        lines.append(f"| {r['case']} | {r['comparison']} | {r['norm_final']:.7g} | {r['norm_max']:.7g} |")
    lines.extend(['','## Dictamen', '',
                  ('Se han obtenido los datos y controles previstos. Clasificación de conteos estable '
                   'en los instantes de referencia; no es prueba matemática de soporte compacto.'
                   if status['phase5_scientifically_closed'] else
                   '**No declarar cerrada la clasificación cuantitativa sin resolver los controles pendientes.** '
                   'Las filas no robustas o ausentes se identifican arriba.'),
                  '', '## Limitaciones metodológicas', '',
                  '- M es capacidad geométrica L/Wp, NO el número de pulsos observado.',
                  '- Un pedestal positivo y/o la ausencia de huecos impide llamar a los lóbulos compactones individuales de soporte disjunto, salvo evidencia independiente.',
                  '- La coincidencia con un perfil coseno a anchura fija no demuestra una solución viajera ni una solución débil de la PDE.',
                  '- El fit con anchura libre es exclusivamente una comparación morfológica, no una familia exacta de soluciones.',
                  '- Comparar las tres mallas antes de citar un número de máximos como fenómeno continuo.',
                  '- El filtro se usa solo para localizar los máximos: fondo, anchuras y ajustes se comparan contra los campos originales.',
                  ''])
    (out/'INFORME_FASE5.md').write_text('\n'.join(lines),encoding='utf-8')
    print('FASE5_ANALISIS_'+status['status'],valid,'de',expected,'run(s) validos',flush=True)
    return status


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default='.')
    ap.add_argument('--output',default='fase5/results/analysis')
    args=ap.parse_args()
    analyze(args.root,args.output)

if __name__=='__main__':main()
