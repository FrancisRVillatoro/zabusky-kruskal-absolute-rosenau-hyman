"""An independent 5-task P,p=2,M=8 campaign: the actual JNW Fig.1 case.
The 3 P,p=2,M=4 runs from Phase 3 are used WITHOUT recomputation.
"""
from __future__ import annotations
import math,csv,hashlib,argparse
from pathlib import Path

FIELDS=['task_id','run_id','case','group','role','p','M','family','project_half','N',
        'nu','tau_end','tau_out','T_cross','save_every','dt','newton_atol',
        'newton_rtol','newton_max_iter','max_steps']

def campaign():
    p=2.;M=8;L=2*math.pi*M*p/(p-1.)
    tcross=L/((p+1)/(2*p));tauout=.01
    k=4*math.ceil(tcross*tauout/.02/4) # 68, so Radau dt ~0.01971
    specs=[('space_low',1000,k),('space_mid',2000,k),('space_high',4000,k),
           ('time_x2',4000,k//2),('time_x4',4000,k//4)]
    rows=[]
    for i,(role,n,save_every) in enumerate(specs,1):
        dt=tcross*tauout/save_every
        rows.append(dict(task_id=i,run_id=f'P_p2_M8__{role}',case='P_p2_M8',
                         group='phase5',role=role,p=p,M=M,family='P',project_half=0,
                         N=n,nu=0.,tau_end=2.,tau_out=tauout,T_cross=tcross,
                         save_every=save_every,dt=dt,
                         newton_atol=1.e-11,newton_rtol=1.e-9,newton_max_iter=12,
                         max_steps=200000))
    assert len(rows)==5 and k%4==0
    return rows

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',default='fase5/campaign_P_p2_M8.csv')
    args=parser.parse_args()
    p=Path(args.out)
    if p.exists():raise SystemExit(f'Manifest already exists: {p}')
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(campaign())
    print('FASE5_MANIFEST_OK',p,hashlib.sha256(p.read_bytes()).hexdigest())

if __name__=='__main__':main()
