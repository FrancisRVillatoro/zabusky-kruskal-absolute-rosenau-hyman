"""Read-only preflight for existing P M4 HDF5 and phase-5 manifest."""
from __future__ import annotations
import argparse,unittest,hashlib,json
from pathlib import Path
import h5py,numpy as np
from .design import campaign
from .analysis import load_hdf5


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',default='.')
    args=ap.parse_args()
    root=Path(args.root)
    expected={a['run_id']:a for a in campaign()}
    import csv
    manifest=root/'fase5/campaign_P_p2_M8.csv'
    with manifest.open() as f: got=list(csv.DictReader(f))
    assert [a['run_id'] for a in got]==list(expected)
    for a in got:
        exp=expected[a['run_id']]
        for k,v in exp.items():
            if isinstance(v,(int,float)):
                assert np.isclose(float(a[k]),v,atol=1e-14,rtol=1e-12),(a['run_id'],k)
            else: assert a[k]==v,(a['run_id'],k)
    for n,role in ((500,'space_low'),(1000,'space_mid'),(2000,'space_high')):
        f=root/f'fase3/results/main/P_p2_M4__{role}.h5'
        if not f.exists():raise FileNotFoundError(f'Required phase-3 P M4 trajectory: {f}')
        info=load_hdf5(f,2.,4,n)
        if len(info['tau'])!=201:raise ValueError(f'201 snapshots required: {f}')
        print('FASE5_FUENTE_OK',f,'N',n,'tmax',info['tau'][-1],flush=True)
    suite=unittest.defaultTestLoader.discover(str(root/'fase5/tests'),pattern='test_*.py')
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():raise SystemExit(1)
    print('FASE5_VERIFICACION_OK',hashlib.sha256(manifest.read_bytes()).hexdigest(),flush=True)

if __name__=='__main__':main()
