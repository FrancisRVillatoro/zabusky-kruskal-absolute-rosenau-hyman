"""CNSNS Phase 5: morphological classification of positive periodic P structures."""
