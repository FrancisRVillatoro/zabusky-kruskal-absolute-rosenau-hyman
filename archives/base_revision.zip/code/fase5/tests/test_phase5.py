import math
import unittest
from pathlib import Path
import tempfile
import numpy as np
import h5py
from fase5.classification import (compacton_width,theoretical_half_prominence_ratio,
  compacton_profile,compacton_train,profile_metrics,fit_compacton_train,
  morphology_label,periodic_gap_length)
from fase5.design import campaign
from fase5.analysis import load_hdf5,_spatial_field_difference

class Phase5Tests(unittest.TestCase):
    def setUp(self):
        self.p=2.;self.W=compacton_width(self.p);self.L=4*self.W
        self.n=1024;self.x=np.arange(self.n)*self.L/self.n
        self.centers=np.array([.5,1.9,3.25])*self.W
        self.pulse=compacton_train(self.x,self.centers,[1.,.6,.8],self.W,2.,self.L)

    def test_exact_width_and_fwhm(self):
        self.assertAlmostEqual(self.W,4*np.pi)
        self.assertAlmostEqual(theoretical_half_prominence_ratio(2.),.5)
        self.assertAlmostEqual(periodic_gap_length(np.ones(self.n),self.L/self.n,.01),0)

    def test_compacton_zero_support(self):
        u=compacton_profile(self.x,center=self.L*.5,amplitude=1.,width=self.W,p=2.,L=self.L)
        self.assertEqual(np.count_nonzero(u>0),self.n//4-1)
        self.assertAlmostEqual(u[self.n//2],1.)
        self.assertEqual(u[self.n//2+self.n//4],0.)

    def test_periodic_peak_counts_and_gap(self):
        s,peaks,checks=profile_metrics(self.pulse,self.L,2.,tau=.5)
        self.assertEqual(s['n_peaks'],3)
        self.assertEqual(s['n_peaks_raw'],3)
        self.assertTrue(s['count_robust'])
        self.assertGreater(s['max_gap_Wp_1pct'],0.1)
        self.assertEqual(len(checks),12)
        self.assertLess(s['q01_over_peak'],.001)

    def test_pedestal_is_detected(self):
        u=.18+self.pulse
        s,peaks,_=profile_metrics(u,self.L,2.)
        self.assertEqual(s['n_peaks'],3)
        self.assertGreater(s['min_value'],.17)
        self.assertEqual(morphology_label(s),'pulsos_sobre_fondo_positivo')
        self.assertEqual(s['max_gap_Wp_1pct'],0.)

    def test_template_fit_compares_zero_and_pedestal(self):
        u=.12+self.pulse
        s,peaks,_=profile_metrics(u,self.L,2.)
        ids=[x['peak_index'] for x in peaks]
        zero,pred0=fit_compacton_train(u,self.L,2.,ids,model='zero',max_nfev=65)
        ped,pred1=fit_compacton_train(u,self.L,2.,ids,model='pedestal',max_nfev=65)
        free,pred2=fit_compacton_train(u,self.L,2.,ids,model='free_width',max_nfev=65)
        self.assertEqual(ped['fit_status'],'SUCCESS')
        self.assertLess(ped['rms_over_peak'],.003)
        self.assertGreater(zero['rms_over_peak'],ped['rms_over_peak']+.01)
        self.assertAlmostEqual(ped['background'],.12,delta=.008)
        self.assertAlmostEqual(free['width_over_Wp'],1.,delta=.04)
        self.assertEqual(morphology_label(s,zero,ped,free),'pulsos_sobre_fondo_positivo')

    def test_initial_P_is_not_M_undiscovered_compactons(self):
        # P(x,0)=cos^2(pi*x/L) contains one maximum, NOT M=4 maxima.
        u=.5*(1+np.cos(2*np.pi*self.x/self.L))
        s,peaks,_=profile_metrics(u,self.L,2.,tau=0.)
        self.assertEqual(s['n_peaks'],1)
        self.assertEqual(s['M_capacity'],4.)
        self.assertGreater(s['fwhm_median_Wp'],.7)

    def test_shift_wrap_invariance(self):
        u=np.roll(self.pulse,self.n//5)
        s,peaks,_=profile_metrics(u,self.L,2.)
        self.assertEqual(s['n_peaks'],3)
        self.assertEqual(s['n_peak_sensitivity_min'],3)

    def test_campaign_p2_M8_and_fixed_time(self):
        rows=campaign()
        self.assertEqual(len(rows),5)
        self.assertEqual([r['N'] for r in rows],[1000,2000,4000,4000,4000])
        self.assertTrue(all(r['project_half']==0 and r['nu']==0 for r in rows))
        self.assertTrue(all(round(r['tau_end']/r['tau_out'])*r['save_every']<=r['max_steps'] for r in rows))
        self.assertEqual(rows[-1]['save_every']*4,rows[0]['save_every'])
        for row in rows:
            self.assertAlmostEqual(row['save_every']*row['dt']/row['T_cross'],.01)

    def test_nested_field_difference(self):
        a=dict(N=64,tau=np.array([0.,.01]),u=np.vstack([np.ones(64),np.ones(64)*2]))
        b=dict(N=128,tau=a['tau'],u=np.vstack([np.ones(128),np.ones(128)*2]))
        self.assertTrue(np.allclose(_spatial_field_difference(a,b),0.))
        b['u'][1]+=0.1
        self.assertAlmostEqual(_spatial_field_difference(a,b)[1],.1)

    def test_real_hdf5_io_contract(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'case.h5'
            N=64;L=self.L;p=self.p;M=4
            with h5py.File(path,'w') as f:
                f.attrs.update(dict(status='COMPLETED',family='P',p=p,nu=0.,
                                    n_cells=N,period=L,config_json='{}'))
                f.create_dataset('x',data=np.arange(N)*L/N)
                f.create_dataset('t',data=np.array([0.,crossing(p,M)*.01]))
                f.create_dataset('u',data=np.ones((2,N)))
            with self.assertRaises(ValueError):load_hdf5(path,p,M,N)
            r=load_hdf5(path,p,M,N,allow_short=True)
            self.assertEqual(r['u'].shape,(2,N))

    def test_numerical_comparison_with_actual_phase2_h5_if_available(self):
        import os
        f=os.environ.get('FASE5_PILOT_H5')
        if not f or not Path(f).exists():return
        with h5py.File(f,'r') as h:
            y=np.asarray(h['u'][-1]);L=float(h.attrs['period']);p=float(h.attrs['p'])
        r,peaks,sens=profile_metrics(y,L,p)
        self.assertTrue(np.isfinite(r['minimum_over_peak']))
        self.assertEqual(len(sens),12)

# local helper

def crossing(p,M):
    return (2*np.pi*M*p/(p-1.))/((p+1.)/(2*p))

if __name__=='__main__':unittest.main()
