"""Quantitative morphology for periodic positive P profiles in absolute K(p,p).

The word 'compacton' is reserved for the exact zero-background traveling-wave
profile. A small least-squares residual is only a morphological comparison;
finite grids cannot establish exact compact support or PDE well-posedness.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import least_squares
from scipy.signal import find_peaks, peak_widths, peak_prominences

PROMINENCES=(0.04, 0.08, 0.12, 0.16)
SEPARATIONS=(0.20, 0.30, 0.40)
REF_PROM=0.08
REF_SEP=0.30


def compacton_width(p:float)->float:
    if not np.isfinite(p) or p<=1: raise ValueError('p must exceed 1')
    return 2.*np.pi*p/(p-1.)


def theoretical_half_prominence_ratio(p:float)->float:
    # HWHM/full support width ratio * 2 => FWHM/Wp.
    return 2.*np.arccos(2.**(-(p-1.)/2.))/np.pi


def compacton_profile(x,center,amplitude,width,p,L):
    """Translated *exact-shape* compacton, support width fixed to `width`.

    The exact K(p,p) traveling compacton has width W_p=2*pi*p/(p-1)
    and c=(p+1)/(2*p)*A^(p-1), with zero background.
    """
    z=(np.asarray(x)-center+L/2.)%L-L/2.
    q=np.zeros_like(z,dtype=float)
    mask=np.abs(z)<width/2.
    q[mask]=amplitude*np.maximum(0.,np.cos(np.pi*z[mask]/width))**(2./(p-1.))
    return q


def compacton_train(x,centers,amps,width,p,L,background=0.):
    x=np.asarray(x)
    vals=np.full(x.shape,float(background),dtype=float)
    for center,a in zip(centers,amps):
        vals+=compacton_profile(x,float(center),float(a),float(width),p,L)
    return vals


def _find_periodic_peaks(y,dx,Wp,prom_frac=REF_PROM,minsep_frac=REF_SEP):
    y=np.asarray(y,dtype=float)
    n=y.size
    scale=max(float(np.ptp(y)),1.e-14)
    minsep=max(2,int(round(minsep_frac*Wp/dx)))
    z=np.tile(y,3)
    pk,prop=find_peaks(z,prominence=prom_frac*scale,distance=minsep)
    valid=(pk>=n)&(pk<2*n)
    pk=pk[valid];pr=prop['prominences'][valid]
    order=np.argsort(pk)
    return pk[order]-n,pr[order]


def periodic_gap_length(y,dx,eps):
    """Longest periodic contiguous segment where |u|<=eps*max|u|."""
    y=np.asarray(y)
    mask=np.abs(y)<=eps*max(np.max(np.abs(y)),1.e-14)
    n=y.size
    if np.all(mask):return n*dx
    if not np.any(mask):return 0.
    false=int(np.flatnonzero(~mask)[0])
    shifted=np.roll(mask,-(false+1))
    best=run=0
    for flag in shifted:
        if flag:run+=1;best=max(best,run)
        else:run=0
    return best*dx


def _valleys_between_peaks(y,peaks):
    y=np.asarray(y)
    n=len(y);peaks=np.asarray(peaks,dtype=int)
    if not len(peaks):return []
    if len(peaks)==1:return [int(np.argmin(y))]
    out=[]
    for i,pk in enumerate(peaks):
        nxt=int(peaks[(i+1)%len(peaks)])
        e=nxt if nxt>pk else nxt+n
        ids=np.arange(pk,e+1)%n
        out.append(int(ids[np.argmin(y[ids])]))
    return out


def profile_metrics(u,L,p,*,tau=float('nan'),prom_frac=REF_PROM,minsep_frac=REF_SEP):
    u=np.asarray(u,dtype=float)
    if u.ndim!=1 or u.size<48 or not np.all(np.isfinite(u)):
        raise ValueError('u must be one finite periodic profile with N>=48')
    n=u.size; dx=L/n;Wp=compacton_width(p)
    # A mild physical-length filter is *only* for locating dominant peaks,
    # not for measuring the field, its minima or fit residuals.
    smooth=gaussian_filter1d(u,max(0.5,Wp/(120.*dx)),mode='wrap')
    peaks,prom=_find_periodic_peaks(smooth,dx,Wp,prom_frac,minsep_frac)
    rawpeaks,rawprom=_find_periodic_peaks(u,dx,Wp,prom_frac,minsep_frac)
    # Recenter each detected peak onto the ORIGINAL field before measuring
    # amplitude, width, prominence, valleys or template fit. Smoothing is only
    # used for peak localization and threshold-sensitivity counting.
    sigma_nodes=max(.5,Wp/(120.*dx))
    radius=max(1,int(math.ceil(2.*sigma_nodes)))
    original_peaks=[]
    for pk in peaks:
        offsets=np.arange(-radius,radius+1)
        ids=(pk+offsets)%n
        original_peaks.append(int(ids[np.argmax(u[ids])]))
    peaks=np.asarray(original_peaks,dtype=int)
    widths=np.array([])
    pr_raw=np.array([])
    if len(peaks):
        raw3=np.tile(u,3)
        widths=peak_widths(raw3,peaks+n,rel_height=.5)[0]*dx
        pr_raw=peak_prominences(raw3,peaks+n)[0]
    valleys=_valleys_between_peaks(u,peaks)
    vmax=float(np.max(u));vabs=max(float(np.max(np.abs(u))),1.e-14)
    vals=np.asarray(u[valleys]) if valleys else np.array([])
    rows=[]
    for i,pk in enumerate(peaks):
        vl=float(u[valleys[i-1]]) if valleys else float('nan')
        vr=float(u[valleys[i]]) if valleys else float('nan')
        b=max(vl,vr)
        rows.append(dict(peak_id=i+1,peak_index=int(pk),x=float(pk*dx),x_over_L=float(pk/n),
                         u_peak=float(u[pk]),prominence=float(pr_raw[i]),
                         detected_prominence_smoothed=float(prom[i]),
                         valley_left=vl,valley_right=vr,local_pedestal=b,
                         pedestal_over_peak=float(b/max(abs(u[pk]),1e-14)),
                         fwhm=float(widths[i]),fwhm_over_Wp=float(widths[i]/Wp),
                         width_ratio_to_exact=float((widths[i]/Wp)/theoretical_half_prominence_ratio(p))))
    sens=[]
    for pr in PROMINENCES:
        for sep in SEPARATIONS:
            a,_=_find_periodic_peaks(smooth,dx,Wp,pr,sep)
            sens.append(dict(prominence_fraction=pr,minsep_fraction=sep,n_peaks=len(a)))
    ns=[a['n_peaks'] for a in sens]
    summary=dict(tau=float(tau),N=n,L=L,p=p,Wp=Wp,M_capacity=L/Wp,
                 n_peaks=len(peaks),n_peaks_raw=len(rawpeaks),
                 n_peak_sensitivity_min=min(ns),n_peak_sensitivity_max=max(ns),
                 count_robust=(min(ns)==max(ns)==len(peaks)),
                 min_value=float(np.min(u)),q01=float(np.quantile(u,.01)),
                 q05=float(np.quantile(u,.05)),median=float(np.median(u)),
                 max_value=vmax,minimum_over_peak=float(np.min(u)/vabs),
                 q01_over_peak=float(np.quantile(u,.01)/vabs),
                 negative_fraction=float(np.mean(u<0.)),
                 near_zero_fraction_1pct=float(np.mean(np.abs(u)<=.01*vabs)),
                 near_zero_fraction_0p1pct=float(np.mean(np.abs(u)<=.001*vabs)),
                 max_gap_Wp_1pct=float(periodic_gap_length(u,dx,.01)/Wp),
                 max_gap_Wp_0p1pct=float(periodic_gap_length(u,dx,.001)/Wp),
                 min_valley=float(np.min(vals)) if len(vals) else float('nan'),
                 median_valley=float(np.median(vals)) if len(vals) else float('nan'),
                 min_valley_over_peak=float(np.min(vals)/vabs) if len(vals) else float('nan'),
                 fwhm_median_Wp=float(np.median(widths/Wp)) if len(widths) else float('nan'),
                 fwhm_exact_Wp=theoretical_half_prominence_ratio(p))
    return summary,rows,sens


def fit_compacton_train(u,L,p,peak_indices,*,model='zero',max_nfev=130):
    """Fit full periodic profile to sum of separated exact-shape lobes.

    `zero`: width exactly Wp, background exactly zero.
    `pedestal`: fixed Wp, fit nonnegative flat pedestal.
    `free_width`: fit both background and common width (morphology only).
    All final RMS errors are evaluated on the ORIGINAL non-downsampled field.
    """
    u=np.asarray(u,dtype=float)
    n=u.size;Wp=compacton_width(p)
    ids=np.asarray(peak_indices,dtype=int)
    if model not in ('zero','pedestal','free_width'):raise ValueError(model)
    if not (1<=len(ids)<=24):
        return dict(model=model,fit_status='SKIPPED_COUNT',n_peaks=len(ids),rms=float('nan'),
                    rms_over_peak=float('nan'),rms_over_range=float('nan'),background=float('nan'),
                    width=float('nan'),width_over_Wp=float('nan'),amplitudes='',centers='',nfev=0),None
    x=np.arange(n)*L/n
    centers0=x[ids];npeaks=len(ids)
    vabs=max(float(np.max(np.abs(u))),1.e-12)
    positive_peak=np.maximum(np.maximum(u[ids]-np.quantile(u,.05),.01*vabs),.01*vabs)
    # The optimizer uses <=512 points for speed, but the reported residual
    # compares the continuous fitted profile with EVERY original grid point.
    xopt=np.linspace(0,L,min(512,n),endpoint=False)
    yopt=np.interp(xopt,np.r_[x,L],np.r_[u,u[0]])
    centers_shift_lb=np.full(npeaks,-0.29*Wp)
    centers_shift_ub=np.full(npeaks,0.29*Wp)
    al_lb=np.full(npeaks,0.)
    al_ub=np.full(npeaks,3.*vabs)
    lo=np.r_[centers_shift_lb,al_lb];hi=np.r_[centers_shift_ub,al_ub]
    init=np.r_[np.zeros(npeaks),positive_peak]
    if model in ('pedestal','free_width'):
        lo=np.r_[lo,0.];hi=np.r_[hi,1.5*vabs]
        init=np.r_[init,max(0.,float(np.quantile(u,.05)))]
    if model=='free_width':
        lo=np.r_[lo,.50*Wp];hi=np.r_[hi,1.75*Wp]
        init=np.r_[init,Wp]
    init=np.minimum(np.maximum(init,lo+1e-12),hi-1e-12)

    def unpack(v):
        c=(centers0+v[:npeaks])%L
        amps=v[npeaks:2*npeaks]
        bg=v[2*npeaks] if model!='zero' else 0.
        width=v[2*npeaks+1] if model=='free_width' else Wp
        return c,amps,bg,width
    def resid(v):
        c,a,b,w=unpack(v)
        return (compacton_train(xopt,c,a,w,p,L,b)-yopt)/vabs
    try:
        z=least_squares(resid,init,bounds=(lo,hi),max_nfev=max_nfev,ftol=1e-9,
                        xtol=1e-9,gtol=1e-9)
        c,a,b,w=unpack(z.x)
        pred=compacton_train(x,c,a,w,p,L,b)
        rms=float(np.sqrt(np.mean((pred-u)**2)))
        out=dict(model=model,fit_status='SUCCESS' if z.success else 'ITER_LIMIT',
                 n_peaks=npeaks,rms=rms,rms_over_peak=rms/vabs,
                 rms_over_range=rms/max(float(np.ptp(u)),1.e-12),
                 background=float(b),background_over_peak=float(b/vabs),
                 width=float(w),width_over_Wp=float(w/Wp),
                 amplitudes=';'.join(f'{q:.9g}' for q in a),
                 centers=';'.join(f'{q:.9g}' for q in c),nfev=int(z.nfev),
                 cost=float(z.cost))
        return out,pred
    except (RuntimeError,ValueError,OverflowError) as exc:
        return dict(model=model,fit_status='ERROR:'+str(exc)[:120],n_peaks=npeaks,
                    rms=float('nan'),rms_over_peak=float('nan'),rms_over_range=float('nan'),
                    background=float('nan'),background_over_peak=float('nan'),
                    width=float('nan'),width_over_Wp=float('nan'),
                    amplitudes='',centers='',nfev=0),None


def morphology_label(summary,fit0=None,fitped=None,fitfree=None):
    """Conservative finite-grid terminology; never certify PDE compact support."""
    if summary['n_peaks']==0:return 'sin_pulsos_resueltos'
    if not summary['count_robust']:return 'conteo_sensible_a_umbrales'
    if summary['min_value']>0.02*max(abs(summary['max_value']),1e-12):
        return 'pulsos_sobre_fondo_positivo'
    if summary['min_valley_over_peak']>0.02:
        return 'pulsos_sobre_valles_positivos'
    if fit0 is None or fit0.get('fit_status')!='SUCCESS':
        return 'clasificacion_pendiente_de_ajuste'
    if (fit0['rms_over_peak']<.04 and
        summary['near_zero_fraction_1pct']>.03 and
        (fitfree is None or .85<=fitfree.get('width_over_Wp',0.)<=1.15)):
        return 'compatible_morfologicamente_con_compactones'
    return 'estructura_pulsatil_no_identificada_como_compacton'
