"""Compact phase-5 export; intentionally omits full large HDF5 fields."""
from __future__ import annotations
import argparse,zipfile,json,hashlib
from pathlib import Path


def pack(root,destination):
    root=Path(root);destination=Path(destination)
    out=root/'fase5/results/analysis'
    if not (out/'status.json').exists():raise FileNotFoundError('Analysis must run first')
    names=[]
    for p in out.rglob('*'):
        if p.is_file():names.append(p)
    for p in (root/'fase5/campaign_P_p2_M8.csv',root/'fase5/README.md',
              root/'fase5/classification.py',root/'fase5/analysis.py',
              root/'fase5/design.py'):
        if p.exists():names.append(p)
    for pattern in ('fase5/results/m8/*.audit.json','fase5/logs/*.out','fase5/logs/*.err'):
        names.extend(root.glob(pattern))
    names=sorted(set(names),key=lambda x:str(x))
    destination.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in names:z.write(p,p.relative_to(root))
        z.writestr('fase5/ZIP_MANIFEST_SHA256.json',json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in names},indent=2)+'\n')
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None
    status=json.loads((out/'status.json').read_text())
    print('FASE5_PAQUETE_OK',destination,'valid',status['valid_runs'],'of',status['expected_runs'],
          'status',status['status'],flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='.')
    ap.add_argument('--out',default='fase5/Fase5_CNSNS_P_resultados_20261118.zip')
    args=ap.parse_args();pack(args.root,Path(args.root)/args.out)

if __name__=='__main__':main()
