"""Fixed-physical-nu campaign for the signed absolute K(p,p) equation.

NO scaling of nu with dx. Every numerical comparison retains identical nu,
spatial stencil, time calendar and initial conditions except the named dimension.
"""
from __future__ import annotations
import csv
import hashlib
import json
from pathlib import Path

P=2.25
M=4
NUS=(0.004, 0.001, 0.00025)
NS=(450,900,1800)
BASE_STEPS_PER_TAU=3200
FIELDS=('task_id','run_id','nu','N','dt_divisor','tau_start','tau_end',
        'project_half','regularization','strict','source_run_id','kind','segment')

def label(nu):
    return f'nu{nu:g}'.replace('.', 'p').replace('-', 'm')

def run_id(nu,n,div=1,suffix=''):
    return f'Z_p225_M4_{label(nu)}_N{n}_d{div}' + (f'_{suffix}' if suffix else '')

def make():
    short=[]
    for nu in NUS:
        for n in NS:
            short.append(dict(run_id=run_id(nu,n),nu=nu,N=n,dt_divisor=1,
                              tau_start=0.,tau_end=1.25,project_half=1,
                              regularization='fourth_order',strict=0,source_run_id='',kind='short',segment=0))
        for div in (2,4):
            short.append(dict(run_id=run_id(nu,1800,div),nu=nu,N=1800,dt_divisor=div,
                              tau_start=0.,tau_end=1.25,project_half=1,
                              regularization='fourth_order',strict=0,source_run_id='',kind='short',segment=0))
        short.append(dict(run_id=run_id(nu,1800,1,'strict'),nu=nu,N=1800,dt_divisor=1,
                              tau_start=0.,tau_end=1.25,project_half=1,
                              regularization='fourth_order',strict=1,source_run_id='',kind='short',segment=0))
    for nu in (0.004,0.001):
        short.append(dict(run_id=run_id(nu,900,1,'unprojected'),nu=nu,N=900,dt_divisor=1,
                          tau_start=0.,tau_end=1.25,project_half=0,
                          regularization='fourth_order',strict=0,source_run_id='',kind='short',segment=0))
    for n in (900,1800):
        short.append(dict(run_id=run_id(0.001,n,1,'stencil2'),nu=0.001,N=n,dt_divisor=1,
                          tau_start=0.,tau_end=1.25,project_half=1,
                          regularization='legacy_second_order',strict=0,source_run_id='',kind='short',segment=0))
    assert len(short)==22
    long=[]
    for seg in (2,3,4):
        for nu in NUS:
            for n in (900,1800):
                name=run_id(nu,n,1,f'seg{seg}')
                source=run_id(nu,n) if seg==2 else run_id(nu,n,1,f'seg{seg-1}')
                long.append(dict(run_id=name,nu=nu,N=n,dt_divisor=1,
                                 tau_start=seg-0.75,tau_end=seg+0.25,
                                 project_half=1,regularization='fourth_order',strict=0,
                                 source_run_id=source,kind='long',segment=seg))
    assert len(long)==18
    for rows in (short,long):
        for i,row in enumerate(rows,1): row['task_id']=i
    assert len(set(x['run_id'] for x in short+long))==40
    return short,long

def make_pilot():
    rows=[]
    for nu in NUS:
        for n in (900,1800):
            rows.append(dict(task_id=len(rows)+1,run_id=run_id(nu,n,1,'pilot'),
                             nu=nu,N=n,dt_divisor=1,tau_start=0.,tau_end=.10,
                             project_half=1,regularization='fourth_order',strict=0,
                             source_run_id='',kind='short',segment=0))
    return rows

def write_manifest(path, rows):
    path=Path(path)
    if path.exists():
        raise FileExistsError('No se reemplaza un manifiesto existente: '+str(path))
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf8') as fd:
        w=csv.DictWriter(fd,fieldnames=FIELDS)
        w.writeheader();w.writerows(rows)
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_manifest(path):
    with open(path,newline='',encoding='utf8') as fd: rows=list(csv.DictReader(fd))
    assert [int(x['task_id']) for x in rows] == list(range(1,len(rows)+1))
    assert len(set(x['run_id'] for x in rows))==len(rows)
    for x in rows:
        assert float(x['nu'])>0 and x['regularization'] in ('fourth_order','legacy_second_order')
        assert int(x['dt_divisor']) in (1,2,4)
    return rows

def main():
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--directory',default='fase6')
    a=p.parse_args()
    short,long=make()
    for name,rows in (('pilot',make_pilot()),('short',short),('long',long)):
        fname=Path(a.directory)/f'campaign_{name}.csv'
        print(fname, len(rows),'SHA256',write_manifest(fname,rows))
    print('FASE6_DISENO_OK 6 piloto + 22 short + 18 long')

if __name__=='__main__':main()
