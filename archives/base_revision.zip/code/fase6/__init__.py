"""Phase 6: fixed physical biharmonic regularization."""
