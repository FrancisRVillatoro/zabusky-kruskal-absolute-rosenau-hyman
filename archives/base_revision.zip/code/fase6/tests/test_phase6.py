from __future__ import annotations
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
import h5py

from absk_radau.model import PeriodicAbsK,domain_length
from fase6.design import make,NUS,NS,BASE_STEPS_PER_TAU,run_id
from fase6.run import run,clock,should_save
from fase6.analyze import find_return,spatial_difference,weak_fourier_residual,spacetime_weak_residual
from fase6.verification import smooth_reference

class TestPhase6(unittest.TestCase):
    def test_design_40(self):
        a,b=make();self.assertEqual((len(a),len(b)),(22,18))
        self.assertEqual(len(set(r['run_id'] for r in a+b)),40)
    def test_fixed_nu_across_N_and_dt(self):
        a,_=make()
        for nu in NUS:
            x=[r for r in a if float(r['nu'])==nu and r['regularization']=='fourth_order' and
               int(r['project_half'])==1 and int(r['strict'])==0]
            self.assertEqual(len(x),5)
            self.assertEqual(sorted(set(int(r['N']) for r in x)),list(NS))
            self.assertEqual(sorted(int(r['dt_divisor']) for r in x if int(r['N'])==1800),[1,2,4])
    def test_clock(self):
        a,_=make()
        for row in a:
            tc,dt,kt=clock(row)
            self.assertAlmostEqual(dt*kt,tc)
            self.assertEqual(kt,BASE_STEPS_PER_TAU*int(row['dt_divisor']))
    def test_sample_times(self):
        self.assertTrue(should_save(3200,3200))
        self.assertTrue(should_save(3200+2,3200))
        self.assertFalse(should_save(3200+1,3200))
    def test_smooth_manufactured_order(self):
        for nu in (.004,.001,.00025):
            e1,b1=smooth_reference(64,nu);e2,b2=smooth_reference(128,nu)
            self.assertGreater(e1/e2,9)
            self.assertLess(max(b1,b2),1e-10)
    def test_real_short_and_continue(self):
        short,long=make()
        s=deepcopy(short[0]);s['run_id']='tiny_short';s['N']=32;s['tau_end']=.0025
        s['nu']=.001
        l=deepcopy(long[0]);l['run_id']='tiny_long';l['N']=32;l['nu']=.001
        l['source_run_id']='tiny_short';l['tau_start']=.0025;l['tau_end']=.005
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            a=run(s,base=root,output=root/'fase6/results/short')
            b=run(l,base=root,output=root/'fase6/results/long')
            self.assertEqual(a['n_accepted'],8)
            self.assertEqual(b['n_accepted'],8)
            with h5py.File(root/'fase6/results/short/tiny_short.h5') as f:
                us=f['u'][-1].copy()
            with h5py.File(root/'fase6/results/long/tiny_long.h5') as f:
                self.assertEqual(f.attrs['status'],'COMPLETED')
                np.testing.assert_allclose(f['u'][0],us,atol=0,rtol=0)
                self.assertAlmostEqual(f['t'][-1]/clock(l)[0],.005)
            self.assertIsNotNone(b['source_sha256'])
    def test_find_return_local(self):
        tau=np.arange(.9,1.10001,.01)
        d=np.zeros((len(tau),10));d[:,5]=.05+(tau-1.01)**2
        d[:,8]=1.;d[:,9]=d[:,5]**2
        u=np.zeros((len(tau),32));u[:,0]=.1
        v={'tau':tau,'d':d,'u':u}
        r=find_return(v,1)
        self.assertEqual(r['status'],'LOCAL_MIN')
        self.assertAlmostEqual(r['tau'],1.01)
    def test_spatial_difference(self):
        tau=np.array([1.,1.000625,1.00125]);coarse=np.ones((3,32))
        fine=np.ones((3,64));fine[:,::2]+=0.01
        v0={'tau':tau,'u':coarse};v1={'tau':tau,'u':fine}
        r=spatial_difference(v0,v1)
        self.assertEqual(r['status'],'OK')
        self.assertAlmostEqual(r['max_L2'],.01)
    def test_weak_fourier_consistency(self):
        m=PeriodicAbsK(64,domain_length(2.25,4),2.25,.001)
        u=.7+.1*np.cos(2*np.pi*m.x/m.L)
        v={'tau':np.array([0.]),'u':u[None,:],
           'config':{'nu':.001,'p':2.25,'M':4,'regularization':'fourth_order'}}
        out=weak_fourier_residual(v)
        self.assertEqual(len(out),4)
        self.assertTrue(all(np.isfinite(x['residual_abs']) for x in out))
    def test_spacetime_weak_residual_h5_only(self):
        m=PeriodicAbsK(64,domain_length(2.25,4),2.25,.001)
        tau=np.arange(.9,1.10000001,.000625)
        # Time-independent constant field: every nonzero spatial Fourier mode vanishes.
        u=np.ones((len(tau),64))*.7
        v={'tau':tau,'u':u,'config':{'p':2.25,'nu':.001,'M':4}}
        r=spacetime_weak_residual(v,1)
        self.assertEqual(len(r),4)
        self.assertTrue(all(x['status']=='OK' and x['residual_abs']<1e-10 for x in r))

    def test_does_not_overwrite_existing(self):
        a,_=make();s=deepcopy(a[0]);s['run_id']='no_overwrite';s['N']=32;s['tau_end']=.000625
        with tempfile.TemporaryDirectory() as d:
            output=Path(d)/'fase6/results/short';output.mkdir(parents=True)
            (output/'no_overwrite.h5').write_text('bad')
            with self.assertRaises(FileExistsError):run(s,base=d,output=output)

if __name__=='__main__':unittest.main()
