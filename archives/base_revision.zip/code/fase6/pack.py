"""Package report, 40 audits, failures, logs; exclude heavy HDF5 profiles."""
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

def pack(root,output):
    root=Path(root).resolve();out=Path(output).resolve()
    out.parent.mkdir(parents=True,exist_ok=True)
    picks=[]
    for directory in ('fase6/results/analysis','fase6/results/short','fase6/results/long','fase6/logs','fase6'):
        for path in (root/directory).rglob('*'):
            if not path.is_file() or path.resolve()==out:continue
            if path.suffix in ('.h5','.pyc','.slurm') or '__pycache__' in path.parts:continue
            if directory=='fase6':
                # Avoid recursing entire folder including copies; keep only small root docs/manifests.
                if path.parent != root/'fase6':continue
            else:
                if path.suffix not in ('.json','.csv','.png','.md','.txt','.out','.err'):continue
            if path not in picks:picks.append(path)
    picks=sorted(set(picks))
    if not any(p.name=='status.json' for p in picks):raise RuntimeError('Falta status.json: aun no se ha analizado')
    sha_lines=[]
    with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=7) as z:
        for f in picks:
            arc=f.relative_to(root).as_posix()
            z.write(f,arc)
            sha_lines.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+arc)
        z.writestr('FILES_SHA256.txt','\n'.join(sha_lines)+'\n')
    print('FASE6_PAQUETE_OK',out,len(picks),'files',out.stat().st_size,'bytes',flush=True)
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='.')
    p.add_argument('--out',default='fase6/Fase6_CNSNS_resultados_20261118.zip')
    a=p.parse_args();pack(a.root,a.out)
