"""Local Slurm verification: model consistency, physical nu, tests, genuine Radau steps."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from absk_radau.model import PeriodicAbsK,domain_length
from absk_radau.radau_mass import MassRadau5,NewtonOptions
from fase6.design import NUS,make,read_manifest

def smooth_reference(n,nu):
    L=domain_length(2.25,4)
    x=np.arange(n)*L/n
    k=2*np.pi/L
    u=.7+.15*np.cos(2*k*x)+.07*np.sin(3*k*x)
    model=PeriodicAbsK(n,L,2.25,nu,regularization='fourth_order')
    f=model.flux(u)
    fk=np.fft.fftfreq(n,d=L/n)*2*np.pi
    fh=np.fft.fft(f)
    uh=np.fft.fft(u)
    exact=-np.fft.ifft((1j*fk+(1j*fk)**3)*fh+nu*(fk**4)*uh).real
    discrete=model.velocity(u)
    e=float(np.linalg.norm(discrete-exact)/np.sqrt(n))
    balance=model.lp_balance_rhs(u)
    formula=-nu*model.dx*np.dot(f,model.Q2@u)
    defect=abs(balance-formula)
    return e,defect

def verify():
    short,long=make()
    assert len(short)==22 and len(long)==18
    sfile=Path('fase6/campaign_short.csv');lfile=Path('fase6/campaign_long.csv')
    assert len(read_manifest(sfile))==22 and len(read_manifest(lfile))==18
    results=[]
    for nu in NUS:
        e1,b1=smooth_reference(64,nu)
        e2,b2=smooth_reference(128,nu)
        # Smooth manufactured derivative fourth-order consistency.
        assert e1/e2>9,(nu,e1,e2,e1/e2)
        assert max(b1,b2)<1e-10,(nu,b1,b2)
        m=PeriodicAbsK(64,domain_length(2.25,4),2.25,nu)
        u=np.cos(2*np.pi*m.x/m.L)
        sol=MassRadau5(m,NewtonOptions(predictor='euler'),project_half=True)
        un,diag=sol.step(u,.008)
        assert np.all(np.isfinite(un)) and diag.norm_residual<=1
        assert m.nu==nu
        results.append(dict(nu=nu,spatial_error_N64=e1,spatial_error_N128=e2,
                            ratio=e1/e2,lp_balance_defect_max=max(b1,b2),
                            radau_step_scaled_rms=diag.norm_residual))
    Path('fase6/results').mkdir(exist_ok=True,parents=True)
    (Path('fase6/results')/'verification.json').write_text(json.dumps(results,indent=2)+'\n')
    print('FASE6_VERIFICACION_OK',len(results),'nu levels',flush=True)
    return results

if __name__=='__main__':verify()
