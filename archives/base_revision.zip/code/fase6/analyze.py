"""Independent scientific audit of regularized trajectories for Phase 6.

Reports existing comparable results only; missing/failed runs remain explicit.
No inference of continuum PDE wellposedness or nu->0 convergence.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
from collections import defaultdict

import h5py
import numpy as np
from absk_radau.model import PeriodicAbsK,domain_length,crossing_time
from fase6.design import read_manifest,NUS,NS

TC=crossing_time(2.25,4,1.)
L=domain_length(2.25,4)

def save_csv(path,rows,fields):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore')
        w.writeheader();w.writerows(rows)

def read_complete(path, expected=None):
    if not Path(path).is_file():return None
    with h5py.File(path,'r') as h:
        if h.attrs.get('status')!='COMPLETED':return None
        t=h['t'][:]/TC
        d=h['diagnostics'][:]
        u=h['u'][:]
        if d.shape!=(len(t),10) or u.shape[0]!=len(t):raise ValueError('H5 invalid shape '+str(path))
        if not np.all(np.diff(t)>0):raise ValueError('H5 times not increasing '+str(path))
        if not np.all(np.isfinite(u)) or not np.all(np.isfinite(d[:,[1,2,5,7,8,9]])):
            raise ValueError('H5 contains nonfinite values '+str(path))
        cfg=json.loads(h.attrs['config_json'])
        if expected is not None:
            assert cfg['run_id']==expected['run_id']
            assert float(cfg['nu'])==float(expected['nu'])
            assert int(cfg['N'])==int(expected['N'])
            assert cfg['regularization']==expected['regularization']
            assert int(cfg['dt_divisor'])==int(expected['dt_divisor'])
            assert bool(cfg['project_half'])==bool(int(expected['project_half']))
            assert abs(float(cfg['tau_start'])-float(expected['tau_start']))<1e-11
            assert abs(float(cfg['tau_end'])-float(expected['tau_end']))<1e-11
            assert abs(float(t[-1])-float(expected['tau_end']))<1e-11
        return {'tau':t,'d':d,'u':u,'config':cfg,'source':str(path)}

def find_return(v,j):
    lo,hi=(0.92,1.12) if j==1 else (j-.20,j+.20)
    tau=v['tau'];d=v['d'];idx=np.where((tau>=lo)&(tau<=hi))[0]
    if len(idx)<3:return dict(status='NO_DATA',index=j)
    indices=[int(i) for i in idx[1:-1] if d[i,5]<=d[i-1,5] and d[i,5]<=d[i+1,5]
             and (d[i,5]<d[i-1,5] or d[i,5]<d[i+1,5])]
    if not indices:return dict(status='NO_LOCAL_MIN',index=j)
    i=min(indices,key=lambda x:d[x,5])
    u=v['u'][i];n=len(u);a=np.fft.rfft(u)/n
    # u0=A*cos(theta), A=1, e_n=2|uhat_n|²/(1/2)=4|uhat_n|²
    e5=4*abs(a[5])**2
    H=float(d[i,9]);D=float(d[i,5]);r=float(d[i,8]);p1=float(d[i,7])
    return dict(status='LOCAL_MIN',index=j,tau=float(tau[i]),D=D,H=H,r=r,
                Phi1=p1,e5=float(e5),e5_over_H=float(e5/H) if H>0 else None,
                mass=float(d[i,1]),I_p1=float(d[i,2]),
                modal_identity_defect=float(D*D-(r-1)**2-H),
                local_output_spacing_tau=float(max(tau[i]-tau[i-1],tau[i+1]-tau[i])),
                grid_index=i,n_local_minima=len(indices))

def spatial_difference(x,y):
    n0=x['u'].shape[1];n1=y['u'].shape[1]
    if n1%n0:raise ValueError('Spatial grids not nested')
    tm={int(round(t*12800)):k for k,t in enumerate(x['tau'])}
    tn={int(round(t*12800)):k for k,t in enumerate(y['tau'])}
    common=sorted(set(tm)&set(tn))
    if not common:return dict(status='NO_COMMON_TIME',n_common=0)
    if any(abs(x['tau'][tm[k]]-y['tau'][tn[k]])>1e-9 for k in common):
        raise ValueError('Time alignment mismatch')
    out=[]
    for k in common:
        ux=x['u'][tm[k]];uy=y['u'][tn[k],::n1//n0]
        delta=np.linalg.norm(ux-uy)/max(np.linalg.norm(ux),1e-300)
        out.append((k/12800,float(delta)))
    return dict(status='OK',n_common=len(common),max_L2=max(v for _,v in out),
                final_L2=out[-1][1],rms_L2=float(np.sqrt(np.mean([v*v for _,v in out]))),
                tau_at_max=max(out,key=lambda p:p[1])[0],
                tau_start=out[0][0],tau_end=out[-1][0])

def field_window(x,y,j):
    if x is None or y is None:return dict(status='MISSING')
    # Only data near j; common time snapshots are exact multiples of 1/12800 tau.
    q={}
    for z,k in ((x,0),(y,1)):
        idx=np.where(abs(z['tau']-j)<=.125001)[0]
        q[k]={'tau':z['tau'][idx],'u':z['u'][idx],'config':z['config']}
    return spatial_difference(q[0],q[1])

def weak_fourier_residual(v,modes=(1,3,5,7)):
    """Smooth periodic Fourier tests of the *physical* PDE in pointwise-in-time weak form.

    Uses model.velocity(u) as the semidiscrete time derivative, not a
    second time differencing that would contaminate h-convergence.
    Reports measured consistency only, not an independent time solver.
    """
    config=v['config'];n=v['u'].shape[1];nu=float(config['nu'])
    p=float(config['p']);l=domain_length(p,float(config['M']))
    model=PeriodicAbsK(n,l,p,nu,regularization=config['regularization'])
    inds=np.unique(np.linspace(0,len(v['tau'])-1,min(13,len(v['tau'])),dtype=int))
    result=[]
    for idx in inds:
        u=v['u'][idx];fu=model.flux(u);du=model.velocity(u)
        Uh=np.fft.rfft(u)/n;Fh=np.fft.rfft(fu)/n;Vh=np.fft.rfft(du)/n
        for m in modes:
            k=2*np.pi*m/l
            conv=1j*k*(1-k*k)*Fh[m]
            damp=nu*k**4*Uh[m]
            r=Vh[m]+conv+damp
            scale=abs(Vh[m])+abs(conv)+abs(damp)
            result.append(dict(tau=float(v['tau'][idx]),harmonic=m,
                               residual_abs=float(abs(r)),denominator=float(scale),
                               relative_residual=float(abs(r)/scale) if scale>1e-12 else None))
    return result


def spacetime_weak_residual(v,j,modes=(1,3,5,7),half_window=.10):
    """Independent H5-only Fourier/time-test residual for the regularized PDE.

    For each spatial mode U_m, multiply U'_m+ik(1-k²)F_m+nu k⁴U_m=0
    by phi(t)=sin²(pi*(t-ta)/(tb-ta)) and integrate by parts in time.
    The data are snapshots only; trapezoid time quadrature remains an error
    source. No model.velocity or semidiscrete RHS is used in this check.
    """
    tau=v['tau'];a=j-half_window;b=j+half_window
    idx=np.where((tau>=a-1e-9)&(tau<=b+1e-9))[0]
    if len(idx)<6 or abs(tau[idx[0]]-a)>1e-8 or abs(tau[idx[-1]]-b)>1e-8:
        return [{'index':j,'harmonic':m,'status':'NO_COMPLETE_TEST_WINDOW'} for m in modes]
    t=tau[idx]*TC
    y=(tau[idx]-a)/(b-a)
    phi=np.sin(np.pi*y)**2
    dphi_dt=(np.pi/(b-a))/TC*np.sin(2*np.pi*y)
    U=np.fft.rfft(v['u'][idx,:],axis=1)/v['u'].shape[1]
    p=float(v['config']['p']); nu=float(v['config']['nu'])
    F=np.fft.rfft(np.abs(v['u'][idx,:])**(p-1)*v['u'][idx,:],axis=1)/v['u'].shape[1]
    l=domain_length(p,float(v['config']['M']))
    result=[]
    for m in modes:
        k=2*np.pi*m/l
        e1=-np.trapezoid(U[:,m]*dphi_dt,t)
        e2=np.trapezoid(1j*k*(1-k*k)*F[:,m]*phi,t)
        e3=np.trapezoid(nu*k**4*U[:,m]*phi,t)
        total=e1+e2+e3
        scale=abs(e1)+abs(e2)+abs(e3)
        result.append(dict(index=j,harmonic=m,status='OK',nu=nu,N=v['u'].shape[1],
                           tau_a=a,tau_b=b,n_samples=len(idx),
                           residual_abs=float(abs(total)),
                           normalization=float(scale),
                           relative_residual=float(abs(total)/scale) if scale>1e-10 else None))
    return result

def zero_source(root,n,j):
    root=Path(root)
    if j==1:
        candidates=[root/'fase4/results/zoom1'/f'Z_p225_M4_N{n}_zoom1.h5',
                    root/'fase3/results/combined_fixed'/f'Z_p225_M4__space_{"mid" if n==900 else "high"}.h5',
                    root/'fase3/results/rescue_fixed'/f'Z_p225_M4__space_{"mid" if n==900 else "high"}.h5',
                    root/'fase3/results/main'/f'Z_p225_M4__space_{"mid" if n==900 else "high"}.h5']
    else:
        candidates=[root/'fase4/results/long'/f'Z_p225_M4_N{n}_seg{j}.h5']
        if j==4 and n==1800:
            candidates.insert(0,root/'fase4b/results/dt_divisor_4'/f'Z_p225_M4_N1800_seg4_dtdiv4.h5')
    for p in candidates:
        if not p.exists():continue
        v=read_complete(p)
        if v is None:continue
        if abs(float(v['config']['nu']))>1e-14:continue
        if int(v['u'].shape[1])!=n:continue
        if find_return(v,j)['status']=='LOCAL_MIN':return v
    return None

def produce(root='.',analysis='fase6/results/analysis'):
    root=Path(root);analysis=Path(analysis);analysis.mkdir(parents=True,exist_ok=True)
    allrows=[*read_manifest(root/'fase6/campaign_short.csv'),*read_manifest(root/'fase6/campaign_long.csv')]
    data={};inventory=[];audits=[];errors=[]
    for row in allrows:
        path=root/'fase6/results'/row['kind']/(row['run_id']+'.h5')
        afile=path.with_suffix('.audit.json')
        try:
            v=read_complete(path,row)
            ready=v is not None and afile.exists()
            reason='' if ready else ('INCOMPLETE_H5' if path.exists() else 'MISSING_H5')
            if ready:
                data[row['run_id']]=v
                audit=json.loads(afile.read_text())
                if audit.get('status')!='COMPLETED':raise ValueError('Audit status is not completed')
                audits.append(audit)
        except Exception as exc:
            ready=False;reason=f'INVALID_H5 {exc}';errors.append({'case':row['run_id'],'error':str(exc)})
        failure=path.with_suffix('.failure.json')
        if not ready and failure.exists():reason+=' '+failure.read_text()[:600]
        inventory.append({**row,'status':'COMPLETED' if ready else 'MISSING_OR_FAILED','reason':reason})
    def findrow(nu,n,div=1,suffix='',segment=0):
        from fase6.design import run_id
        return run_id(nu,n,div,suffix if segment==0 else f'seg{segment}')
    returns=[];weak=[];weakspace=[]
    for row in allrows:
        v=data.get(row['run_id'])
        if v is None:continue
        # Baseline and all controls: first return; segmented runs: j=segment.
        j=int(row['segment']) if row['kind']=='long' else 1
        rr=find_return(v,j)
        rr.update(run_id=row['run_id'],nu=float(row['nu']),N=int(row['N']),
                  dt_divisor=int(row['dt_divisor']),regularization=row['regularization'],
                  project_half=int(row['project_half']),strict=int(row['strict']))
        returns.append(rr)
        # Fourier consistency need only primary runs on 3 spatial grids.
        if int(row['dt_divisor'])==1 and int(row['strict'])==0 and int(row['project_half'])==1 and row['regularization']=='fourth_order':
            try:
                for w in weak_fourier_residual(v):
                    weak.append(dict(run_id=row['run_id'],nu=float(row['nu']),N=int(row['N']),segment=j,**w))
            except Exception as exc:errors.append({'case':row['run_id'],'error':'weak residual '+str(exc)})
            try:
                for w in spacetime_weak_residual(v,j):weakspace.append(dict(run_id=row['run_id'],**w))
            except Exception as exc:errors.append({'case':row['run_id'],'error':'spacetime weak residual '+str(exc)})
    ref=[]
    # Fixed-nu/nested spatial grids, field budgets for each of four returns.
    for nu in NUS:
        for j in (1,2,3,4):
            for n0,n1 in ((450,900),(900,1800)):
                if j>1 and n0==450:continue
                a=data.get(findrow(nu,n0,segment=0 if j==1 else j))
                b=data.get(findrow(nu,n1,segment=0 if j==1 else j))
                v=field_window(a,b,j)
                ref.append({'nu':nu,'return':j,'dimension':'spatial','N0':n0,'N1':n1,
                            'dtdiv0':1,'dtdiv1':1,**v})
            if j==1:
                for div0,div1 in ((1,2),(2,4)):
                    a=data.get(findrow(nu,1800,div0));b=data.get(findrow(nu,1800,div1))
                    v=field_window(a,b,j)
                    ref.append({'nu':nu,'return':j,'dimension':'temporal','N0':1800,'N1':1800,
                                'dtdiv0':div0,'dtdiv1':div1,**v})
                a=data.get(findrow(nu,1800));b=data.get(findrow(nu,1800,suffix='strict'))
                v=field_window(a,b,j)
                ref.append({'nu':nu,'return':j,'dimension':'algebraic','N0':1800,'N1':1800,
                            'dtdiv0':1,'dtdiv1':1,**v})
    ctrl=[]
    for nu in (0.004,0.001):
        base=data.get(findrow(nu,900));alt=data.get(findrow(nu,900,suffix='unprojected'))
        ctrl.append(dict(nu=nu,type='projection',N=900,**field_window(base,alt,1)))
    for n in (900,1800):
        base=data.get(findrow(.001,n));alt=data.get(findrow(.001,n,suffix='stencil2'))
        ctrl.append(dict(nu=.001,type='biharmonic_stencil_only',N=n,**field_window(base,alt,1)))
    # nu>0 limit comparisons always label nu=0 source's integrator and provenance.
    zero=[]
    for j in (1,2,3,4):
        for n in (900,1800):
            v0=zero_source(root,n,j)
            R0=find_return(v0,j) if v0 else dict(status='MISSING_ZERO_BASELINE')
            for nu in NUS:
                v=data.get(findrow(nu,n,segment=0 if j==1 else j))
                rr=find_return(v,j) if v else dict(status='MISSING_REGULARIZED')
                zero.append(dict(return_index=j,N=n,nu=nu,
                                 nu0_source=v0['source'] if v0 else None,
                                 nu0_status=R0['status'],nu_status=rr['status'],
                                 nu0_tau=R0.get('tau'),nu_tau=rr.get('tau'),
                                 nu0_D=R0.get('D'),nu_D=rr.get('D'),
                                 delta_D=(rr['D']-R0['D']) if rr['status']==R0['status']=='LOCAL_MIN' else None,
                                 nu0_e5_over_H=R0.get('e5_over_H'),nu_e5_over_H=rr.get('e5_over_H')))
    trend=[]
    for j in (1,2,3,4):
        for n in (900,1800):
            values=[next((x for x in zero if x['return_index']==j and x['N']==n and x['nu']==nu),None)
                    for nu in (0.004,0.001,0.00025)]
            dels=[x.get('delta_D') if x else None for x in values]
            allok=all(d is not None for d in dels)
            mono=(abs(dels[0])>=abs(dels[1])>=abs(dels[2])) if allok else None
            trend.append(dict(return_index=j,N=n,nu_values='0.004;0.001;0.00025',
                              delta_D_high=dels[0],delta_D_mid=dels[1],delta_D_low=dels[2],
                              monotone_approach_to_zero_in_three_samples=mono,
                              caution='Finite-grid observation; never a proof of nu->0 convergence'))
    save_csv(analysis/'nu_trend.csv',trend,list(trend[0]))
    save_csv(analysis/'inventory.csv',inventory,list(inventory[0]))
    returnfields=['run_id','nu','N','dt_divisor','regularization','project_half','strict','index',
                  'status','tau','D','H','r','Phi1','e5','e5_over_H','mass','I_p1','modal_identity_defect',
                  'local_output_spacing_tau','grid_index','n_local_minima']
    save_csv(analysis/'return_catalog.csv',returns,returnfields)
    refcols=['nu','return','dimension','N0','N1','dtdiv0','dtdiv1','status','n_common',
             'max_L2','final_L2','rms_L2','tau_at_max','tau_start','tau_end']
    save_csv(analysis/'refinement.csv',ref,refcols)
    save_csv(analysis/'other_controls.csv',ctrl,['nu','type','N','status','n_common','max_L2','final_L2','rms_L2','tau_at_max','tau_start','tau_end'])
    save_csv(analysis/'zero_nu_comparison.csv',zero,list(zero[0]))
    save_csv(analysis/'weak_residuals.csv',weak,['run_id','nu','N','segment','tau','harmonic','residual_abs','denominator','relative_residual'])
    save_csv(analysis/'weak_spacetime.csv',weakspace,
             ['run_id','index','harmonic','status','nu','N','tau_a','tau_b','n_samples','residual_abs','normalization','relative_residual'])
    save_csv(analysis/'audits.csv',audits,list(audits[0]) if audits else ['run_id','status'])
    weakstats=[]
    for (nu,n,seg),rlist in sorted(groupby_rows(weak,('nu','N','segment')).items()):
        s=[x['relative_residual'] for x in rlist if x['relative_residual'] is not None]
        weakstats.append(dict(nu=nu,N=n,segment=seg,n_tests=len(s),max_relative=max(s) if s else None,
                              rms_relative=float(np.sqrt(np.mean(np.square(s)))) if s else None))
    save_csv(analysis/'weak_summary.csv',weakstats,['nu','N','segment','n_tests','max_relative','rms_relative'])
    wsstats=[]
    for (nu,n,j),items in sorted(groupby_rows([x for x in weakspace if x.get('status')=='OK'],('nu','N','index')).items()):
        s=[x['relative_residual'] for x in items if x['relative_residual'] is not None]
        wsstats.append(dict(nu=nu,N=n,index=j,n_tests=len(s),max_relative=max(s) if s else None,
                            rms_relative=float(np.sqrt(np.mean(np.square(s)))) if s else None))
    save_csv(analysis/'weak_spacetime_summary.csv',wsstats,
             ['nu','N','index','n_tests','max_relative','rms_relative'])
    complete=sum(x['status']=='COMPLETED' for x in inventory)
    status=dict(phase='fase6',status='DATA_COMPLETE' if complete==len(inventory) else 'PARTIAL',
                n_completed=complete,n_planned=len(inventory),n_missing=len(inventory)-complete,
                scientifically_closed=False,ready_for_scientific_review=(complete==len(inventory)),
                inventory_files='inventory.csv',n_local_minima=sum(r['status']=='LOCAL_MIN' for r in returns),
                n_fourier_tests=len(weak),n_spacetime_weak_tests=len(weakspace),errors=errors,
                interpretation=[
                  'nu is held fixed in physical units when N and time step vary; nu != eta*dx**4',
                  'For nu>0, the functional I_(p+1) is not assumed conserved or monotonically dissipated; audit its balance.',
                  'At fixed nu the finite-grid refinements precede comparisons with nu=0, not the reverse.',
                  'Pointwise Fourier residual uses model.velocity at saved states; separate spacetime weak residual uses only H5 snapshots and smooth time-test functions, with quadrature error.',
                  'The alternative biharmonic stencil changes only the regularizing term; it is not a second independent spatial scheme for the full PDE.',
                  'The projected Z evolutions belong to the discrete half-wave antisymmetric subspace; unprojected controls must be reported.',
                  'A returning minimum with D<1 need not be converged as a continuum solution; compare full fields.',
                  'Only 3 positive nu values; a nu->0 continuum limit cannot be proved from this finite study.',
                  'Late-time comparisons of nu>0 with nu=0 involve different temporal accuracy histories.'
                ])
    (analysis/'status.json').write_text(json.dumps(status,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    try:plot(analysis,returns,ref)
    except ImportError:pass
    print('FASE6_ANALISIS_'+('COMPLETO' if complete==len(inventory) else 'PARCIAL'),complete,'/',len(inventory),
          'retornos',status['n_local_minima'],'test_modes',len(weak),flush=True)
    return status

def groupby_rows(rows,fields):
    o=defaultdict(list)
    for r in rows:o[tuple(r[f] for f in fields)].append(r)
    return o

def plot(folder,rets,ref):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(7,4))
    for nu in NUS:
        q=sorted([r for r in rets if r['status']=='LOCAL_MIN' and r['nu']==nu and r['N']==1800
                   and r['dt_divisor']==1 and r['strict']==0 and r['project_half']==1
                   and r['regularization']=='fourth_order'],key=lambda r:r['index'])
        if q:ax.plot([r['index'] for r in q],[r['D'] for r in q],marker='o',label=f'nu={nu:g}')
    ax.set(xlabel='Return index j',ylabel='D_rec at local minimum',title='Regularized recurrence at N=1800')
    ax.set_xticks((1,2,3,4));
    if ax.lines:ax.legend()
    fig.tight_layout()
    fig.savefig(folder/'regularized_returns.png',dpi=170);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,4))
    for j in (1,2,3,4):
        q=sorted([r for r in ref if r['return']==j and r['dimension']=='spatial' and r['N0']==900
                 and r.get('status')=='OK'],key=lambda r:r['nu'])
        if q:ax.plot([r['nu'] for r in q],[r['max_L2'] for r in q],marker='o',label=f'j={j}')
    ax.set(xlabel='Physical nu',ylabel='max normalized field difference',title='900 vs 1800 spatial budget')
    if ax.lines:ax.legend()
    fig.tight_layout();fig.savefig(folder/'fixed_nu_spatial.png',dpi=170);plt.close(fig)

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',default='.')
    p.add_argument('--output',default='fase6/results/analysis')
    a=p.parse_args();produce(a.root,a.output)

if __name__=='__main__':main()
