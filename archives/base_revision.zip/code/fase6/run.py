"""Checkpointable fixed-step Radau IIA5; nu is physical and independent of N.

A distinct file is produced for every (nu,N,dt,segment,control). No implicit
step halving; stronger Newton only changes algebraic globalization.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import time

import h5py
import numpy as np
import scipy

from absk_radau.io import H5Recorder
from absk_radau.model import PeriodicAbsK,domain_length,crossing_time,make_initial_data
from absk_radau.radau_mass import MassRadau5,NewtonOptions,NewtonFailure,RunStats
from fase6.design import BASE_STEPS_PER_TAU,read_manifest

def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def clock(row):
    tcr=crossing_time(2.25,4,1.)
    div=int(row['dt_divisor']);kpt=BASE_STEPS_PER_TAU*div
    return tcr,tcr/kpt,kpt

def solvers(model,row):
    strict=bool(int(row['strict']))
    a=1e-13 if strict else 1e-11
    r=1e-11 if strict else 1e-9
    it=16 if strict else 12
    configs=[('original',NewtonOptions(atol=a,rtol=r,max_iter=it,line_search_backtracks=10,predictor='euler')),
             ('extended_euler',NewtonOptions(atol=a,rtol=r,max_iter=max(it,32),line_search_backtracks=22,predictor='euler')),
             ('extended_constant',NewtonOptions(atol=a,rtol=r,max_iter=max(it,32),line_search_backtracks=22,predictor='constant'))]
    return [(name,MassRadau5(model,opt,project_half=bool(int(row['project_half'])))) for name,opt in configs]

def result_filename(outfolder,row):
    return Path(outfolder)/f"{row['run_id']}.h5"

def source_filename(root,row):
    name=row['source_run_id']+'.h5'
    source=Path(root)/'fase6/results'/('short' if int(row['segment'])==2 else 'long')/name
    return source

def read_source(source,row,tc):
    with h5py.File(source,'r') as h:
        assert h.attrs['status']=='COMPLETED',f'Checkpoint incompleto: {source}'
        cfg=json.loads(h.attrs['config_json'])
        assert cfg['run_id']==row['source_run_id']
        assert abs(float(cfg['nu'])-float(row['nu']))<1e-14
        assert int(cfg['N'])==int(row['N'])
        assert int(cfg['dt_divisor'])==int(row['dt_divisor'])
        assert bool(cfg['project_half'])==bool(int(row['project_half']))
        assert cfg['regularization']==row['regularization']
        assert abs(float(h['t'][-1])/tc-float(row['tau_start']))<2e-11
        u=h['u'][-1,:].copy()
        assert len(u)==int(row['N']) and np.all(np.isfinite(u))
    return u,sha256(source)

def is_completed(dest,row,tc):
    if not dest.is_file() or not dest.with_suffix('.audit.json').is_file():return False
    try:
        with h5py.File(dest,'r') as h:
            cfg=json.loads(h.attrs['config_json'])
            return (h.attrs['status']=='COMPLETED' and cfg['run_id']==row['run_id']
                and abs(h['t'][-1]/tc-float(row['tau_end']))<2e-11)
    except (OSError,KeyError,ValueError):return False

def should_save(k,kpt):
    # Sparse background samples every 0.01 tau; dense every .000625 near integer returns.
    # For div=1, 2, 4, stride=2,4,8 and 32,64,128, respectively.
    return k%(kpt//100)==0 or (any(abs(k/kpt-j)<=0.125000001 for j in (1,2,3,4)) and k%(kpt//1600)==0)

def run(row, *,base='.',output=None):
    tc,dt,kpt=clock(row)
    start=float(row['tau_start']);end=float(row['tau_end'])
    k0=round(start*kpt);k1=round(end*kpt)
    if not (k0/kpt==start and k1/kpt==end and k1>k0):
        raise RuntimeError('Tiempos no representables exactamente con el calendario')
    if output is None:
        output=f"fase6/results/{row['kind']}"
    dest=result_filename(output,row)
    if dest.exists():
        if is_completed(dest,row,tc):
            print('FASE6_REUTILIZADA',row['run_id'],flush=True)
            return json.loads(dest.with_suffix('.audit.json').read_text())
        raise FileExistsError('HDF5 existente incompleto/no verificable; no sobreescribir: '+str(dest))
    n=int(row['N']);nu=float(row['nu']);l=domain_length(2.25,4)
    model=PeriodicAbsK(n,l,2.25,nu,regularization=row['regularization'])
    variants=solvers(model,row)
    origin='initial_data'
    origin_hash=None
    if row['kind']=='short':
        u=make_initial_data(model,'Z',1.)
        u=variants[0][1].project(u)
        if start!=0:raise ValueError('short starts at 0')
    else:
        origin=source_filename(base,row)
        if not origin.is_file(): raise FileNotFoundError('No existe checkpoint origen: '+str(origin))
        u,origin_hash=read_source(origin,row,tc)
    config=dict(phase='fase6',run_id=row['run_id'],kind=row['kind'],segment=int(row['segment']),
                p=2.25,M=4,N=n,nu=nu,family='Z',amplitude=1.,project_half=bool(int(row['project_half'])),
                regularization=row['regularization'],strict=bool(int(row['strict'])),
                dt_divisor=int(row['dt_divisor']),dt=dt,steps_per_tau=kpt,
                T_cross=tc,tau_start=start,tau_end=end,source=str(origin),source_sha256=origin_hash,
                fixed_dt=True,nu_independent_of_dx=True,
                method='Radau IIA5 3 stage mass matrix; globalized Newton fallback with unchanged tolerances',
                newton_atol=(1e-13 if int(row['strict']) else 1e-11),
                newton_rtol=(1e-11 if int(row['strict']) else 1e-9),
                software=dict(python=sys.version.split()[0],numpy=np.__version__,
                    scipy=scipy.__version__,h5py=h5py.__version__,platform=platform.platform()))
    dest.parent.mkdir(parents=True,exist_ok=True)
    print('FASE6_START',row['run_id'],'nu',nu,'N',n,'dt',dt,'tau',start,end,'nsteps',k1-k0,flush=True)
    record=H5Recorder(dest,model,config,'Z',1.)
    stats=RunStats(mode='fixed_physical_nu')
    fallbacks={name:0 for name,_ in variants}
    tbegin=time.perf_counter()
    try:
        record(k0*dt,u,stats)
        for k in range(k0+1,k1+1):
            errors=[]
            for name,sol in variants:
                try:
                    un,diag=sol.step(u,dt)
                    break
                except NewtonFailure as exc:errors.append(f'{name}: {exc}')
            else:
                failure=dict(status='FAILED_FIXED_DT',run_id=row['run_id'],nu=nu,N=n,
                             tau_before=(k-1)/kpt,tau_failed=k/kpt,dt=dt,fall_back=fallbacks,
                             errors=errors,last_saved_tau=float(record.h5['t'][-1])/tc)
                dest.with_suffix('.failure.json').write_text(json.dumps(failure,indent=2,ensure_ascii=False)+'\n')
                raise NewtonFailure('FASE6_FIXED_DT_UNRESOLVED '+json.dumps(failure))
            u=un;fallbacks[name]+=1
            stats.add_step(diag,dt)
            stats.final_time=k*dt
            record.on_step(k*dt,dt,diag,'accepted',float('nan'))
            if should_save(k,kpt) or k==k1:record(k*dt,u,stats)
            if (k-k0) % max(1,(k1-k0)//4)==0:
                print('FASE6_PROGRESS',row['run_id'],f'{k-k0}/{k1-k0}','fallback',fallbacks,flush=True)
        record.finish(stats)
    except BaseException as exc:
        record.fail(exc)
        raise
    with h5py.File(dest,'r') as h:
        t=h['t'][:];d=h['diagnostics'][:];logs=h['step_log'][:]
        assert h.attrs['status']=='COMPLETED'
        assert len(logs)==k1-k0 and np.all(logs[:,7]==1)
        assert np.max(logs[:,4])<=1+1e-10
        assert np.max(np.abs(logs[:,1]-dt))<1e-12
        assert np.all(np.diff(t)>0) and abs(t[-1]/tc-end)<2e-11
        assert np.all(np.isfinite(d[:,[1,2,3,5,7,8,9]]))
        balance_approx=float(np.trapezoid(d[:,3],t))
        delta_i=float(d[-1,2]-d[0,2]);i0=float(d[0,2])
        audit=dict(status='COMPLETED',run_id=row['run_id'],nu=nu,N=n,
                   dt_divisor=int(row['dt_divisor']),segment=int(row['segment']),
                   tau_start=start,tau_end=end,nu_independent_of_dx=True,
                   project_half=bool(int(row['project_half'])),regularization=row['regularization'],
                   n_accepted=k1-k0,n_snapshots=len(t),max_newton_residual=float(np.max(logs[:,4])),
                   max_newton_iters=int(np.max(logs[:,2])),fallback_counts=fallbacks,
                   mass_max_drift=float(np.max(abs(d[:,1]-d[0,1]))),
                   lp_relative_change=float(delta_i/max(abs(i0),1e-300)),
                   lp_balance_integral_trapezoid=balance_approx,
                   lp_balance_defect=float((delta_i-balance_approx)/max(abs(i0),1e-300)),
                   halfwave_defect_max=float(np.max(d[:,4])),
                   wall_seconds=time.perf_counter()-tbegin,source_sha256=origin_hash,
                   sha256_h5=sha256(dest))
    dest.with_suffix('.audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    print('FASE6_CASE_OK',row['run_id'],'nu',nu,'N',n,'accepted',k1-k0,
          'fallback',fallbacks,'max_rms',audit['max_newton_residual'],flush=True)
    return audit

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--manifest',required=True)
    p.add_argument('--index',type=int,required=True)
    p.add_argument('--base',default='.')
    p.add_argument('--output')
    args=p.parse_args()
    rows=read_manifest(args.manifest)
    if args.index<1 or args.index>len(rows): raise SystemExit('Indice invalido')
    run(rows[args.index-1],base=args.base,output=args.output)

if __name__=='__main__':main()
