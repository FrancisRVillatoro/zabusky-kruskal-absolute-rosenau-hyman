"""Executable unit tests for Phase 1 identities; DOES NOT integrate the PDE."""
import json
from pathlib import Path
import numpy as np
from modal_diagnostics import one_harmonic_diagnostics as diag, data_profile, modal_balance_rhs

N=1024
L=16*np.pi
x=L*np.arange(N)/N
rng=np.random.default_rng(24052026)
results={}

def check(name, value, tol):
    v=float(value)
    results[name]={'absolute_error':v,'tolerance':tol,'pass':v <= tol}
    assert v <= tol, (name,v,tol)

# Arbitrary real field with several harmonics, nonconserved mean, and random noise.
u=.37+.42*np.cos(2*np.pi*(x/L-.29))+.12*np.sin(4*np.pi*x/L)+.06*np.cos(14*np.pi*x/L)+.01*rng.normal(size=N)
a=.5; b=.65
z=diag(u,L,a,b,2.25)
# Independent discrete L2 calculation at the analytically optimal shift.
u0star=a+b*np.cos(2*np.pi*(x-z.xi_opt)/L)
d_direct=np.linalg.norm(u-u0star)/np.linalg.norm(a+b*np.cos(2*np.pi*x/L))
check('single-harmonic Parseval continuous-shift identity', z.D_cont-d_direct, 1e-12)
check('D_cont decomposition versus Qosc/Phi1',
      z.D_cont**2-((z.mean_u-a)**2/(a*a+b*b/2)+
      (b*b/2)/(a*a+b*b/2)*(1+z.Qosc-2*np.sqrt(z.Qosc*z.Phi1))),1e-12)
# Grid shifts cannot beat the continuous optimal shift.
check('grid shift distance versus independent minimum',
      z.D_grid-min(np.linalg.norm(u-(a+b*np.cos(2*np.pi*(x-k*L/N)/L))) for k in range(N))/np.linalg.norm(a+b*np.cos(2*np.pi*x/L)),1e-12)
assert z.D_grid+1e-12>=z.D_cont
results['shift_grid_bias_positive']={'value':z.D_grid-z.D_cont,'pass':True}

# For exact shifted cosine, identity gives zero (float precision).
initial=data_profile(x,L,'Z')
shifted=np.cos(2*np.pi*(x/L-.123456))
zz=diag(shifted,L,0.,1.)
check('exactly translated cosine D_cont',zz.D_cont,1e-10)
# For Z the global sign is a shift by L/2; no extra sign minimization.
check('Z sign reversal equals half-period shift',
      np.linalg.norm(-initial-data_profile(x+L/2,L,'Z'))/np.linalg.norm(initial),1e-13)
# P factor of 1/3 when mean preserved.
pv=data_profile(x,L,'P')+.02*np.cos(6*np.pi*x/L)
pp=diag(pv,L,.5,.5)
check('P mean and fundamental factor', pp.D_cont**2-pp.H_high/3,1e-12)
# A_mass is exactly normalized mean (and NOT a half-wave diagnostic).
check('positive-negative mass equals normalized mean',
      z.Amass-abs(np.mean(u))/np.mean(np.abs(u)),1e-15)
# Perturbation half-wave initial value.
eps=.05
ze=data_profile(x,L,'ZE05',epsilon=eps)
zet=diag(ze,L,0.,1.)
check('ZE05 half-wave initial analytical value',
      zet.Ahalf-2*eps/np.sqrt(1+eps*eps),2e-13)
# At n=0 mass mode has zero formal RHS, with or without dissipation.
for nu in (0.,1.e-4):
    check(f'zero Fourier mode balance, nu={nu:g}',
          modal_balance_rhs(u,L,p=2.25,nu=nu)[0],1e-14)
# Amplitude scaling with identical nu_eff: direct algebra of transformed PDE.
for p in (2.,2.25,3.):
    A=1.7; nu=.004
    check(f'amplitude reduced viscosity p={p}', (nu/A**(p-1))*A**(p-1)-nu, 1e-15)

# Independent Fourier calculation: the mode-wise rate agrees with the
# derivative computed from a pseudo-spectral RHS on a smooth positive field.
up = 1.5 + 0.2*np.cos(2*np.pi*x/L) + 0.06*np.sin(6*np.pi*x/L)
pexp = 2.25
vcoeff = np.fft.rfft(up)
kk = 2*np.pi*np.fft.rfftfreq(N, d=L/N)
fluxcoeff = np.fft.rfft(up**pexp)
nu_test = 1e-4
udot = np.fft.irfft(-1j*kk*(1-kk**2)*fluxcoeff -nu_test*kk**4*vcoeff,n=N)
rhs = modal_balance_rhs(up,L,pexp,nu_test)
hat0=np.fft.rfft(up)/N
hdot=np.fft.rfft(udot)/N
rates=2*np.real(np.conj(hat0)*hdot)
check('modal transfer and damping rate from independent spectral RHS',
      np.max(abs(rhs-rates)),1e-12)
check('mean conservation from spectral RHS',np.mean(udot),1e-12)
# For nu=0, I_(p+1) is preserved exactly by the skew discrete operator
# in this periodic Fourier collocation check (up to roundoff).
udot0=np.fft.irfft(-1j*kk*(1-kk**2)*fluxcoeff,n=N)
check('I_(p+1) semidiscrete balance for nu=0',
      (L/N)*np.dot(up**pexp,udot0),1e-12)

print(json.dumps({'tests':results,'passed':all(c['pass'] for c in results.values()),
                  'note':'Algebraic and Fourier checks only; no continuum/PDE solver validation.'},indent=2))
Path(__file__).with_name('checks_phase1.json').write_text(json.dumps({'tests':results,'passed':True},indent=2)+'\n')
