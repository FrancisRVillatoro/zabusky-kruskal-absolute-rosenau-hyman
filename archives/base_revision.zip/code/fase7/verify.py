"""Phase 7 amplitude covariance verification (CNSNS |K|(p,p)).

Requires the *unchanged* phase-2 absk_radau package, NumPy, SciPy, Matplotlib.
This is a finite-dimensional consistency test, not a PDE well-posedness proof.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np

from absk_radau.model import PeriodicAbsK, make_initial_data, domain_length, crossing_time
from absk_radau.radau_mass import MassRadau5, NewtonOptions
from absk_radau.modal_diagnostics import one_harmonic_diagnostics

RETURNS = [(1, 1.0090625, 0.0460305690393),
           (2, 2.019375, 0.077838723059),
           (3, 3.02625, 0.127966132776),
           (4, 4.0334375, 0.237769)]


def configuration(p, M, family, nu0, amplitude, N, projected, *, fixed_nu=False):
    nu = nu0 if fixed_nu else nu0 * amplitude ** (p - 1)
    model = PeriodicAbsK(N, domain_length(p, M), p, nu=nu)
    u0 = make_initial_data(model, family, amplitude=amplitude)
    # Absolute residual tolerance must scale with field amplitude if the
    # *Newton stopping rule itself* is to be covariant.
    options = NewtonOptions(atol=1e-12 * amplitude, rtol=1e-10,
                            max_iter=20, line_search_backtracks=16,
                            predictor='constant')
    solver = MassRadau5(model, options, project_half=projected)
    return model, u0, solver


def evolution(p, M, family, nu0, amplitude, N=80, projected=False,
              tau_end=0.04, delta_tau=0.002, *, fixed_nu=False):
    nsteps = round(tau_end / delta_tau)
    assert abs(nsteps * delta_tau-tau_end)<1e-12
    model, u, solver = configuration(p,M,family,nu0,amplitude,N,projected,
                                      fixed_nu=fixed_nu)
    physical_h = crossing_time(p, M, amplitude) * delta_tau
    outputs = [u.copy()]
    scaled_residuals = []
    for k in range(1, nsteps+1):
        u, d = solver.step(u, physical_h)
        outputs.append(u.copy())
        scaled_residuals.append(d.norm_residual)
    return np.arange(nsteps+1)*delta_tau, np.array(outputs), max(scaled_residuals)


def check_operator(p, M, family, nu0, a, N=80, projected=False):
    ref, u, sol = configuration(p,M,family,nu0,1.,N,projected)
    new, v, sol2 = configuration(p,M,family,nu0,a,N,projected)
    scale = a ** p
    rhs_ref = ref.rhs(u)
    rhs_matched = new.rhs(v)
    rhs_error = np.max(np.abs(rhs_matched - scale*rhs_ref))
    ref_j = ref.jac(u)
    new_j = new.jac(v)
    jerr = np.max(np.abs((new_j - a**(p-1)*ref_j).toarray()))
    assert rhs_error < 1e-10, (p, a, nu0, rhs_error)
    assert jerr < 1e-10, (p, a, nu0, jerr)
    # Same exact equation after scaling only if nu scales as A^(p-1).
    if nu0:
        fixed, v2, _ = configuration(p,M,family,nu0,a,N,projected,fixed_nu=True)
        mismatch = np.max(np.abs(fixed.rhs(v2) - scale*rhs_ref))
        expected = np.max(np.abs((nu0-new.nu) * ref.Dmass @ v2))
        assert np.isclose(mismatch, expected, atol=2e-11, rtol=1e-8)
    else:
        mismatch = 0.
    return rhs_error,jerr,mismatch


def modal_row(u, L, family, amplitude, p):
    a,b = (amplitude*.5,amplitude*.5) if family.upper()=='P' else (0.,amplitude)
    d=one_harmonic_diagnostics(u,L,a,b,p=p)
    return (d.D_cont, d.Phi1, d.r, d.H_high, d.I_p1)


def run(outdir: Path):
    outdir.mkdir(parents=True,exist_ok=True)
    cases = [
        dict(case='Z_p225_M4_nu0_proj', p=2.25, M=4, family='Z',nu0=0.,projected=True),
        dict(case='Z_p225_M4_nu0_unproj', p=2.25, M=4, family='Z',nu0=0.,projected=False),
        dict(case='Z_p225_M4_nu004_proj', p=2.25, M=4, family='Z',nu0=.004,projected=True),
        dict(case='P_p2_M8_nu0', p=2., M=8, family='P',nu0=0.,projected=False),
    ]
    rows=[]; curve=[]
    for case in cases:
        name=case['case']; kw={k:v for k,v in case.items() if k!='case'}
        p,M,fam,nu0,proj = (kw[k] for k in ('p','M','family','nu0','projected'))
        tau,reference,rr=evolution(**kw,amplitude=1.)
        L=domain_length(p,M)
        for amp in (0.5,2.0):
            aa,jj,mismatch=check_operator(p,M,fam,nu0,amp,projected=proj)
            ts,scaled,r2=evolution(**kw,amplitude=amp)
            field_difference=np.max(np.abs(scaled/amp-reference),axis=1)
            diagerr=0.
            for i in range(len(ts)):
                d0=modal_row(reference[i],L,fam,1.,p)
                da=modal_row(scaled[i],L,fam,amp,p)
                diagerr=max(diagerr,max(abs(d0[j]-da[j]) for j in range(4)))
                # I_(p+1) scales by amplitude^(p+1) not invariant itself
                diagerr=max(diagerr,abs(d0[4]-da[4]/amp**(p+1)))
                curve.append({'case':name,'A':amp,'tau':ts[i],
                              'field_normalized_error':field_difference[i],
                              'D_reference':d0[0], 'D_rescaled':da[0]})
            rows.append({'case':name, 'A':amp, 'p':p,'nu_ref':nu0,
                         'nu_scaled':nu0*amp**(p-1),
                         'rhs_absolute_error':aa,'jac_absolute_error':jj,
                         'fixed_nu_rhs_mismatch':mismatch,
                         'max_normalized_field_error':max(field_difference),
                         'max_modal_and_invariant_error':diagerr,
                         'max_newton_scaled_residual':max(rr,r2),
                         'tau_end':tau[-1],'N':len(reference[0])})
    def savecsv(path, data):
        with open(path,'w',newline='',encoding='utf-8') as fp:
            w=csv.DictWriter(fp,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    savecsv(outdir/'scale_verification.csv',rows)
    savecsv(outdir/'scale_error_curves.csv',curve)
    returnrows=[]
    p=2.25; M=4
    for j,tauj,Dj in RETURNS:
        for a in (0.5,1.,2.):
            returnrows.append({'return_j':j,'amplitude_A':a,
                              'tau_j':tauj, 'D_j':Dj,
                              't_physical_predicted':tauj*crossing_time(p,M,a),
                              'Tcross':crossing_time(p,M,a),
                              'prediction_not_new_simulation':True})
    savecsv(outdir/'predicted_return_times.csv',returnrows)
    maxfield=max(x['max_normalized_field_error'] for x in rows)
    maxmodal=max(x['max_modal_and_invariant_error'] for x in rows)
    summary={'tests':'operator + Jacobian + short Radau evolution + modal invariance',
             'cases':len(rows),'projected_and_unprojected':True,
             'max_normalized_field_error':maxfield,
             'max_modal_and_invariant_error':maxmodal,
             'max_newton_scaled_residual':max(x['max_newton_scaled_residual'] for x in rows),
             'all_success':True,
             'warning':'Short-time, finite-N software verification only; no continuum PDE convergence claim.',
             'return_time_table':'By exact scaling from phase-4/4B A=1 data, not new long integrations.'}
    (outdir/'verification_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8,4.5))
    for entry in rows:
        subset=[x for x in curve if x['case']==entry['case'] and x['A']==entry['A']]
        ax.semilogy([x['tau'] for x in subset],
                    [max(x['field_normalized_error'],1e-16) for x in subset],
                    label=f"{entry['case']}, A={entry['A']:g}")
    ax.set(xlabel=r'Normalized time $\tau$',ylabel=r'$\|u_A/A-u_1\|_\infty$',
           title='Amplitude covariance: short Radau integrations')
    ax.grid(alpha=.25); ax.legend(fontsize=6.6,ncol=2)
    fig.tight_layout();fig.savefig(outdir/'amplitude_covariance.png',dpi=170)
    plt.close(fig)
    print('FASE7_VERIFICACION_OK',json.dumps(summary))
    for row in rows: print('FASE7_CASE_OK',row['case'],f"A={row['A']}",
                           f"field={row['max_normalized_field_error']:.3g}",
                           f"modal={row['max_modal_and_invariant_error']:.3g}")
    return summary


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--outdir',type=Path,default=Path('fase7/results/local'))
    args=p.parse_args();run(args.outdir)

if __name__=='__main__':main()
