"""Algebraic and numerical regression for exact amplitude scaling."""
import unittest
import numpy as np
from absk_radau.model import PeriodicAbsK,domain_length,crossing_time,make_initial_data
from absk_radau.radau_mass import MassRadau5,NewtonOptions
from absk_radau.modal_diagnostics import one_harmonic_diagnostics
from fase7.verify import check_operator,configuration,evolution

class ScalingTests(unittest.TestCase):
    def test_travel_time(self):
        for p in (1.75,2.0,2.25,3.0):
            for a in (0.5,2.,3.):
                x=crossing_time(p,4,a)
                y=crossing_time(p,4,1.)*a**(1-p)
                self.assertAlmostEqual(x,y,places=12)

    def test_discrete_operator_nu0(self):
        for fam,pp,pr in [('Z',2.25,True),('P',2.,False)]:
            e,j,m=check_operator(pp,4,fam,0.,2.,projected=pr)
            self.assertLess(e,1e-10)
            self.assertLess(j,1e-10)
            self.assertEqual(m,0.)

    def test_fixed_nu_does_not_scale(self):
        e,j,m=check_operator(2.25,4,'Z',0.004,2.,projected=True)
        self.assertLess(e,1e-10)
        self.assertLess(j,1e-10)
        self.assertGreater(m,1e-7)  # at N=80: nonzero mismatch

    def test_one_step_radau_projected(self):
        p=2.25;M=4;a=2.;nu=.004;N=80
        m,u,s=configuration(p,M,'Z',nu,1.,N,True)
        q,v,t=configuration(p,M,'Z',nu,a,N,True)
        dt=crossing_time(p,M,1.)*.001
        un,d=s.step(u,dt)
        vn,d2=t.step(v,dt/a**(p-1))
        self.assertLess(np.max(np.abs(vn/a-un)),1e-9)

    def test_modal_and_I_scaling(self):
        p=2.25;M=4;a=2.3;N=80;L=domain_length(p,M)
        model=PeriodicAbsK(N,L,p)
        u=make_initial_data(model,'Z')+0.13*np.sin(3*2*np.pi*model.x/L)
        z=one_harmonic_diagnostics(u,L,0.,1.,p)
        w=one_harmonic_diagnostics(a*u,L,0.,a,p)
        for field in ('D_cont','r','H_high','Phi1'):
            self.assertLess(abs(getattr(z,field)-getattr(w,field)),1e-13)
        self.assertLess(abs(w.I_p1/a**(p+1)-z.I_p1),1e-11)

    def test_short_trajectory_nu0(self):
        kw=dict(p=2.25,M=4,family='Z',nu0=0.,N=80,projected=True,
                tau_end=0.008,delta_tau=0.002)
        x,ua,_=evolution(amplitude=1.,**kw)
        y,ub,_=evolution(amplitude=2.,**kw)
        self.assertTrue(np.array_equal(x,y))
        self.assertLess(np.max(np.abs(ua-ub/2.)),1e-9)

    def test_short_trajectory_nupositive(self):
        kw=dict(p=2.25,M=4,family='Z',nu0=.004,N=80,projected=True,
                tau_end=0.008,delta_tau=0.002)
        x,ua,_=evolution(amplitude=1.,**kw)
        y,ub,_=evolution(amplitude=2.,**kw)
        self.assertLess(np.max(np.abs(ua-ub/2.)),1e-9)

if __name__=='__main__':unittest.main()
