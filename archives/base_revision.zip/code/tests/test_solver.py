"""Independent numerical tests; run: python -m unittest discover -s tests -v"""
import math
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
from scipy import sparse
from scipy.integrate import solve_ivp
from absk_radau import PeriodicAbsK, MassRadau5, NewtonOptions, A_R, B_R, C, integrate
from absk_radau.model import make_initial_data, crossing_time, domain_length


class LinearScalarWithMass:
    def __init__(self):
        self.mass=sparse.csr_matrix([[2.]])
    def rhs(self,u):
        return -2.*u
    def jac(self,u):
        return sparse.csr_matrix([[-2.]])


class Tests(unittest.TestCase):
    def test_radau_tableau(self):
        np.testing.assert_allclose(A_R.sum(axis=1),C,rtol=0,atol=3e-16)
        np.testing.assert_allclose(A_R[-1,:],B_R,rtol=0,atol=0)
        for k in range(1,6):
            self.assertAlmostEqual(float(np.dot(B_R,C**(k-1))),1/k,places=14)

    def test_scalar_mass_order_five(self):
        solver=MassRadau5(LinearScalarWithMass())
        errs=[]
        for h in (.5,.25,.125):
            ts,yy,stats=integrate(solver,np.array([1.]),1.,h,save_every=20)
            self.assertEqual(stats.accepted,round(1/h))
            errs.append(abs(float(yy[-1,0])-math.exp(-1.)))
        self.assertGreater(errs[0]/errs[1],20.)
        self.assertGreater(errs[1]/errs[2],20.)

    def test_periodic_stencil_no_duplicate(self):
        m=PeriodicAbsK(64,50.,2.)
        self.assertEqual(len(m.x),64)
        self.assertLess(m.x[-1],m.L)
        one=np.ones(m.n)
        np.testing.assert_allclose(m.mass@one,one,atol=2e-14)
        np.testing.assert_allclose(m.B@one,0.,atol=2e-13)
        np.testing.assert_allclose(m.C@one,0.,atol=2e-13)
        np.testing.assert_allclose(m.Q@one,0.,atol=2e-13)
        np.testing.assert_allclose(m.mass.toarray(),m.mass.toarray().T,atol=2e-14)
        np.testing.assert_allclose(m.K.toarray(),-m.K.toarray().T,atol=2e-14)

    def test_jacobian_directional_fd(self):
        m=PeriodicAbsK(32,2*np.pi*4,2.25,nu=1.e-4)
        rng=np.random.default_rng(20261117)
        u=0.5+rng.standard_normal(32)*.2
        v=rng.standard_normal(32); v/=np.linalg.norm(v)
        eps=1.e-6
        Jv=m.jac(u)@v
        fd=(m.rhs(u+eps*v)-m.rhs(u-eps*v))/(2*eps)
        self.assertLess(np.linalg.norm(fd-Jv)/np.linalg.norm(Jv),1.e-6)

    def test_stage_jacobian_directional_fd(self):
        m=PeriodicAbsK(24,50.,2.25,nu=1.e-4)
        solver=MassRadau5(m)
        rng=np.random.default_rng(11)
        u=np.cos(2*np.pi*m.x/m.L)
        y=np.tile(u,(3,1))+.01*rng.standard_normal((3,m.n))
        d=rng.standard_normal((3,m.n));d/=np.linalg.norm(d)
        eps=1e-6
        Jd=(solver.stage_jacobian(y,0.02)@d.flatten()).reshape((3,m.n))
        fd=(solver.stage_residual(u,y+eps*d,.02)-solver.stage_residual(u,y-eps*d,.02))/(2*eps)
        self.assertLess(np.linalg.norm(Jd-fd)/np.linalg.norm(Jd),1.e-7)

    def test_symmetry_equivariance_and_invariant(self):
        m=PeriodicAbsK(64,80.,2.25,nu=0.)
        rng=np.random.default_rng(17)
        u=rng.normal(size=m.n)
        np.testing.assert_allclose(m.rhs(np.roll(u,7)),np.roll(m.rhs(u),7),rtol=1.e-12,atol=1.e-12)
        self.assertAlmostEqual(m.mass_integral(m.velocity(u)),0.,delta=1.e-11)
        self.assertAlmostEqual(m.lp_balance_rhs(u),0.,delta=1.e-10)

    def test_regularization_positive_symbol_and_fourth_order(self):
        m=PeriodicAbsK(64,20.,2.,nu=.001)
        eig=np.linalg.eigvalsh(m.Q2.toarray())
        self.assertGreater(eig.min(),-1e-12)
        errs=[]
        for n in (32,64,128):
            md=PeriodicAbsK(n,2*np.pi,2.,nu=.001)
            x=md.x
            probe=np.cos(x)
            error=np.linalg.norm(md.Q2@probe-probe)/np.linalg.norm(probe)
            errs.append(error)
        self.assertGreater(errs[0]/errs[1],12.)
        self.assertGreater(errs[1]/errs[2],12.)

    def test_reference_scipy_radau(self):
        m=PeriodicAbsK(24,40.,2.,nu=5.e-5)
        u0=make_initial_data(m,'P')
        solver=MassRadau5(m,NewtonOptions(atol=1e-12,rtol=1e-11))
        t,history,stats=integrate(solver,u0,.05,.005,save_every=10)
        ref=solve_ivp(lambda tt,y:m.velocity(y),(0,.05),u0,method='Radau',rtol=1e-11,atol=1e-13)
        self.assertTrue(ref.success)
        self.assertLess(np.linalg.norm(history[-1]-ref.y[:,-1])/np.linalg.norm(u0),2.e-8)
        self.assertEqual(stats.rejected_newton,0)

    def test_Radau_mass_preserves_mean_no_nu(self):
        m=PeriodicAbsK(48,60.,2.)
        u0=make_initial_data(m,'Z')
        solver=MassRadau5(m)
        t,history,stats=integrate(solver,u0,.12,.01,save_every=4)
        self.assertEqual(stats.accepted,12)
        self.assertLess(abs(m.mass_integral(history[-1])-m.mass_integral(u0)),1.e-10)
        self.assertLess(abs(m.lp_invariant(history[-1])-m.lp_invariant(u0)),1.e-7)

    def test_projected_halfwave(self):
        m=PeriodicAbsK(32,50.,2.)
        u0=make_initial_data(m,'Z')
        u0+=1e-4*np.cos(4*np.pi*m.x/m.L)
        solver=MassRadau5(m,project_half=True)
        t,history,stats=integrate(solver,u0,.03,.01)
        self.assertLess(m.normalized_halfwave_defect(history[-1]),1e-13)

    def test_step_doubling(self):
        solver=MassRadau5(LinearScalarWithMass())
        t,yy,stats=integrate(solver,np.array([1.]),1.,.6,adaptive=True,
                              step_atol=1.e-8,step_rtol=1.e-8)
        self.assertAlmostEqual(t[-1],1.,places=14)
        self.assertLess(abs(yy[-1,0]-math.exp(-1)),1.e-7)
        self.assertGreater(stats.accepted,1)
        self.assertEqual(stats.mode,'doubling')

    def test_fourier_mode_linear_viscosity(self):
        model=PeriodicAbsK(64,2*np.pi,2.,nu=.2)
        class LinearViscous:
            mass=model.mass
            def rhs(self,y): return -.2*(model.Dmass@y)
            def jac(self,y): return -.2*model.Dmass
        solver=MassRadau5(LinearViscous())
        y0=np.cos(2*model.x)
        t,yy,stats=integrate(solver,y0,.4,.04,save_every=3)
        rate=float(np.dot(y0,model.Q2@y0)/np.dot(y0,y0))
        reference=np.exp(-.2*rate*.4)*y0
        self.assertLess(np.linalg.norm(yy[-1]-reference)/np.linalg.norm(y0),2.e-8)

    def test_rejection_never_silent_for_fixed_mode(self):
        from absk_radau.radau_mass import NewtonFailure
        class BadRhs:
            mass=sparse.csr_matrix([[1.]])
            def rhs(self,y): return np.array([float('nan')])
            def jac(self,y): return sparse.csr_matrix([[1.]])
        solver=MassRadau5(BadRhs())
        with self.assertRaises(NewtonFailure):
            solver.step(np.array([1.]),.01)
        with self.assertRaisesRegex(RuntimeError,'fixed step refused'):
            integrate(solver,np.array([1.]),.02,.01)

    def test_legacy_operator_separate_from_fourth_order(self):
        mnew=PeriodicAbsK(32,2*np.pi,2.,nu=.003)
        mold=PeriodicAbsK(32,2*np.pi,2.,nu=.003,regularization='legacy_second_order')
        np.testing.assert_allclose(mnew.mass.toarray(),mold.mass.toarray())
        np.testing.assert_allclose(mnew.K.toarray(),mold.K.toarray())
        self.assertGreater(np.linalg.norm((mnew.Dmass-mold.Dmass).toarray()),.01)

    def test_cli_hdf5_metadata(self):
        with tempfile.TemporaryDirectory() as folder:
            outfile=os.path.join(folder,'smoke.h5')
            p=subprocess.run([sys.executable,'-m','absk_radau.cli','--N','32','--p','2.0',
                 '--M','4','--family','Z','--tau-end','0.0003','--dt','0.002',
                 '--save-every','2','--out',outfile],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,msg=p.stdout+'\n'+p.stderr)
            import h5py
            with h5py.File(outfile,'r') as fh:
                self.assertEqual(fh.attrs['status'],'COMPLETED')
                self.assertEqual(fh['u'].shape[1],32)
                self.assertAlmostEqual(fh['t'][-1],fh.attrs['period'] / (.75) *.0003,places=12)
                self.assertEqual(fh['diagnostics'].shape[0],fh['t'].shape[0])
                self.assertEqual(fh['step_log'].shape[0],int(__import__('json').loads(fh.attrs['run_stats_json'])['accepted']))

if __name__=='__main__':
    unittest.main()
