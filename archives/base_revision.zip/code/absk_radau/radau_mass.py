"""Mass-matrix Radau IIA (3-stage, classical order five) for A u'=F(u).

Nonlinear stages are solved with a *true* 3N x 3N sparse Jacobian
using damped Newton, scaled stage residuals, sparse LU and step rejection.
Fixed steps are the primary validated research mode. Optional adaptivity
uses conservative step doubling (three solves per accepted step), rather
than pretending to implement the embedded SciPy Radau estimator.

No continuous PDE well-posedness or global error bound is implied.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Callable
import math
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu

SQRT6=np.sqrt(6.)
C=np.array([(4-SQRT6)/10., (4+SQRT6)/10., 1.])
A_R=np.array([
    [(88-7*SQRT6)/360., (296-169*SQRT6)/1800., (-2+3*SQRT6)/225.],
    [(296+169*SQRT6)/1800., (88+7*SQRT6)/360., (-2-3*SQRT6)/225.],
    [(16-SQRT6)/36., (16+SQRT6)/36., 1./9.]
],dtype=float)
B_R=A_R[2].copy()


class NewtonFailure(RuntimeError):
    pass


@dataclass
class NewtonOptions:
    atol: float=1e-11
    rtol: float=1e-9
    max_iter: int=12
    line_search_backtracks: int=10
    predictor: str='constant'  # or 'euler'

    def __post_init__(self):
        if not 0 < self.atol < 1 or not 0 < self.rtol < 1:
            raise ValueError('atol and rtol must be in (0,1)')
        if self.max_iter < 1 or self.line_search_backtracks < 0:
            raise ValueError('invalid Newton iteration limits')
        if self.predictor not in ('constant', 'euler'):
            raise ValueError('unknown predictor')


@dataclass
class StepData:
    iters: int
    nlu: int
    norm_residual: float
    damping_steps: int


@dataclass
class RunStats:
    accepted: int=0
    rejected_newton: int=0
    rejected_error: int=0
    total_newton_iterations: int=0
    total_lu: int=0
    max_scaled_residual: float=0.
    max_line_search_halvings: int=0
    min_accepted_dt: float=float('inf')
    max_accepted_dt: float=0.
    final_time: float=0.
    mode: str='fixed'

    def add_step(self, d: StepData, dt: float):
        self.accepted += 1
        self.total_newton_iterations += d.iters
        self.total_lu += d.nlu
        self.max_scaled_residual=max(self.max_scaled_residual,d.norm_residual)
        self.max_line_search_halvings=max(self.max_line_search_halvings,d.damping_steps)
        self.min_accepted_dt=min(self.min_accepted_dt,dt)
        self.max_accepted_dt=max(self.max_accepted_dt,dt)


class MassRadau5:
    def __init__(self, model, newton: NewtonOptions|None=None, project_half: bool=False):
        self.model=model
        self.newton=newton or NewtonOptions()
        self.mass=sparse.csr_matrix(model.mass)
        self.n=self.mass.shape[0]
        if self.mass.shape!=(self.n,self.n):
            raise ValueError('mass must be square')
        if project_half and self.n%2:
            raise ValueError('project_half requires an even grid')
        self.project_half=project_half

    def project(self, y):
        return 0.5*(y - np.roll(y, self.n//2)) if self.project_half else y

    def stage_residual(self, u, stages, dt):
        # A(Y_i-u) - h sum_j a_ij F(Y_j) = 0; rows follow stage order.
        f=np.array([self.model.rhs(yi) for yi in stages])
        if not np.all(np.isfinite(f)):
            raise NewtonFailure('nonfinite right-hand side')
        return (self.mass @ (stages-u).T).T-dt*(A_R@f)

    def stage_jacobian(self, stages, dt):
        # d R_i / d Y_j = delta_ij A - h a_ij F'(Y_j)
        js=[self.model.jac(yi) for yi in stages]
        blocks=[[ ((self.mass + (-dt*A_R[i,j])*js[j]) if i==j
                   else (-dt*A_R[i,j])*js[j])
                 for j in range(3)] for i in range(3)]
        return sparse.bmat(blocks, format='csc')

    def _scaled_rms(self, residual, u, stages):
        scale=self.newton.atol+self.newton.rtol*np.maximum(np.abs(stages),np.abs(u)[None,:])
        return float(np.sqrt(np.mean((residual/scale)**2)))

    def step(self, u, dt):
        u=np.asarray(u,dtype=float)
        if u.ndim!=1 or u.size!=self.n or not np.all(np.isfinite(u)):
            raise ValueError('invalid initial vector')
        if not np.isfinite(dt) or dt<=0:
            raise ValueError('dt must be positive finite')
        if self.newton.predictor=='euler':
            if not hasattr(self.model, 'velocity'):
                raise ValueError('euler predictor requires model.velocity')
            v=self.model.velocity(u)
            y=u[None,:]+dt*C[:,None]*v[None,:]
            if not np.all(np.isfinite(y)):
                y=np.tile(u,(3,1))
        else:
            y=np.tile(u,(3,1))
        damping_total=0
        nlu=0
        for iteration in range(self.newton.max_iter+1):
            R=self.stage_residual(u,y,dt)
            err=self._scaled_rms(R,u,y)
            if not np.isfinite(err):
                raise NewtonFailure('nonfinite scaled stage residual')
            if err<=1.:
                un=self.project(y[2].copy()) # stiff accuracy: y_{n+1}=Y3
                if not np.all(np.isfinite(un)):
                    raise NewtonFailure('nonfinite endpoint')
                return un, StepData(iteration,nlu,err,damping_total)
            if iteration==self.newton.max_iter:
                raise NewtonFailure(f'Newton iterations exhausted, residual={err:.4g}')
            try:
                J=self.stage_jacobian(y,dt)
                sol=splu(J).solve((-R).reshape(-1))
                nlu+=1
            except Exception as exc:
                raise NewtonFailure(f'sparse factorization/solve failed: {exc}') from exc
            if not np.all(np.isfinite(sol)):
                raise NewtonFailure('nonfinite Newton increment')
            dy=sol.reshape((3,self.n))
            accepted=False
            for nback in range(self.newton.line_search_backtracks+1):
                alpha=2.**(-nback)
                candidate=y+alpha*dy
                if not np.all(np.isfinite(candidate)):
                    continue
                try:
                    rc=self.stage_residual(u,candidate,dt)
                    ec=self._scaled_rms(rc,u,candidate)
                except (ValueError, NewtonFailure, FloatingPointError):
                    continue
                if np.isfinite(ec) and (ec < err or ec <=1.):
                    y=candidate
                    damping_total+=nback
                    accepted=True
                    break
            if not accepted:
                raise NewtonFailure(f'line search failed, residual={err:.4g}')
        raise AssertionError('unreachable')


def integrate(
    solver: MassRadau5,
    u0: np.ndarray,
    t_end: float,
    dt: float,
    *,
    t_start: float=0.,
    save_every: int=10,
    on_save: Callable|None=None,
    on_step: Callable|None=None,
    max_steps: int=1_000_000,
    adaptive: bool=False,
    step_atol: float=1e-8,
    step_rtol: float=1e-6,
    dt_min: float=1e-12,
    dt_max: float=float('inf'),
    fixed_failure_policy: str='abort',
):
    """Advance to t_end. Callback signature: on_save(t,u,stats).

    If callback omitted, returns saved times and fields in memory.
    No interpolation: final timestep is shortened to hit t_end exactly.
    Fixed mode aborts on Newton failure by default; 'halve' is an explicit
    opt-in recovery mode which records reductions and is *not* strict fixed.
    In adaptive mode, accepted solution comes from two half-steps, and
    raw coarse/fine difference is an intentionally conservative error
    indicator, not an order-five embedded pair or error theorem.
    """
    if not np.isfinite(t_end) or t_end<=t_start or not np.isfinite(dt) or dt<=0:
        raise ValueError('invalid integration interval / dt')
    if max_steps<1 or save_every<1 or dt_min<=0 or dt_max<dt_min:
        raise ValueError('invalid integration options')
    if adaptive and (step_atol<=0 or step_rtol<=0):
        raise ValueError('step tolerances must be positive')
    if fixed_failure_policy not in ('abort','halve'):
        raise ValueError('fixed_failure_policy must be abort or halve')
    y=solver.project(np.asarray(u0,dtype=float).copy())
    t=float(t_start)
    stats=RunStats(final_time=t, mode='doubling' if adaptive else 'fixed')
    times=[]
    values=[]

    def emit():
        if on_save:
            on_save(t,y.copy(),stats)
        else:
            times.append(t); values.append(y.copy())

    emit()
    h0=float(dt)
    h=h0
    attempts=0
    # float guard for near-final interval
    while t < t_end - 8*np.finfo(float).eps*max(1.,abs(t_end)):
        if attempts>=max_steps:
            raise RuntimeError(f'max_steps reached at t={t:.17g}')
        attempts+=1
        h=min(h,dt_max,t_end-t)
        if not adaptive:
            # Reject and halve failed Newton steps. Then return toward the
            # user-specified fixed dt (next step), recording changes explicitly.
            try:
                y_next,diag=solver.step(y,h)
            except NewtonFailure as exc:
                stats.rejected_newton+=1
                if on_step: on_step(t,h,None,'newton_reject',float('nan'))
                if fixed_failure_policy == 'abort':
                    raise RuntimeError(f'fixed step refused at t={t:.17g}, h={h:.17g}: {exc}') from exc
                h/=2.
                if h<dt_min:
                    raise RuntimeError(f'Newton failed below dt_min at t={t}: {exc}') from exc
                continue
        else:
            try:
                coarse,d0=solver.step(y,h)
                mid,d1=solver.step(y,h/2)
                fine,d2=solver.step(mid,h/2)
            except NewtonFailure as exc:
                stats.rejected_newton+=1
                if on_step: on_step(t,h,None,'newton_reject',float('nan'))
                h/=2
                if h<dt_min:
                    raise RuntimeError(f'Newton failed below dt_min at t={t}: {exc}') from exc
                continue
            scale=step_atol+step_rtol*np.maximum(np.abs(y),np.abs(fine))
            eta=float(np.sqrt(np.mean(((fine-coarse)/scale)**2)))
            if not np.isfinite(eta):
                raise RuntimeError('nonfinite step-doubling error')
            if eta>1.:
                stats.rejected_error+=1
                if on_step: on_step(t,h,None,'error_reject',eta)
                fac=max(.2,min(.8,.9*eta**(-1/6)))
                h*=fac
                if h<dt_min:
                    raise RuntimeError(f'step-doubling rejects below dt_min at t={t}: err={eta}')
                continue
            y_next=fine
            diag=StepData(d0.iters+d1.iters+d2.iters,d0.nlu+d1.nlu+d2.nlu,
                          max(d0.norm_residual,d1.norm_residual,d2.norm_residual),
                          d0.damping_steps+d1.damping_steps+d2.damping_steps)
        # Step accepted. For sensitivity experiments check h history carefully.
        t_new=t+h
        if not t_new>t:
            raise RuntimeError('step size below machine precision at t')
        t=t_new
        y=y_next
        stats.add_step(diag,h)
        stats.final_time=t
        if on_step: on_step(t,h,diag,'accepted',eta if adaptive else float('nan'))
        if stats.accepted % save_every == 0 or t >= t_end-8*np.finfo(float).eps*max(1.,abs(t_end)):
            emit()
        if adaptive:
            fac=2. if eta<1e-12 else max(.2,min(2.,.9*eta**(-1/6)))
            h=min(dt_max,h*fac)
        else:
            # Fixed baseline step; if a step failed, its accepted half-step
            # is followed by the original fixed step (no silent reattempt).
            h=h0
    if on_save:
        return stats
    return np.asarray(times),np.stack(values),stats
