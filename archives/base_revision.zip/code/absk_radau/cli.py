"""CLI: python -m absk_radau.cli --N 64 --family Z --tau-end 0.002 ..."""
import argparse
import json
import platform
import sys
from pathlib import Path
from .model import PeriodicAbsK, make_initial_data, crossing_time, domain_length
from .radau_mass import MassRadau5, NewtonOptions, integrate
from .io import H5Recorder
import numpy as np
import scipy
import h5py


def parser():
    a=argparse.ArgumentParser(description='Periodic |K|(p,p), Radau IIA5 mass-matrix sparse solver.')
    a.add_argument('--N',type=int,default=64)
    a.add_argument('--p',type=float,default=2.0)
    a.add_argument('--M',type=float,default=4.)
    a.add_argument('--family',type=str,default='Z')
    a.add_argument('--amplitude',type=float,default=1.)
    a.add_argument('--epsilon',type=float,default=0.)
    a.add_argument('--nu',type=float,default=0.)
    a.add_argument('--frame-speed',type=float,default=0.)
    a.add_argument('--regularization',choices=['fourth_order','legacy_second_order'],default='fourth_order')
    a.add_argument('--dt',type=float,default=.005)
    a.add_argument('--tau-end',type=float,default=.002)
    a.add_argument('--save-every',type=int,default=5)
    a.add_argument('--max-steps',type=int,default=100000)
    a.add_argument('--newton-atol',type=float,default=1.e-11)
    a.add_argument('--newton-rtol',type=float,default=1.e-9)
    a.add_argument('--newton-max-iter',type=int,default=12)
    a.add_argument('--predictor',choices=['constant','euler'],default='constant')
    a.add_argument('--fixed-failure-policy',choices=['abort','halve'],default='abort')
    a.add_argument('--project-half',action='store_true')
    a.add_argument('--adaptive-doubling',action='store_true')
    a.add_argument('--step-atol',type=float,default=1.e-8)
    a.add_argument('--step-rtol',type=float,default=1.e-6)
    a.add_argument('--dt-min',type=float,default=1.e-11)
    a.add_argument('--dt-max',type=float,default=float('inf'))
    a.add_argument('--out',type=str,default='results/smoke_Z_p2_M4.h5')
    return a


def main(argv=None):
    args=parser().parse_args(argv)
    if args.N%2 and args.project_half:
        raise SystemExit('project-half requires even N')
    if args.project_half and args.family.upper()!='Z':
        raise SystemExit('project-half is intended for the exact Z family only')
    if args.tau_end<=0:
        raise SystemExit('tau-end must be positive')
    length=domain_length(args.p,args.M)
    tcross=crossing_time(args.p,args.M,args.amplitude)
    t_end=args.tau_end*tcross
    model=PeriodicAbsK(args.N,length,args.p,args.nu,frame_speed=args.frame_speed,regularization=args.regularization)
    u0=make_initial_data(model,args.family,args.amplitude,args.epsilon)
    options=NewtonOptions(args.newton_atol,args.newton_rtol,args.newton_max_iter,predictor=args.predictor)
    solver=MassRadau5(model,options,args.project_half)
    cfg={**vars(args),'period':length,'T_cross':tcross,'t_end':t_end,
         'environment':{'python':sys.version.split()[0], 'numpy':np.__version__,
             'scipy':scipy.__version__,'h5py':h5py.__version__,'platform':platform.platform()}}
    path=Path(args.out)
    recorder=H5Recorder(path,model,cfg,args.family,args.amplitude)
    try:
        stats=integrate(solver,u0,t_end,args.dt,
                        save_every=args.save_every,on_save=recorder,on_step=recorder.on_step,
                        max_steps=args.max_steps,adaptive=args.adaptive_doubling,
                        step_atol=args.step_atol,step_rtol=args.step_rtol,
                        dt_min=args.dt_min,dt_max=args.dt_max,
                        fixed_failure_policy=args.fixed_failure_policy)
        recorder.finish(stats)
    except BaseException as err:
        recorder.fail(err)
        raise
    print(json.dumps({'status':'COMPLETED','file':str(path),'snapshots':recorder.written,
          'stats':vars(stats),'mass_initial':model.mass_integral(u0),
          'lp_initial':model.lp_invariant(u0)},indent=2,default=str))

if __name__=='__main__':
    main()
