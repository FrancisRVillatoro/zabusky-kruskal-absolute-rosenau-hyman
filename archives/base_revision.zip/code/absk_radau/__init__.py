"""Absolute |K|(p,p) numerics: periodic mass-matrix Radau IIA5, Phase 2."""
from .model import PeriodicAbsK, make_initial_data, crossing_time, domain_length
from .radau_mass import A_R, B_R, C, MassRadau5, NewtonOptions, NewtonFailure, integrate
