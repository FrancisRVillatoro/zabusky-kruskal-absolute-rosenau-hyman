"""Mass-matrix discretisation of the periodic absolute |K|(p,p) equation.

    u_t + (|u|^(p-1)u)_x + (|u|^(p-1)u)_xxx + nu*u_xxxx = 0.

Space: historical symmetric Pade/Petrov-Galerkin mass A and skew
operators B and C, on exactly N distinct grid nodes j*L/N.
For nu>0 a separate fourth-order, symmetric nonnegative Q@Q operator
is used instead of the historical second-order D stencil.

SciPy sparse matrices are maintained throughout; no inverse is formed.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu


def periodic_stencil(n: int, offsets: tuple[int, ...], coefficients: tuple[float, ...]):
    """Matrix T with (T u)[j] = sum_s coefficient_s * u[(j+s)%n]."""
    if n < 16:
        raise ValueError("N >= 16 required for non-aliased verification stencils")
    if len(offsets) != len(coefficients):
        raise ValueError("offsets and coefficients lengths differ")
    row = np.arange(n, dtype=np.int64)
    rows = np.concatenate([row for _ in offsets])
    cols = np.concatenate([(row+s) % n for s in offsets])
    vals = np.concatenate([np.full(n, c, dtype=float) for c in coefficients])
    mat = sparse.coo_matrix((vals, (rows, cols)), shape=(n, n))
    return mat.tocsr()


@dataclass
class PeriodicAbsK:
    """Semi-discrete A*u' = F(u). All lengths are physical units."""
    n: int
    L: float
    p: float
    nu: float = 0.0
    frame_speed: float = 0.0
    regularization: str = "fourth_order"

    def __post_init__(self):
        if self.n < 16 or not np.isfinite(self.L) or self.L <= 0:
            raise ValueError("N >= 16 and L > 0 required")
        if not np.isfinite(self.p) or self.p <= 1:
            raise ValueError("p > 1 required")
        if not np.isfinite(self.nu) or self.nu < 0:
            raise ValueError("nu >= 0 required")
        if not np.isfinite(self.frame_speed):
            raise ValueError("frame_speed must be finite")
        if self.regularization not in ("fourth_order", "legacy_second_order"):
            raise ValueError("unknown regularization")
        self.dx = self.L / self.n
        h = self.dx
        off = (-2, -1, 0, 1, 2)
        self.mass = periodic_stencil(self.n, off, tuple(np.array([1,26,66,26,1])/120.0))
        self.B = periodic_stencil(self.n, off, tuple(np.array([-1,-10,0,10,1])/(24*h)))
        self.C = periodic_stencil(self.n, off, tuple(np.array([-1,2,0,-2,1])/(2*h**3)))
        self.K = (self.B + self.C).tocsr()
        self.Q = periodic_stencil(self.n, off, tuple(np.array([-1,16,-30,16,-1])/(12*h*h)))
        self.Q2 = (self.Q @ self.Q).tocsr()
        self.Dlegacy = periodic_stencil(self.n, off, tuple(np.array([1,-4,6,-4,1])/(h**4)))
        if self.regularization == 'fourth_order':
            self.Dmass = (self.mass @ self.Q2).tocsr()
        else:
            self.Dmass = self.Dlegacy
        # F(u) = -K f(u) - nu Dmass u + c0 B u
        self.linear = (-self.nu*self.Dmass + self.frame_speed*self.B).tocsr()
        self._mass_lu = splu(self.mass.tocsc())

    @property
    def x(self):
        return np.arange(self.n, dtype=float) * self.dx

    def flux(self, u):
        v = np.asarray(u, dtype=float)
        return np.abs(v)**(self.p-1)*v

    def rhs(self, u):
        v = np.asarray(u, dtype=float)
        return -(self.K @ self.flux(v)) + self.linear @ v

    def jac(self, u):
        v = np.asarray(u, dtype=float)
        weights = self.p * np.abs(v)**(self.p-1)
        # Column scaling: (K diag(weights))_ij = K_ij weights_j.
        return (-(self.K @ sparse.diags(weights, format='csr')) + self.linear).tocsr()

    def velocity(self, u):
        return self._mass_lu.solve(np.asarray(self.rhs(u)))

    def mass_integral(self, u):
        return float(self.dx*np.sum(u))

    def lp_invariant(self, u):
        return float(self.dx*np.sum(np.abs(u)**(self.p+1))/(self.p+1))

    def lp_balance_rhs(self, u):
        # Valid for this semidiscretisation; for nu=0 it vanishes
        # up to floating point error because A^-1 K is skew.
        v = np.asarray(u)
        return float(self.dx*np.dot(self.flux(v), self.velocity(v)))

    def normalized_halfwave_defect(self, u):
        if self.n % 2:
            raise ValueError('N must be even for half-wave symmetry')
        norm = np.linalg.norm(u)
        return float(np.linalg.norm(u+np.roll(u, self.n//2))/norm) if norm else float('nan')


def make_initial_data(model: PeriodicAbsK, family='Z', amplitude=1., epsilon=0.):
    if not np.isfinite(amplitude) or amplitude <= 0:
        raise ValueError('amplitude must be positive and finite')
    th = 2*np.pi*model.x/model.L
    family = family.upper()
    if family == 'P':
        return (amplitude*0.5)*(1+np.cos(th))
    if family == 'Z':
        return amplitude*np.cos(th)
    if family.startswith('ZE'):
        # Analytic continuous maximum, not max over grid. Write c=cos(th),
        # cos(2th)=2c^2-1; extrema in [-1,1] of 2eps*c^2+c-eps.
        candidates=[-1.,1.]
        if epsilon != 0 and -1. <= -1./(4.*epsilon) <= 1.:
            candidates.append(-1./(4.*epsilon))
        vmax = max(abs(2*epsilon*c*c+c-epsilon) for c in candidates)
        return amplitude*(np.cos(th)+epsilon*np.cos(2*th))/vmax
    raise ValueError(f'unknown initial data family {family}')


def compacton_width(p: float):
    return 2*np.pi*p/(p-1)


def domain_length(p: float, m_widths: float):
    return compacton_width(p)*m_widths


def crossing_time(p: float, m_widths: float, amplitude: float=1.):
    cchar=(p+1)/(2*p)*amplitude**(p-1)
    return domain_length(p,m_widths)/cchar
