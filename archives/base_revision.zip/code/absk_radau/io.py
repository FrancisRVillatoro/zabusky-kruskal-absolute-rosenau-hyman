"""Stream results to a single HDF5 file (no many-small-files campaign)."""
from __future__ import annotations
from dataclasses import asdict
import json
from pathlib import Path
import numpy as np
import h5py
from .modal_diagnostics import one_harmonic_diagnostics


class H5Recorder:
    def __init__(self, filename, model, config: dict, family, amplitude, *, gzip=4):
        p=Path(filename)
        p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists():
            raise FileExistsError(f'output already exists: {p} (never overwrite silently)')
        self.path=p
        self.h5=h5py.File(p,'x')
        self.h5.attrs['status']='INCOMPLETE'
        self.h5.attrs['format_version']='absk_radau_v0.2'
        self.h5.attrs['config_json']=json.dumps(config,sort_keys=True)
        self.h5.attrs['period']=model.L
        self.h5.attrs['n_cells']=model.n
        self.h5.attrs['p']=model.p
        self.h5.attrs['nu']=model.nu
        self.h5.attrs['family']=family
        self.h5.attrs['amplitude']=amplitude
        self.h5.attrs['regularization']=model.regularization
        self.h5.create_dataset('x',data=model.x)
        self.t=self.h5.create_dataset('t',shape=(0,),maxshape=(None,),chunks=(128,),dtype='f8')
        self.u=self.h5.create_dataset('u',shape=(0,model.n),maxshape=(None,model.n),
                                     chunks=(1,model.n),dtype='f8',compression='gzip',compression_opts=gzip)
        self.data=self.h5.create_dataset('diagnostics',shape=(0,10),maxshape=(None,10),
                                        chunks=(128,10),dtype='f8')
        self.data.attrs['columns']=json.dumps(['time','mass','lp_invariant','lp_balance_rhs',
                  'halfwave_defect','D_cont','D_grid','Phi1','r','H_high'])
        self.model=model
        self.family=family.upper()
        self.amplitude=amplitude
        self.written=0
        self.step_rows=[]

    def __call__(self,t,y,stats):
        i=self.written
        self.t.resize((i+1,))
        self.u.resize((i+1,self.model.n))
        self.data.resize((i+1,10))
        self.t[i]=t;self.u[i,:]=y
        D=DG=phi=r=H=float('nan')
        if self.family=='Z':
            md=one_harmonic_diagnostics(y,self.model.L,0.,self.amplitude,p=self.model.p)
            D,DG,phi,r,H=md.D_cont,md.D_grid,md.Phi1,md.r,md.H_high
        elif self.family=='P':
            md=one_harmonic_diagnostics(y,self.model.L,self.amplitude/2,self.amplitude/2,p=self.model.p)
            D,DG,phi,r,H=md.D_cont,md.D_grid,md.Phi1,md.r,md.H_high
        half=self.model.normalized_halfwave_defect(y) if self.model.n%2==0 else float('nan')
        self.data[i,:]=[t,self.model.mass_integral(y),self.model.lp_invariant(y),
                        self.model.lp_balance_rhs(y),half,D,DG,phi,r,H]
        self.written+=1
        # flush regularly so incomplete runs remain identifiable/readable
        if self.written%32==0: self.h5.flush()

    def on_step(self,t,h,diag,outcome,est_error):
        # Event codes: accepted=1, Newton reject=-1, error reject=-2.
        code={'accepted':1,'newton_reject':-1,'error_reject':-2}[outcome]
        self.step_rows.append((float(t),float(h),float(diag.iters) if diag else float('nan'),
                               float(diag.nlu) if diag else float('nan'),
                               float(diag.norm_residual) if diag else float('nan'),
                               float(diag.damping_steps) if diag else float('nan'),
                               float(est_error),float(code)))

    def _write_step_log(self):
        if self.step_rows and 'step_log' not in self.h5:
            d=self.h5.create_dataset('step_log',data=np.asarray(self.step_rows,dtype=float),
                                     compression='gzip',compression_opts=4)
            d.attrs['columns']=json.dumps(['time_after_or_at_rejection','dt_attempt',
                 'newton_iters','sparse_lu','scaled_residual','line_search_halvings',
                 'doubling_error','event_code'])

    def finish(self,stats):
        self._write_step_log()
        self.h5.attrs['run_stats_json']=json.dumps(asdict(stats),sort_keys=True)
        self.h5.attrs['status']='COMPLETED'
        self.h5.flush()
        self.h5.close()

    def fail(self,reason):
        if self.h5.id.valid:
            self._write_step_log()
            self.h5.attrs['failure_reason']=str(reason)
            self.h5.flush()
            self.h5.close()
