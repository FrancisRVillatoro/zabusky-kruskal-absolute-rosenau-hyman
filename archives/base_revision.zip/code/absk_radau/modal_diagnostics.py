"""Analytical Fourier diagnostics for single-harmonic recurrence in |K|(p,p).

Phase 1 scientific module. It does NOT integrate the PDE.
Only a genuinely periodic grid without a repeated end point is accepted.
Convention: uhat[n] = FFT(u)[n]/N, k[n] = 2*pi*n/L.
Copyright (c) 2026. Project draft, no warranties.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class Recurrence:
    D_cont: float
    D_osc: float
    D_grid: float
    xi_opt: float
    mean_u: float
    mean_error: float
    r: float
    H_high: float
    Qosc: float
    Phi1: float
    E_positive: np.ndarray  # E_n=|uhat_n|^2 for n>=0
    e_positive: np.ndarray  # 2E_n/(b^2/2) for n>=1, e[0] = 0
    Ahalf: float
    Amass: float
    I_p1: float | None


def data_profile(x: np.ndarray, L: float, family: str,
                 A: float = 1.0, epsilon: float = 0.0) -> np.ndarray:
    """P, Z, ZE families; ZE normalized by continuous max (unlike old grid max)."""
    theta = 2*np.pi*np.asarray(x, float)/L
    fam = family.upper()
    if fam == 'P':
        return A*(1 + np.cos(theta))/2
    if fam == 'Z':
        return A*np.cos(theta)
    if fam.startswith('ZE'):
        # For |epsilon|<1/4 the largest absolute value occurs at theta=0 or pi.
        # More generally find the exact maximum of |cos(theta)+epsilon cos(2theta)|
        # by checking endpoints and all interior critical points.
        candidates = [-1.0, 1.0]
        if epsilon != 0:
            v = -1.0/(4.0*epsilon)
            if -1 <= v <= 1:
                candidates.append(v)
        max_abs = max(abs(2*epsilon*c*c + c - epsilon) for c in candidates)
        raw = np.cos(theta) + epsilon*np.cos(2*theta)
        return A*raw/max_abs
    raise ValueError(f'unknown family: {family}')


def one_harmonic_diagnostics(u: np.ndarray, L: float, a: float, b: float,
                             p: float | None = None) -> Recurrence:
    """Compute exact continuous-shift recurrence to a+b*cos(2*pi*x/L).

    u is real, N equispaced values x_j=j*L/N, j=0..N-1.
    Riemann-sum/DFT identities are exact for the corresponding discrete L2
    inner product; continuum formulas apply to L2 functions as stated.
    """
    u = np.asarray(u, dtype=float)
    if u.ndim != 1 or len(u) < 8 or not np.all(np.isfinite(u)):
        raise ValueError('u must be a finite 1D periodic field with N>=8')
    if not np.isfinite(L) or L <= 0 or not np.isfinite(a) or not np.isfinite(b) or b == 0:
        raise ValueError('invalid L, a, or b')
    N = len(u)
    M0 = a*a + b*b/2
    weight = (b*b/2)/M0
    hat = np.fft.rfft(u)/N
    E = np.abs(hat)**2
    # rfft contains a Nyquist coefficient only once for N even.
    mult = np.full(len(E), 2., dtype=float)
    mult[0] = 1.
    if N % 2 == 0:
        mult[-1] = 1.
    osc = float(np.sum(mult[1:]*E[1:]))
    high = float(max(0.0, osc - 2*E[1]))
    r = float(2*np.sqrt(E[1])/abs(b))
    H_high = high/(b*b/2)
    Qosc = osc/(b*b/2)
    Phi1 = float(2*E[1]/osc) if osc > 0 else float('nan')
    mu = float(hat[0].real)
    D2 = (mu-a)**2/M0 + weight*((r-1)**2 + H_high)
    D_cont = float(np.sqrt(max(0.0, D2)))
    D_osc = float(np.sqrt(max(0.0, (mu-a)**2/(b*b/2)+(r-1)**2+H_high)))

    # Optimal continuous spatial translation of the sinusoidal target.
    # For b<0 the target first Fourier coefficient has the extra phase pi.
    xi = (-(np.angle(hat[1]*np.sign(b))))*L/(2*np.pi)
    xi = float(np.mod(xi, L))
    k = np.arange(N)
    shifts = (2*np.pi*k/N)
    alpha = np.angle(hat[1]*np.sign(b))
    delta = np.angle(np.exp(1j*(alpha + shifts)))
    misalignment = float(np.min(np.abs(delta)))
    bias2 = (2*abs(b)*np.abs(hat[1])/M0)*(1-np.cos(misalignment))
    D_grid = float(np.sqrt(max(0, D2+bias2)))

    coeff = np.zeros(len(E), dtype=float)
    coeff[1:] = mult[1:]*E[1:]/(b*b/2)
    # Half-wave diagnostic only defined on even grids.
    if N % 2 == 0:
        ah = float(np.linalg.norm(u+np.roll(u, N//2))/np.linalg.norm(u)) if np.linalg.norm(u) else float('nan')
    else:
        ah = float('nan')
    amass = float(abs(np.sum(u))/np.sum(abs(u))) if np.any(u) else float('nan')
    I = float(L*np.mean(np.abs(u)**(p+1))/(p+1)) if p is not None else None
    return Recurrence(D_cont,D_osc,D_grid,xi,mu,mu-a,r,H_high,Qosc,Phi1,E,coeff,ah,amass,I)


def modal_balance_rhs(u: np.ndarray, L: float, p: float, nu: float = 0.) -> np.ndarray:
    """Formal mode-wise d/dt |uhat_n|^2 from the PDE (n>=0)."""
    u = np.asarray(u, dtype=float)
    N = len(u)
    ku = 2*np.pi*np.fft.rfftfreq(N, d=L/N)
    uh = np.fft.rfft(u)/N
    fh = np.fft.rfft(np.abs(u)**(p-1)*u)/N
    return 2*ku*(1-ku*ku)*np.imag(np.conj(uh)*fh) - 2*nu*ku**4*np.abs(uh)**2
