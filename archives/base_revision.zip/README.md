# Numerical supplement

This supplement contains the mass-matrix Radau solver, the production manifests and the exported measurements for the periodic absolute Rosenau–Hyman equation. The source tree retains the phase numbering used in the campaign. All paths below are relative to this supplement unless a command changes the working directory.

## Independent experiments in the revised article

| Question | Numerical data, code and figures |
|---|---|
| Does the sequence persist with an invariant-preserving time integrator? | controls/README.md, method_returns.csv, shared_time_profiles.csv, avf_run_status.csv and long_results/ in that directory |
| Where is the aligned residual, how do zero crossings compare across grids, and how large are the observed spreads? | audit/README.txt and audit/results/, especially zero_refinement.csv, profile_provenance.csv and scalar_envelopes.csv |
| Do the near-null seventh harmonic and a short list of odd modes explain recurrence? | mechanism/README.md, galerkin_events.csv, transfer_at_returns.csv and relative_phase.pdf in that directory |
| What changes with domain length, flux, projection, initial perturbation and positive-data observation time? | experiments/README.md, results/local_minima.csv, results/field_comparisons.csv and results/positive_troughs.csv in that directory |
| Do positive-pedestal solitary waves explain the measured widths? | audit/pedestal_widths.py and its per-peak output in audit/results/ |

Archived results and new fixed-step integrations are identified separately. The provided inputs reproduce the figures without a cluster. The optional Picasso script reads the complete original HDF5 trajectories. Full local attempts, including unsuccessful fixed-step AVF solves, are in the numerical tables.

## Read the measurements

| Question | Primary exported file or directory |
|---|---|
| How did the short verification cases behave under refinement? | `exports/short_returns/series_25.csv` and `exports/verification/fase3/results/` |
| What happened at the successive returns with zero dissipation? | `exports/returns/retornos.csv`, `modes_N*.csv`, `field_budget.csv` and `profile_return*_N1800.csv` in the same directory |
| What changed when the last segment was integrated with a smaller step? | `exports/fourth_return/retornos4b.csv` and `field_budget4b.csv` in the same directory |
| How were peaks, widths and backgrounds measured? | `exports/pulse_morphology/fase5/results/analysis/` contains snapshots, individual peaks, threshold sweeps, fit coefficients, example profiles and field comparisons |
| How did the return depend on physical dissipation? | `exports/regularization/fase6/results/analysis/` contains `return_catalog.csv`, `refinement.csv`, `zero_nu_comparison.csv`, control comparisons and weak residuals |
| What is the amplitude-scaling verification? | `exports/scaling/fase7/results/local/` and the executable tests in `code/fase7/` |

For the central unregularized series use the first three sampled minima on the 1800-node grid in `retornos.csv`. The fourth is the 1800-node, divisor-four row in `retornos4b.csv`, from a restart at the normalized time 3.25. The original final segment at the base step stopped early. The exports preserve that failure and the distinct checkpoint histories. The space–time CSV contains actual positions and snapshot times. Its sampling interval varies over the run.

The full production HDF5 trajectories and restart checkpoints were written on Picasso. They are outside this supplement. All-node profiles are available for the first three unregularized returns at 1800 nodes. The distributed fourth-return and regularization results contain modal and field-comparison tables. Two HDF5 files in `exports/solver_smoke/` are short solver test fixtures. Additional full fields are supplied in the independent controls below.

## Verify the article data without integrations

From this directory run:

```bash
python3 check_exports.py
```

This standard-library program verifies the source and data checksums, recomputes the return distances directly from the three exported all-node aligned profiles, checks the modal identity at all four events, and evaluates the background floor and regularization comparisons. `FILE_PROVENANCE.tsv` maps each original file to its member path, SHA-256 and originating archive. `SOURCE_ARCHIVES.tsv` records the hashes of the 21 parent archives. The source and result files listed in this inventory are byte-for-byte copies. The directory names `returns` and `fourth_return` distinguish the different time-step histories.

## Rebuild figures from the original campaigns

The plotting scripts and their input tables are in the plots directory. After installing the dependencies from requirements.txt, run both commands from the supplement root:

    python3 plots/reproduce/plot_comparisons.py
    python3 plots/reproduce/make_figures.py

They write vector PDFs to plots/figures, with a raster field layer in the space–time panel. The scripts use only the supplied numerical exports. For the plot data, plots/data/figure_sources.md lists the original filenames and checksums. The revision also contains figures from the controls below.

## Run the solver checks

The production verification ran on Linux with Python 3.14.3, NumPy 2.3.5, SciPy 1.17.0 and h5py 3.15.1. Matplotlib is used by the plotting routines. From the supplement root:

```bash
python3 -m pip install -r requirements.txt
cd code
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export MPLBACKEND=Agg
python3 -m unittest discover -s tests -v
python3 -m unittest discover -s fase3/tests -v
python3 -m fase3.verification --out fase3/results/verification_replay.json
python3 -m unittest fase7.tests.test_scaling -v
python3 -m fase7.verify --outdir fase7/results/scaling_replay
```

The saved Picasso reference is `exports/verification/fase3/results/verification_picasso_3697921.json`. It includes the smooth residuals, time-refinement errors and isolated travelling compacton tests. A separate packaging check with Python 3.12.14, NumPy 2.3.5 and SciPy 1.17.0 passed 14 solver unit tests and all seven scaling tests. All eight short amplitude comparisons were also recomputed. Their maximum normalized field difference was 1.78 × 10⁻¹⁵. The HDF5 unit test was part of the original production verification; the packaging check had no h5py installation.

## Replay production on a compute node

Use a fresh copy of `code/` as the working directory. The sequences below use module entry points so the project is independent of local scheduler names. Indices are one-based and refer to rows of the corresponding CSV. Simulation drivers create their output directories. Independent indices may run as array tasks. Continue from completed audited outputs at dependencies. Changes in sparse linear algebra or hardware can change the point of a Newton failure.

1. **Short verification runs.** Run each of indices 1–26, substituting the row number for `i`:

   ```bash
   python3 -m fase3.run_case --manifest fase3/campaign_main.csv --index "$i" --output fase3/results/main
   ```

   For a run that stops at a fixed-step Newton failure, its partial HDF5 file is the input to `python3 -m fase3.rescate.repair --index "$i"`. In the recorded experiment the recovery indices were 10, 13, 14, 15, 16, 17, 20, 21 and 22. Index 22 remained unresolved. Assemble the completed trajectories once with `python3 -m fase3.rescate.merge` and export their diagnostics with `python3 -m fase3.exportar_retornos25`. Successful, failed and resumed runs retain separate paths.

2. **Unregularized returns.** Run each of indices 1–3 (450, 900, 1800 nodes) for both modes. They consume the corresponding completed stage-3 trajectories:

   ```bash
   python3 -m fase4.continue_radau --case-index "$i" --mode zoom1
   python3 -m fase4.continue_radau --case-index "$i" --mode long
   ```

   The original 1800-node base-step run completed its second continuation to 3.25 and subsequently stopped before return four. Use `python3 -m fase4.analyze` for the original segments. For the independent fourth-return restarts run `python3 -m fase4b.run_block --case-index "$i" --dt-divisor "$d"` for each combination of `i=2,3` and `d=2,4`, then `python3 -m fase4b.analyze`. Each restart reads the corresponding completed state at 3.25.

3. **Positive pulses.** The four-width control reads stage-3 fields. For the eight-width case run indices 1–5 of `python3 -m fase3.run_case --manifest fase5/campaign_P_p2_M8.csv --index "$i" --output fase5/results/m8`. Then run `python3 -m fase5.analysis` to classify the fields, fit templates and compare grids.

4. **Fixed physical regularization.** Run indices 1–22 of `python3 -m fase6.run --manifest fase6/campaign_short.csv --index "$i" --output fase6/results/short`. Continue with `python3 -m fase6.run --manifest fase6/campaign_long.csv --index "$i" --output fase6/results/long` in three successive groups, indices 1–6, 7–12 and 13–18. A trajectory in each later group needs its own completed predecessor. Run `python3 -m fase6.analyze` with the stage-3, stage-4 and stage-4B outputs present for the unregularized comparison. The six design pilots can be replayed separately with `campaign_pilot.csv` and `--output fase6/results/pilot`.

The small audit files distinguish convergence of a nonlinear stage solve, execution through an endpoint, and agreement between discretizations. A completed job or a satisfied modal identity alone establishes neither a physical convergence rate nor uniqueness of the continuum evolution.
