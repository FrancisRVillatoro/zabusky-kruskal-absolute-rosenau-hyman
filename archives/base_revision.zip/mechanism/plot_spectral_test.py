"""Regenerate the harmonic truncation and instantaneous-transfer figure."""
import argparse
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def read_rows(path):
    with path.open() as file:
        return list(csv.DictReader(file))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exports',type=Path,required=True)
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    args.out.parent.mkdir(parents=True,exist_ok=True)
    catalog = read_rows(args.results/'galerkin_events.csv')
    ref = [v for v in read_rows(args.exports/'returns/retornos.csv') if v['N']=='1800' and v['status']=='LOCAL_MIN']
    ref += [v for v in read_rows(args.exports/'fourth_return/retornos4b.csv') if v['N']=='1800' and v['dt_divisor']=='4']
    ref_depth = [float(v['D']) for v in ref]
    full = read_rows(args.exports/'returns/modes_N1800.csv')
    time = np.array([float(v['tau']) for v in full])
    e5 = np.array([float(v['e5']) for v in full])
    plt.rcParams.update({'font.size':9,'axes.titlesize':10,'axes.spines.right':False,
                         'axes.spines.top':False,'pdf.fonttype':42})
    fig,(a,b)=plt.subplots(1,2,figsize=(7.1,2.85),layout='constrained')
    for cutoff,col,marker in [(7,'#a45326','s'),(9,'#80599c','v'),(15,'#408477','^'),(21,'#245c88','o')]:
        case=[v for v in catalog if v['p']=='2.25' and v['M']=='4' and int(v['cutoff'])==cutoff and int(v['quad'])==512]
        a.plot(range(1,5),[float(v['D_min']) for v in case],ls='--',marker=marker,
               color=col,lw=1,ms=3.7,label=fr'$n_{{\max}}={cutoff}$')
    a.plot(range(1,5),ref_depth,color='#182328',marker='D',lw=1.6,ms=4,label='Padé')
    a.set(xticks=range(1,5),xlabel='Return index',ylabel=r'$D$ at local minimum',ylim=(0,.42))
    a.set_title('(a)   Harmonic truncation',loc='left')
    a.legend(loc='upper left',fontsize=7,frameon=False,ncols=2,columnspacing=.9)
    for idx,(v,col,ls) in enumerate(zip(ref[:3],['#245c88','#a45326','#408477'],['-','--','-.'])):
        tau=float(v['tau'])
        near=np.abs(time-tau)<=.016
        vals=e5[near]/e5[np.argmin(abs(time-tau))]
        b.plot(time[near]-tau,vals,color=col,ls=ls,lw=1.6,label=f'$j={idx+1}$')
    b.axvline(0,color='#696c70',lw=.75,alpha=.7)
    b.scatter(0,1,color='#182328',s=13,zorder=5)
    b.set(xlabel=r'$\tau-\tau_j$',ylabel=r'$e_5(\tau)/e_5(\tau_j)$',yscale='log',
          xlim=(-.015,.015),xticks=[-.015,0,.015])
    b.set_title('(b)   Fifth harmonic near each return',loc='left')
    b.legend(loc='upper right',frameon=False,fontsize=8)
    for ax in (a,b):
        ax.grid(axis='y',alpha=.2)
    fig.savefig(args.out, bbox_inches='tight',pad_inches=.04)
    plt.close(fig)

if __name__=='__main__':
    main()
