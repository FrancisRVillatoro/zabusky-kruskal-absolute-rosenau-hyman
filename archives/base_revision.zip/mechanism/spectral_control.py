"""Fourier--Galerkin truncations and low-mode diagnostics of the signed cosine.

Run with: python spectral_control.py --exports PATH_TO_SUPPLEMENT/exports --out PATH
This reduced model uses exact spatial derivative multipliers and a trapezoidal
approximation to the continuous projection of |u|^(p-1)u on the retained modes.
For noninteger p no finite oversampling rule is exactly alias-free. The principal
case is therefore rerun at twice the quadrature size and tighter ODE tolerances.
"""
import argparse
import csv
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar
from scipy.signal import find_peaks

ODDS = (3, 5, 7, 9, 15, 21)
WINDOWS = ((.94, 1.10), (1.80, 2.20), (2.80, 3.20), (3.80, 4.20))


def read_csv(path):
    with path.open() as fp:
        return list(csv.DictReader(fp))


def write_csv(path, rows):
    with path.open('w', newline='') as fp:
        out = csv.DictWriter(fp, list(rows[0]))
        out.writeheader()
        out.writerows(rows)


def diagnostics(c):
    powers = 4.0 * abs(c)**2
    r = 2.0 * abs(c[0])
    H = np.sum(powers[1:], axis=0)
    D = np.sqrt((r - 1.0)**2 + H)
    return D, r, H, powers


def proportion_negative(t, y):
    # Time measure of y<0 under piecewise-linear interpolation.
    a, b = y[:-1], y[1:]
    fractions = ((a < 0) & (b < 0)).astype(float)
    cross = (a < 0) != (b < 0)
    fractions[cross] = np.where(a[cross]<0, -a[cross], -b[cross]) / abs(a[cross]-b[cross])
    return np.dot(np.diff(t), fractions) / (t[-1] - t[0])


def audit_export(exports, output):
    rows = read_csv(exports / 'returns' / 'modes_N1800.csv')
    t = np.array([float(r['tau']) for r in rows])
    assert np.all(np.diff(t)>0)
    phi = np.unwrap([float(r['fundamental_phase']) for r in rows])
    assert np.max(np.abs(np.diff(phi))) < np.pi/2
    idx = np.argmin(abs(t-1.0090625))
    travel = -(phi[idx]-phi[0])/(2*np.pi)
    period = 4*2*np.pi*2.25/(2.25-1)
    T = period*2*2.25/(2.25+1)
    powers = {n: np.array([float(r[f'e{n}']) for r in rows]) for n in [3,5,7,9,11]}
    observables=[dict(observable=f'time_mean_e{n}',value=np.trapezoid(s,t)/(t[-1]-t[0]),
                      tau_start=t[0],tau_end=t[-1]) for n,s in powers.items()]
    for name,val,upper in [('time_share_e7_below_e9',proportion_negative(t,powers[7]-powers[9]),t[-1]),
                           ('sample_share_e7_below_e9',np.mean(powers[7]<powers[9]),t[-1]),
                           ('travel_fundamental_domain_lengths',travel,t[idx]),
                           ('mean_fundamental_physical_speed',travel*period/(t[idx]*T),t[idx]),
                           ('maximum_unwrapped_increment_abs',np.max(abs(np.diff(phi))),t[-1])]:
        observables.append(dict(observable=name,value=val,tau_start=t[0],tau_end=upper))
    write_csv(output/'archive_modal_statistics.csv', observables)
    return t,np.array([float(r['D']) for r in rows])


def solve_case(p, M, cutoff, nquad, rtol, tau_stop, exports, reference):
    n = np.arange(1,cutoff+1,2)
    k = n * ((p-1)/(M*p))
    L = 2*np.pi*M*p/(p-1)
    T = L * 2*p/(p+1)
    multiplier = -1j*T*k*(1-k*k)
    c0 = np.zeros(len(n),complex)
    c0[0] = .5
    def flux(t,c):
        v = np.zeros(nquad//2+1, complex)
        v[n] = c
        u = np.fft.irfft(v,n=nquad,norm='forward')
        return multiplier * np.fft.rfft(abs(u)**(p-1)*u,norm='forward')[n]
    sol = solve_ivp(flux,(0,tau_stop),c0,method='DOP853',rtol=rtol,atol=rtol*0.005,
                    dense_output=True)
    if not sol.success: raise RuntimeError(sol.message)
    common = dict(p=p,M=M,cutoff=cutoff,retained=len(n),quad=nquad,rtol=rtol,evals=sol.nfev)
    sampled = np.arange(0, int(round(tau_stop*3200))+1)/3200
    D = diagnostics(sol.sol(sampled))[0]
    Dfun = lambda tau: diagnostics(sol.sol(tau))[0]
    catalog = []
    for j,(ta,tb) in enumerate(WINDOWS,1):
        if tb>tau_stop: continue
        inwin = np.flatnonzero((sampled>=ta)&(sampled<=tb))
        local = inwin[find_peaks(-D[inwin])[0]]
        line = dict(**common,j=j,n_min=len(local),tau_min='',D_min='',r='',H='',dominant_odd='',
                    e5_over_H='',e7_over_H='',e9_over_H='', L2_vs_Pade_same_time='',
                    D_at_Pade_return='', Pade_D='')
        if len(local):
            ix=local[np.argmin(D[local])]
            refined = minimize_scalar(Dfun,method='bounded',bounds=(sampled[ix-1],sampled[ix+1]),
                                      options={'xatol':1e-12})
            tau = refined.x
            d,r,H,power=diagnostics(sol.sol(tau))
            line.update(tau_min=tau,D_min=d,r=r,H=H,dominant_odd=int(n[np.argmax(power[1:])+1]))
            for m in (5,7,9):
                line[f'e{m}_over_H']=power[np.nonzero(n==m)[0][0]]/H if m in n else 0.
        if p==2.25 and M==4 and j<=3:
            rows=read_csv(exports/'returns'/f'profile_return{j}_N1800.csv')
            tau_p=float(rows[0]['tau'])
            c = sol.sol(tau_p)
            v = np.zeros(1800//2+1,complex)
            v[n]=c
            u=np.fft.irfft(v,n=1800,norm='forward')
            ref=np.array([float(row['u']) for row in rows])
            shift=np.array([float(row['u0_opt_shift']) for row in rows])
            line['L2_vs_Pade_same_time']=np.sqrt(2*np.mean((u-ref)**2))
            line['D_at_Pade_return']=diagnostics(c)[0]
            line['Pade_D']=np.sqrt(2*np.mean((ref-shift)**2))
        catalog.append(line)
    # This second catalog does not assume returns at multiples of the M=4
    # crossing time. A fixed absolute prominence selects visible dips in D.
    # Event depths are retained without a deep-return threshold.
    dips, properties = find_peaks(-D,prominence=.03)
    outside = []
    for ix,prominence in zip(dips,properties['prominences']):
        if sampled[ix] < .2:
            continue
        fit = minimize_scalar(Dfun,method='bounded',bounds=(sampled[ix-1],sampled[ix+1]),
                              options={'xatol':1e-12})
        c = sol.sol(fit.x)
        depth,amp,tail,power = diagnostics(c)
        fields = dict(**common,tau=fit.x,D=depth,r=amp,H=tail,prominence=prominence,
                      dominant_nonfundamental=int(n[1+np.argmax(power[1:])]))
        for m in (3,5,7,9,11):
            fields[f'e{m}_over_H'] = power[(m-1)//2]/tail if m<=cutoff else 0.
        outside.append(fields)
    t,d_ref = reference
    compare=np.zeros(0)
    if p==2.25 and M==4:
        mask=t<=tau_stop
        compare=diagnostics(sol.sol(t[mask]))[0]-d_ref[mask]
    grid=np.linspace(0,tau_stop,81)
    cs=sol.sol(grid)
    v=np.zeros((nquad//2+1,len(grid)),complex)
    v[n,:]=cs
    us=np.fft.irfft(v,n=nquad,axis=0,norm='forward')
    invariant=np.mean(abs(us)**(p+1),axis=0)
    summary=dict(**common,tau_stop=tau_stop,max_rel_I_drift=np.max(abs(invariant/invariant[0]-1)),
                 max_abs_D_vs_Pade=np.max(abs(compare)) if len(compare) else '')
    return catalog, summary, outside


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exports',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    curve=audit_export(args.exports,args.out)
    cases=[(2.25,4,q) for q in ODDS]
    cases += [(p,M,q) for p,M in [(2.25,3),(2.25,5),(3,4)] for q in (7,15,21)]
    specs=[(p,M,q,512,1e-9) for p,M,q in cases]
    specs += [(2.25,4,q,1024,1e-11) for q in (7,21)]
    catalog=[]
    summary=[]
    global_events=[]
    for p,M,q,nquad,rtol in specs:
        rows,stats,other=solve_case(p,M,q,nquad,rtol,4.25,args.exports,curve)
        catalog.extend(rows)
        summary.append(stats)
        global_events.extend(other)
        write_csv(args.out/'galerkin_events.csv',catalog)
        write_csv(args.out/'galerkin_run_checks.csv',summary)
        if global_events:
            write_csv(args.out/'galerkin_free_events.csv',global_events)
        print(p,M,q,nquad,[round(row['D_min'],4) if row['n_min'] else None for row in rows],flush=True)

if __name__=='__main__':
    main()
