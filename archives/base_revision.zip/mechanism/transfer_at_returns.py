"""Compute event-local Fourier transfer in the full all-node archived profiles.

The formula for de_n/dtau involves the complete nonlinear flux at each point.
A separately reported centered secant uses the saved adjacent modal snapshots.
The n in this script is a Fourier harmonic, not the number of grid nodes.
"""
import argparse
import csv
from pathlib import Path

import numpy as np


def read_rows(path):
    with path.open() as file:
        return list(csv.DictReader(file))


def save_rows(path, rows):
    with path.open('w', newline='') as file:
        writer = csv.DictWriter(file, list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def pade_multiplier(k, h):
    theta = k*h
    mass = (66 + 52*np.cos(theta) + 2*np.cos(2*theta))/120
    b = np.sin(theta)*(np.cos(theta)+5)/(6*h)
    c = -4*np.sin(theta)*np.sin(theta/2)**2/h**3
    return (b+c)/mass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exports', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    path = args.exports / 'returns'
    args.out.mkdir(parents=True, exist_ok=True)
    archive = read_rows(path/'modes_N1800.csv')
    time = np.array([float(row['tau']) for row in archive])
    p = 2.25
    L = 2*np.pi * 4*p/(p-1)
    crossing_time = 2*p*L/(p+1)
    output = []
    for j in (1,2,3):
        rows = read_rows(path/f'profile_return{j}_N1800.csv')
        tau = float(rows[0]['tau'])
        idx = np.flatnonzero(np.isclose(time,tau,atol=1e-13,rtol=0)).item()
        u = np.array([float(row['u']) for row in rows])
        U = np.fft.rfft(u,norm='forward')
        F = np.fft.rfft(np.abs(u)**(p-1)*u,norm='forward')
        for n in (1,3,5,7,9,11):
            k = 2*np.pi*n/L
            symbol = k*(1-k*k)
            symbol_h = pade_multiplier(k,L/u.size)
            flux_product = np.conj(U[n])*F[n]
            de = 8*crossing_time*np.imag(flux_product)
            dtau = time[idx+1]-time[idx-1]
            secant = (float(archive[idx+1][f'e{n}'])-float(archive[idx-1][f'e{n}']))/dtau
            output.append(dict(j=j, tau=tau, n=n, multiplier=symbol, discrete_multiplier=symbol_h,
                e=4*abs(U[n])**2, abs_flux_coeff=abs(F[n]), flux_phase_relative_to_u=np.angle(flux_product),
                de_dtau_cont_symbol=de*symbol, de_dtau_pade_symbol=de*symbol_h,
                de_dtau_centered_secant=secant, secant_left_tau=time[idx-1], secant_right_tau=time[idx+1]))
    save_rows(args.out/'transfer_at_returns.csv', output)

if __name__=='__main__':
    main()
