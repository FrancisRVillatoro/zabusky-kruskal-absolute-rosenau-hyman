# Harmonic truncation and transfer at recurrence

These scripts test two questions for the signed cosine. How many harmonics are needed to reproduce the four depths of the primary case? Does the dominant residual harmonic gain power at the instant of return?

Run from this directory with Python, NumPy 2.x, SciPy and Matplotlib. Point EXP at the supplement's unpacked exports directory.

```sh
EXP=../exports
python spectral_control.py --exports "$EXP" --out .
python transfer_at_returns.py --exports "$EXP" --out .
python plot_spectral_test.py --exports "$EXP" --results . --out spectral_test.pdf
```

The reduced ODE uses odd positive Fourier coefficients and their complex conjugates, the exact multipliers for spatial derivatives, trapezoidal flux projection, and DOP853 dense output. At noninteger exponent finite quadrature approximates the projection. The options for a run are repeated on its CSV rows. The second integration at harmonic cutoffs 7 and 21 jointly tightens the tolerances and doubles the quadrature size. The high-cutoff ODEs remain finite-dimensional comparisons. A cutoff of 7 retains four positive harmonics.

- `galerkin_events.csv` reports the deepest interior local minimum in each of four specified windows. Empty depths indicate the absence of an interior minimum. Field discrepancies use the complete archived 1,800-node profiles at the exact Padé snapshot time, in the original laboratory frame, normalized by the initial cosine RMS.
- `galerkin_free_events.csv` lists minima from a search without the four windows, using minimum prominence 0.03, a sampling interval of 1/3200 crossings and a dense-output minimum refinement. The first 0.2 crossings are excluded. Additional domain-length and exponent cases are axis controls for the truncation.
- `galerkin_run_checks.csv` gives solver evaluations, sampled invariant drift on 81 uniformly spaced times, and the maximum difference in the scalar distance evaluated at all reference snapshot times through 3.25 for the matching case.
- `archive_modal_statistics.csv` gives time-weighted normalized modal powers from the irregularly sampled Padé archive, the occupation time of a strict inequality using piecewise-linear interpolation, and the unwrapped fundamental displacement.
- `transfer_at_returns.csv` gives the flux coefficients, relative phases and instantaneous normalized power slopes at the first three fine-grid Padé returns. These are computed from the complete physical-space snapshots with both continuum and discrete spatial multipliers and checked by centered secants on adjacent modal snapshots.
- `spectral_test.pdf` compares the four return depths and the evolution of fifth-mode power close to the first three measured minima.

For a phase portrait of the full Padé data, run `python relative_phase.py --exports "$EXP" --out .`. The script reconstructs the complex translation-invariant coordinates from the exported relative phases and square roots of the modal powers. Each interval from the preceding minimum (or the initial cosine) to the next minimum is linearly mapped to [0,1]. Absolute phases at negligible amplitude are immaterial. The CSV gives the RMS inter-excursion difference of each complex coefficient divided by the previous RMS amplitude. The exact decomposition of squared complex distance into radial change and an angular part is integrated over this normalized interval. Relative phase is the angle against the fundamental raised to the corresponding harmonic order. The input cadence limits the accuracy of these comparisons.
