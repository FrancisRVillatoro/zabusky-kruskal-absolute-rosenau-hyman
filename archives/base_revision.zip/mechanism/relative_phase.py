"""Plot translation-reduced Fourier coordinates and compare successive excursions."""
import argparse
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def read(path):
    with path.open() as fp:
        return list(csv.DictReader(fp))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exports', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    modes = read(args.exports / 'returns/modes_N1800.csv')
    catalog = read(args.exports / 'returns/retornos.csv')
    returns = [0.] + [float(r['tau']) for r in catalog if r['N']=='1800' and r['status']=='LOCAL_MIN']
    assert len(returns)==4
    t = np.array([float(row['tau']) for row in modes])
    s = np.linspace(0., 1., 1001)
    plt.rcParams.update({'font.size':8.2, 'pdf.fonttype':42, 'axes.spines.right':False,
                         'axes.spines.top':False})
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.65), layout='constrained')
    rows = []
    for n, ax in zip((3, 5, 7), axs):
        amp = np.array([np.sqrt(float(row[f'e{n}'])) for row in modes])
        theta = np.array([float(row[f'theta{n}_relative'] or 'nan') for row in modes])
        invalid = ~np.isfinite(theta)
        assert np.all(amp[invalid] < 1e-10)
        z = amp * np.exp(1j * np.nan_to_num(theta))
        z[invalid] = 0.
        paths = []
        for j, (left, right) in enumerate(zip(returns, returns[1:])):
            times = left + s*(right-left)
            # Linear interpolation of real and imaginary parts on the actual time grid.
            path = np.interp(times, t, z)
            paths.append(path)
            color = ['#245c88','#a45326','#408477'][j]
            ax.plot(path.real, path.imag, color=color, lw=1,
                    ls=['-','--','-.'][j], label=f'Excursion {j+1}')
            ax.scatter(path[-1].real, path[-1].imag, color=color, s=13, zorder=4)
        ax.set_aspect('equal', adjustable='datalim')
        ax.axhline(0, color='.75', lw=.5, zorder=0)
        ax.axvline(0, color='.75', lw=.5, zorder=0)
        ax.set(xlabel=fr'$\mathrm{{Re}}\,z_{n}$', ylabel=fr'$\mathrm{{Im}}\,z_{n}$',
               title=f'$n={n}$')
        for j, (a,b) in enumerate(zip(paths, paths[1:]), 1):
            radial = (abs(a)-abs(b))**2
            total = abs(a-b)**2
            integral = np.trapezoid(total, s)
            rows.append(dict(n=n, first_excursion=j, second_excursion=j+1,
                 relative_RMS=np.sqrt(integral/np.trapezoid(abs(a)**2,s)),
                 squared_difference_radial_share=np.trapezoid(radial,s)/integral,
                 squared_difference_angular_share=np.trapezoid(total-radial,s)/integral,
                 left_tau=returns[j-1],middle_tau=returns[j],right_tau=returns[j+1]))
    fig.legend(*axs[0].get_legend_handles_labels(), loc='outside lower center',
               frameon=False, fontsize=7.8, ncol=3)
    fig.savefig(args.out/'relative_phase.pdf',bbox_inches='tight',pad_inches=.03)
    plt.close(fig)
    with (args.out/'relative_phase.csv').open('w',newline='') as fp:
        writer = csv.DictWriter(fp, list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == '__main__':
    main()
