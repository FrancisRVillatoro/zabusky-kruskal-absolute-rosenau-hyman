"""Regenerate the four article figures from the accompanying CSV files.

Run from any directory with Python 3, NumPy, pandas and Matplotlib installed:
    python reproduce/make_figures.py
"""
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIGURES = ROOT / "figures"
BLUE = "#245286"
RED = "#AA4830"
GREEN = "#24756D"
GOLD = "#956A17"
INK = "#263238"
GREY = "#65747B"
PALE = "#ECF0F1"
WIDTH = 6.6

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 8,
    "axes.titlesize": 9,
    "axes.labelsize": 8,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "legend.fontsize": 7,
    "axes.labelcolor": INK,
    "text.color": INK,
    "xtick.color": INK,
    "ytick.color": INK,
    "axes.edgecolor": GREY,
    "axes.linewidth": .65,
    "lines.linewidth": 1.2,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "legend.frameon": False,
    "legend.handlelength": 2.1,
    "legend.borderaxespad": .2,
    "figure.facecolor": "white",
    "savefig.facecolor": "white",
    "pdf.fonttype": 42,
    "mathtext.fontset": "dejavusans",
})

def panel(ax, text):
    ax.set_title(text, loc="left", fontweight="semibold", pad=6)


def finish(fig, name):
    FIGURES.mkdir(exist_ok=True)
    fig.savefig(FIGURES / f"{name}.pdf", dpi=300, bbox_inches="tight",
                pad_inches=.04, metadata={"Creator": "Python / Matplotlib", "CreationDate": None})
    plt.close(fig)


def close_period(x, *series):
    """Close dataset over one period for a continuous plot with endpoints 0 and 1."""
    x = np.asarray(x, dtype=float)
    if np.isclose(x[-1], 1.0):
        return (x, *[np.asarray(values) for values in series])
    return (np.r_[x, 1.0], *[np.r_[values, values[0]] for values in series])


def black_grid(ax, direction="y"):
    ax.set_axisbelow(True)
    ax.grid(axis=direction, color="#DCE2E5", linewidth=.5)


def phase4_file(name):
    return pd.read_csv(DATA / "phase4" / name)


def geometry():
    series = [phase4_file(f"profile_return{j}_N1800.csv") for j in (1, 2, 3)]
    space_time = phase4_file("spacetime_N1800.csv").pivot(index="tau", columns="x", values="u")
    domain_length = series[0].x.iloc[1] * series[0].N.iloc[0]
    fig = plt.figure(figsize=(WIDTH, 3.8), layout="constrained")
    grid = fig.add_gridspec(2, 2, width_ratios=[1.0, 1.12])
    ax = fig.add_subplot(grid[:, 0])
    fields = space_time.to_numpy()
    xx = np.r_[space_time.columns.to_numpy() / domain_length, 1.]
    fields = np.c_[fields, fields[:, 0]]
    # "nearest" places cell boundaries halfway between *actual* recorded times.
    mesh = ax.pcolormesh(xx, space_time.index, fields, cmap="RdBu_r",
                         vmin=-1.4, vmax=1.4, shading="nearest", rasterized=True)
    ax.set(xlim=(0, 1), ylim=(0, space_time.index[-1]),
           xlabel=r"$x/L$", ylabel=r"Crossing time $\tau$")
    ax.set_yticks([0, 1, 2, 3])
    ax.set_xticks([0, .25, .5, .75, 1])
    for frame in series:
        ax.axhline(frame.tau.iloc[0], color=INK, linewidth=.65, dashes=[1.5, 3])
    bar = fig.colorbar(mesh, ax=ax, location="bottom", shrink=.88, pad=.06,
                       aspect=34, ticks=[-1.4, -.7, 0, .7, 1.4])
    bar.set_label(r"Field $u(x,\tau)$", labelpad=1)
    panel(ax, "(a) Space–time field")

    a = fig.add_subplot(grid[0, 1])
    b = fig.add_subplot(grid[1, 1])
    profile = series[0]
    x, u, ref = close_period(profile.x.to_numpy()/domain_length,
                             profile.u.to_numpy(), profile.u0_opt_shift.to_numpy())
    a.plot(x, u, color=BLUE, label=r"$u(x,\tau_1)$")
    a.plot(x, ref, color=RED, dashes=[4, 2], label="Translated initial profile")
    a.set(ylabel="Field", xlim=(0, 1), ylim=(-1.13, 1.13))
    a.set_yticks([-1, 0, 1])
    a.set_xticks([0, .25, .5, .75, 1])
    a.tick_params(labelbottom=False)
    panel(a, "(b) First return")
    a.legend(loc="lower center", bbox_to_anchor=(.5, -.23), ncols=2,
             columnspacing=1, fontsize=6.5)

    for j, (frame, color, style) in enumerate(zip(series, [GREEN, RED, BLUE],
                                                    [":", "--", "-"]), 1):
        x, residual = close_period(frame.x.to_numpy()/domain_length, frame.residual.to_numpy())
        b.plot(x, residual, color=color, ls=style, lw=1.0, label=fr"$j={j}$")
    b.axhline(0, color=GREY, lw=.5, zorder=-2)
    b.set(xlim=(0, 1), xlabel=r"$x/L$", ylabel=r"$u-u_0^{\rm shift}$")
    b.set_xticks([0, .25, .5, .75, 1])
    b.legend(loc="lower center", ncol=3, bbox_to_anchor=(.5, -.55),
             columnspacing=1.3)
    panel(b, "(c) Residual after translation")
    finish(fig, "fig1_return_geometry")


def modal_returns():
    modes = phase4_file("modes_N1800.csv")
    coarse = phase4_file("modes_N900.csv")
    early = phase4_file("retornos.csv").query("N == 1800 and status == 'LOCAL_MIN'").copy()
    # These summaries give the sampled minimum; the modal curve contains the same rows.
    early = early.merge(modes[["tau", "e3", "e5"]], on="tau", validate="one_to_one")
    late = pd.read_csv(DATA/"phase4b"/"retornos4b.csv").query("N == 1800 and dt_divisor == 4").copy()
    late["index"] = 4
    returns = pd.concat([early, late], ignore_index=True).sort_values("index")
    fig, axes = plt.subplots(2, 2, figsize=(WIDTH, 4.65), layout="constrained")
    a, b, c, d = axes.ravel()
    a.plot(coarse.tau, coarse.D, color="#9DA9AD", lw=1.3, label=r"$N=900$")
    a.plot(modes.tau, modes.D, color=BLUE, lw=1.05, label=r"$N=1800$")
    a.scatter(returns.tau.iloc[:3], returns.D.iloc[:3], color=BLUE, s=16,
              edgecolors="white", linewidths=.4, zorder=4)
    a.scatter(late.tau, late.D, color=RED, marker="D", s=23, edgecolors="white",
              linewidths=.5, zorder=5, label=r"$\Delta t/4$ restart")
    panel(a, "(a) Distance to the initial orbit")
    a.set(xlabel=r"$\tau$", ylabel=r"$D$", xlim=(0, 4.25), ylim=(-.025, 1.04))
    a.set_xticks(range(5))
    a.legend(loc="lower center", bbox_to_anchor=(.5, -.37), ncols=3, fontsize=6.2,
             columnspacing=.8, handlelength=1.45)
    b.plot(modes.tau, modes.r, color=BLUE, label=r"$r=2|\hat u_1|/A$")
    b.plot(modes.tau, modes.Phi1, color=RED, ls="--", lw=1.0, label=r"$\Phi_1$")
    panel(b, "(b) Recovery of the fundamental")
    b.set(xlabel=r"$\tau$", ylabel="Amplitude or fraction", xlim=(0, 3.25), ylim=(0, 1.06))
    b.set_xticks([0, 1, 2, 3])
    b.legend(loc="lower center", bbox_to_anchor=(.5, -.37), ncols=2)
    for n, color, ls in [(1, INK, "-"), (3, BLUE, "--"), (5, RED, ":"), (7, GREEN, "-.")]:
        e = modes[f"E{n}"].to_numpy()
        c.plot(modes.tau, np.where(e>0, e, np.nan), color=color, ls=ls,
               lw=1.0, label=fr"$n={n}$")
    c.set(xlabel=r"$\tau$", ylabel=r"$E_n=|\hat u_n|^2$", xlim=(0, 3.25),
          yscale="log", ylim=(1e-6, .5))
    c.set_xticks([0, 1, 2, 3])
    c.set_yticks([1e-6, 1e-4, 1e-2])
    c.legend(ncols=4, loc="lower center", bbox_to_anchor=(.5,-.37), fontsize=6.4,
             columnspacing=.9, handlelength=1.4)
    panel(c, "(c) Fourier powers")
    j = returns["index"].to_numpy()
    portion3 = 100 * returns.e3.to_numpy() / returns.H.to_numpy()
    portion5 = 100 * returns.e5.to_numpy() / returns.H.to_numpy()
    rest = 100 - portion3 - portion5
    d.bar(j, portion5, color=RED, width=.58, label=r"$n=5$")
    d.bar(j, portion3, bottom=portion5, color=BLUE, width=.58, label=r"$n=3$")
    d.bar(j, rest, bottom=portion5+portion3, color="#CCD3D4", width=.58, label="Remaining")
    d.set(xlabel=r"Return $j$", ylabel="Nonfundamental power (%)", ylim=(0, 100))
    d.set_xticks(j)
    d.legend(ncols=3, loc="lower center", bbox_to_anchor=(.5,-.37), fontsize=6.4,
             columnspacing=1, handlelength=1.25)
    panel(d, "(d) Spectrum at each minimum")
    for ax in axes.ravel():
        black_grid(ax)
    finish(fig, "fig2_modal_returns")


def positive_profiles():
    base = DATA/"phase5"
    profile = pd.read_csv(base/"profile_fits.csv").query("case == 'P_p2_M8'")
    population = pd.read_csv(base/"snapshots.csv").query(
        "case == 'P_p2_M8' and role == 'space_high' and N == 4000").sort_values("tau")
    peaks = pd.read_csv(base/"peaks.csv").query(
        "case == 'P_p2_M8' and role == 'space_high' and N == 4000")
    fig, axes = plt.subplots(2, 2, figsize=(WIDTH, 4.17), layout="constrained")
    a, b, c, d = axes.ravel()
    for ax, tau, title in [(a, .5, r"(a) Profile at $\tau=0.5$"),
                           (b, 2., r"(b) Profile at $\tau=2$")]:
        selected = profile.loc[profile.tau.eq(tau)].sort_values("x")
        marks = peaks.loc[peaks.tau.eq(tau)]
        x, u, zero, pedestal = close_period(selected.x_over_L.to_numpy(), selected.u.to_numpy(),
                                             selected.comp_zero.to_numpy(), selected.comp_pedestal.to_numpy())
        ax.plot(x, u, color=INK, lw=1.3, label="Field")
        ax.plot(x, zero, color=BLUE, lw=1.0, ls="--", label="Zero base")
        ax.plot(x, pedestal, color=RED, lw=1.0, ls=":", label="Fitted base")
        ax.scatter(marks.x_over_L, marks.u_peak, s=12, marker="o", facecolors="white",
                   edgecolors=INK, linewidths=.7, zorder=4, label="Peaks")
        panel(ax, title)
        ax.set(xlim=(0, 1), ylim=(0, 1.58), xlabel=r"$x/L$", ylabel="Field")
        ax.set_xticks([0, .25, .5, .75, 1])
        ax.set_yticks([0, .5, 1, 1.5])
    handles, labels = a.get_legend_handles_labels()
    a.legend(handles[:2], labels[:2], loc="upper center", bbox_to_anchor=(.5, -.34), ncols=2)
    b.legend(handles[2:], labels[2:], loc="upper center", bbox_to_anchor=(.5, -.34), ncols=2)

    c.fill_between(population.tau, population.n_peak_sensitivity_min,
                   population.n_peak_sensitivity_max, step="mid",
                   color="#D5E3E9", label="Threshold range")
    c.step(population.tau, population.n_peaks, where="mid", color=BLUE, lw=1.15,
           label="Primary count")
    c.set(xlabel=r"$\tau$", ylabel="Number of peaks", xlim=(0, 2), ylim=(0, 8.5))
    c.set_xticks([0, .5, 1, 1.5, 2])
    c.set_yticks([0, 2, 4, 6, 8])
    c.legend(ncols=2, loc="upper center", bbox_to_anchor=(.5, -.34),
             handlelength=1.5, columnspacing=1)
    panel(c, "(c) Sensitivity of peak count")
    mature = population.loc[population.tau >= .25]
    d.plot(mature.tau, 100*mature.minimum_over_peak, color=GREEN, lw=1.1)
    d.axhline(1, color=GREY, ls="--", lw=.85, label="1% threshold")
    d.set(xlabel=r"$\tau$", ylabel=r"$100\,\min(u)/\max(u)$", xlim=(.25, 2), ylim=(0, 10))
    d.set_xticks([.25, .5, 1, 1.5, 2])
    d.legend(loc="upper center", bbox_to_anchor=(.5, -.34))
    panel(d, "(d) Interpulse background")
    for ax in (c, d):
        black_grid(ax)
    finish(fig, "fig3_positive_profiles")


def regularization():
    base = DATA/"phase6"
    means = pd.read_csv(base/"zero_nu_comparison.csv").query("N == 1800")
    all_returns = pd.read_csv(base/"zero_nu_comparison.csv")
    radau = all_returns[["N", "return_index", "nu0_D"]].drop_duplicates().pivot(index="return_index",columns="N",values="nu0_D")
    late = pd.read_csv(DATA / "phase4b" / "retornos4b.csv").query("dt_divisor == 4").set_index("N").D
    radau.loc[4] = late.reindex(radau.columns)
    regularized = all_returns.pivot(index=["nu","return_index"],columns="N",values="nu_D")
    zero = means[["return_index","nu0_D"]].drop_duplicates().sort_values("return_index")
    sections = pd.read_csv(base/"matched_field_sections.csv")
    fig, (a, b, c) = plt.subplots(1, 3, figsize=(7.1, 2.55), layout="constrained")
    common = sections.loc[sections.nu.eq(0)].sort_values("j")
    c.plot(common.j, 100*common.error, color=INK, ls="--", marker="o", mfc="white", ms=3.4)
    a.plot(zero.return_index, zero.nu0_D, color=INK, ls="--", marker="o",
           mfc="white", ms=4.2, label=r"$\nu=0$", zorder=2)
    b.plot(radau.index, abs(radau[1800]-radau[900]), color=INK, ls="--", marker="o", mfc="white", ms=4.2)
    legend_rows = [(0.00025, RED, "s", "-."), (0.001, BLUE, "^", ":"),
                   (0.004, GREEN, "D", "-")]
    for nu, color, marker, style in legend_rows:
        points = means.loc[means.nu.eq(nu)].sort_values("return_index")
        controls = regularized.loc[nu].sort_index()
        shared = dict(color=color, marker=marker, mfc="white", ms=4, ls=style)
        a.plot(points.return_index, points.nu_D, **shared, label=fr"$\nu={nu:g}$")
        b.plot(controls.index, abs(controls[1800]-controls[900]), **shared)
        common = sections.loc[sections.nu.eq(nu)].sort_values("j")
        c.plot(common.j, 100*common.error, **shared)
    for ax in (a, b, c):
        ax.set(xlabel=r"Return $j$", xlim=(.85, 4.15))
        ax.set_xticks([1, 2, 3, 4])
        black_grid(ax)
    panel(a, "(a) Return distance")
    a.set(ylabel=r"$D_j$", ylim=(0, .26))
    panel(b, "(b) Depth on refinement")
    b.set(ylabel=r"$|D_j(1800)-D_j(900)|$", yscale="log")
    panel(c, "(c) Field on refinement")
    c.set(ylabel=r"Field difference at $j+1/8$ (%)")
    handles, labels = a.get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncols=4, columnspacing=1.5)
    finish(fig, "fig4_regularization")


if __name__ == "__main__":
    geometry()
    modal_returns()
    positive_profiles()
    regularization()
