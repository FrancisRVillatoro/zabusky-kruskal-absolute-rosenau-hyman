"""Rebuild the short-time survey and the fourth-return resolution plots.

Inputs are unchanged CSV exports of the simulation analysis modules.
Run from any working directory with Python, NumPy and Matplotlib.
"""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "comparisons"
OUT = ROOT / "figures"
OUT.mkdir(exist_ok=True)
C = ["#145885", "#bf571c", "#157b68", "#6d4c8b"]
plt.rcParams.update({"font.size": 9.1, "axes.titlesize": 10, "axes.labelsize": 10,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.axisbelow": True, "pdf.fonttype": 42, "font.family": "DejaVu Sans"})

def rows(file):
    with (DATA / file).open(newline="", encoding="utf8") as handle:
        return list(csv.DictReader(handle))

def values(records, key):
    return np.array([float(record[key]) for record in records])

def save(fig,name):
    fig.savefig(OUT / (name+".pdf"), bbox_inches="tight", pad_inches=.055)
    plt.close(fig)

def short_cases():
    records = rows("series_25.csv")
    cases = [
        ("P_p2_M4", r"$P,\ p=2,\ M=4$"),
        ("Z_p2_M4", r"$Z,\ p=2,\ M=4$"),
        ("Z_p225_M4", r"$Z,\ p=9/4,\ M=4$"),
        ("Z_p2_M8", r"$Z,\ p=2,\ M=8$"),
    ]
    fig,axes = plt.subplots(1,2,figsize=(7.0,2.7),sharex=True)
    for idx,(case,label) in enumerate(cases):
        subset = [r for r in records if r["role"]=="space_high" and r["case"]==case]
        assert len(subset)>120
        t = values(subset,"tau")
        for ax,key in zip(axes,("D_cont","Phi1")):
            ax.plot(t,values(subset,key),color=C[idx],lw=1.5,
                    ls=["-","--","-.",":"][idx],label=label)
    for ax,title in zip(axes,("(a)   Distance to the initial profile","(b)   Fundamental share")):
        ax.set_title(title,loc="left",pad=8)
        ax.set(xlim=(0,2.01), xlabel=r"Scaled time $\tau$", xticks=(0,.5,1,1.5,2))
        ax.grid(axis="y",alpha=.22,lw=.55)
    axes[0].set_ylabel(r"$D_{\rm rec}$")
    axes[1].set_ylabel(r"$\Phi_1$")
    axes[1].set_ylim(-.02,1.025)
    fig.legend(*axes[0].get_legend_handles_labels(),loc="lower center",ncol=4,frameon=False,
               bbox_to_anchor=(.5,-.08),fontsize=8.1,columnspacing=1.2)
    fig.subplots_adjust(wspace=.38,bottom=.23)
    save(fig,"comparison_cases")

def resolution():
    baseline = rows("field_budget.csv")
    refined = rows("field_budget4b.csv")
    fig,axes=plt.subplots(1,2,figsize=(7.0,2.7))
    for n0,col,marker in [(450,C[1],"s"),(900,C[0],"o")]:
        r=[q for q in baseline if int(q["Ncoarse"])==n0 and float(q["coverage"].split("..")[-1])>=float(q["return"])+.09]
        axes[0].plot(values(r,"return"),100*values(r,"max_L2_window"),color=col,
                     marker=marker,label=f"{n0} vs {2*n0}",lw=1.4,ms=4)
    axes[0].legend(frameon=False,loc="upper left",fontsize=8)
    axes[0].set(xlabel="Return index",ylabel="Peak field discrepancy (%)",xticks=[1,2,3,4],xlim=(.87,4.13),ylim=(0,6.6))
    axes[0].set_title("(a)   Original time step",loc="left",pad=8)
    comparisons=[("spatial",900,1800,2,2),("spatial",900,1800,4,4),("temporal",900,900,2,4),("temporal",1800,1800,2,4)]
    for j,(kind,n0,n1,a,b) in enumerate(comparisons):
        [rec]=[r for r in refined if (r["type"],int(r["Ncoarse"]),int(r["Nfine"]),int(r["dt_divisor_a"]),int(r["dt_divisor_b"]))==(kind,n0,n1,a,b)]
        axes[1].bar(j,100*float(rec["max_L2"]),color=C[0 if kind=="spatial" else 1],width=.62)
    axes[1].set(title="",ylabel="Peak field discrepancy (%)",ylim=(0,6.6))
    axes[1].set_xticks(range(4),["Space\n"+r"$s/2$","Space\n"+r"$s/4$","Time\n"+r"$N=900$","Time\n"+r"$N=1800$"],fontsize=8)
    axes[1].set_title("(b)   Fourth-return block",loc="left",pad=8)
    for ax in axes:
        ax.grid(axis="y",alpha=.22,lw=.55)
        ax.yaxis.set_major_locator(MaxNLocator(4,integer=True))
    fig.subplots_adjust(wspace=.42,bottom=.23)
    save(fig,"resolution_windows")

if __name__ == "__main__":
    short_cases()
    resolution()
