# Source tables for the recurrence, morphology and regularization figures

The script `reproduce/make_figures.py` uses the tables below to make `fig1_return_geometry.pdf`, `fig2_modal_returns.pdf`, `fig3_positive_profiles.pdf` and `fig4_regularization.pdf`.

These CSV files are unmodified copies of entries in the Picasso output archives. The paths below identify each original entry. A SHA-256 digest identifies its uncompressed bytes.

### Fase4_CNSNS_resultados_20261118.zip

- `spacetime_N1800.csv` → `phase4/spacetime_N1800.csv` (`b5b8049fde26d23cff8a6afcbd989ab6315bfd32fd483a58ab18cb0bae029b0f`)
- `profile_return1_N1800.csv` → `phase4/profile_return1_N1800.csv` (`da1cde455ae958ed594d60a8475b943bb1c92a0981a1a72309410fe5c8ecf5eb`)
- `profile_return2_N1800.csv` → `phase4/profile_return2_N1800.csv` (`00700befeb2d105af31538173d0e5cd16c7afe87c790271d1d4c8e3944866d9e`)
- `profile_return3_N1800.csv` → `phase4/profile_return3_N1800.csv` (`0a9e2e01fb0ba73537eeed7a8faf1f073d65a56a3a8ed54b2a94a54d237ac592`)
- `modes_N1800.csv` → `phase4/modes_N1800.csv` (`377131902d04507d74fb38ebee3a95b73cafe81e8f752364025f2e0c930a55af`)
- `modes_N900.csv` → `phase4/modes_N900.csv` (`9543c5ff86b3c3b1f38c44a3451dfcabc8fbe5a60799d1a2d30927aae02027fe`)
- `retornos.csv` → `phase4/retornos.csv` (`3eb20dcb563d883cff31924ad9068499094da82bafe17d9e5bbfa88c8cb5d493`)

### Fase4B_CNSNS_resultados_20261118.zip

- `retornos4b.csv` → `phase4b/retornos4b.csv` (`062723ce4d45414aaaac8acf6b0ef35a80d88e0aa48870ca87f976a3ed4fc195`)

### Fase5_CNSNS_P_resultados_20261118.zip

- `fase5/results/analysis/profile_fits.csv` → `phase5/profile_fits.csv` (`47ea31cb48bf962938dac9e089601a0e109eddebaa3d7a7b2e33d6eee6dbd3ee`)
- `fase5/results/analysis/snapshots.csv` → `phase5/snapshots.csv` (`d6166635e4260f3d0762a4bbd03be1dbee0cfd7f964447147d3318495c1f0463`)
- `fase5/results/analysis/peaks.csv` → `phase5/peaks.csv` (`0f90439a77d73aa497a1b2b1acd0317ff7230673cfd5755b5d3e26451d94b67d`)

### Fase6_CNSNS_resultados_20261118.zip

- `fase6/results/analysis/zero_nu_comparison.csv` → `phase6/zero_nu_comparison.csv` (`027aa86bf0a46021d744120c0870bee7f61c9512874ecd827d055a155c95dacf`)
- `fase6/results/analysis/refinement.csv` → `phase6/refinement.csv` (`e7f4b49386052d35c0620b7e6d831e12078b3794dd2c686cc3112bc45525e4b7`)

## Short-run comparison and fourth-return error figures

The script `reproduce/plot_comparisons.py` draws the short survey and unregularized field discrepancies. The following files retain their archived content and filenames.

- Fase4_CNSNS_resultados_20261118.zip → comparisons/field_budget.csv (2c077fb2b29a3a9bc69bdec3284f7d6624f2d80f0092439591305bde740e799c)
- Fase4B_CNSNS_resultados_20261118.zip → comparisons/field_budget4b.csv (82e300ae2970917a6da595964110b4c533393385bac54f5f135afe4b6c9c85ae)
- Fase3_retornos_25_20261117.zip → comparisons/minimos_locales.csv (da8cb3b6c235d72c2b69256c3a21e7c768ba9430b5fa5eff773d963a9548041f)
- Fase3_retornos_25_20261117.zip → comparisons/resumen_25.csv (91b81e5e3d5ff62257b7a39d2e9c28a4ea93ecbac574d50c92d26fb50fcd0a02)
- Fase3_retornos_25_20261117.zip → comparisons/series_25.csv (cf96c2ebf2e90ae5a1106380f854e1bd58f578a7ab94af6ff237b856b0d4d0ac)

The revised regularization plot also reads phase6/matched_field_sections.csv. Its source is audit/results/matched_field_sections.csv, reproduced with audit/matched_field_sections.py. The scalar fourth-return comparison uses the quarter-step rows of phase4b/retornos4b.csv on both grids.
