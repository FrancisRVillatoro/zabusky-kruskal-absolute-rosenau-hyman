# Energy-preserving AVF control

The independent time integrator uses the archived Python spatial operators and initial cosine. It runs from the initial condition with fixed steps, zero viscosity and the production half-wave projection. No Radau state is used as an AVF initial condition. The componentwise divided difference is the exact AVF flux in real arithmetic. A local Taylor expansion evaluates it stably near equal nonzero arguments. The nonlinear solve uses analytic derivatives, backtracking and an RMS-scaled residual cutoff of one (absolute scale 1e-11, relative scale 1e-9).

Run the following from this directory with the supplement unpacked. The drivers locate its code and exports automatically when this directory is inside the supplement, or inside a directory next to its supp subdirectory. Alternatively, give the drivers the supplement root using --supplement. NumPy, SciPy and matplotlib are required.

```sh
export OPENBLAS_NUM_THREADS=1
python -m unittest -v test_avf
for n in 450 900 1800; do
  for k in 3200 6400; do
    python avf_long.py --N "$n" --K "$k"
  done
done
for n in 900 1800; do
  python avf_long.py --N "$n" --K 12800
done
python compare_methods.py
```

The target horizon is 4.25 crossing times. Every step is sampled in the windows [0.94,1.10], [1.8,2.2], [2.8,3.2] and [3.8,4.2]. A return is the lowest interior sample there and must be below both immediate neighbours. A window is included only if fully traversed. Each JSON records the attained horizon, nonlinear failure (if any), maximum absolute relative invariant change at all accepted steps and individually resolved returns. Each CSV carries sampled diagnostics. NPZ arrays contain the last accepted field, fields at each accepted return, and fields at the archived fine-grid Radau times whenever traversed. The separate results directory contains short runs ending at 1.10 with the same integrator for invariant auditing around the first return.

method_returns.csv joins the resolved AVF and archived Radau diagnostics. shared_time_profiles.csv compares fields at the first three fine-grid Radau return times without any translation, normalized by the initial cosine norm. The fourth Radau minimum uses the refined final-block restart in the fourth-return export. That export has no full field at the exact fourth minimum. avf_run_status.csv lists all attempts including fixed-step Newton failures. The PDF is generated from method_returns.csv data. Three unit tests cover the divided difference and its derivative, the reordered Newton matrix, second-order accuracy and conservation.
