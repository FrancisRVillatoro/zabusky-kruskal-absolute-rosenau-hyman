"""Fixed-step energy-preserving AVF control on the production mass-matrix system.

Uses the original spatial operators. The cyclic five-diagonal Newton system is
permuted into bandwidth four for a compact banded factorization; no matrix
inverse is assembled. Run with --help for available comparisons.
"""
import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy.linalg import solve_banded
from scipy.special import binom


def default_supplement():
    here=Path(__file__).resolve().parent
    for parent in here.parents:
        for candidate in (parent,parent/'supp'):
            if (candidate/'code/absk_radau/model.py').is_file():
                return candidate
    return None


def setup_code(supplement):
    sys.path.insert(0, str(Path(supplement).resolve() / 'code'))
    from absk_radau.model import PeriodicAbsK, crossing_time, domain_length, make_initial_data
    return PeriodicAbsK, crossing_time, domain_length, make_initial_data


class MeanFlux:
    """Componentwise discrete gradient of |u|**(p+1)/(p+1)."""
    def __init__(self, p):
        self.p = p
        k = np.arange(11)
        self.mean_coef = binom(p, k) / (k + 1)
        self.derivative_coef = p * binom(p - 1, k) / (k + 2)

    def evaluate(self, x, y, derivative=False):
        delta = y - x
        close = (np.abs(delta) <= .05 * np.abs(x)) & (x != 0)
        flat = (x == 0) & (y == 0)
        other = ~(close | flat)
        g = np.zeros_like(x)
        power = self.p + 1
        xo, yo, do = x[other], y[other], delta[other]
        g[other] = (np.abs(yo)**power - np.abs(xo)**power) / (power * do)
        xc = x[close]
        q = delta[close] / xc
        axp = np.abs(xc)**(self.p - 1)
        g[close] = axp * xc * np.polynomial.polynomial.polyval(q, self.mean_coef)
        if not derivative:
            return g
        dg = np.zeros_like(x)
        dg[other] = (np.abs(yo)**(self.p - 1) * yo - g[other]) / do
        dg[close] = axp * np.polynomial.polynomial.polyval(q, self.derivative_coef)
        return g, dg


class AVFStep:
    def __init__(self, model, dt, relative=1.e-9, absolute=1.e-11):
        self.model, self.dt = model, dt
        self.relative, self.absolute = relative, absolute
        self.flux = MeanFlux(model.p)
        n = model.n
        self.perm = np.argsort(np.minimum(2*np.arange(n), 2*(n-np.arange(n))-1))
        inverse = np.argsort(self.perm)
        self.mass_band = np.zeros((9,n))
        self.k_band = np.zeros((9,n))
        for operator, band in [(model.mass,self.mass_band),(model.K,self.k_band)]:
            mat = operator.tocoo()
            row, col = inverse[mat.row], inverse[mat.col]
            assert np.abs(row-col).max() <= 4
            band[4 + row-col,col] = mat.data

    def residual(self, x, y, g):
        return self.model.mass @ (y-x) + self.dt * (self.model.K @ g)

    def scaled(self, residual, x, y):
        scale = self.absolute + self.relative*np.maximum(np.abs(x),np.abs(y))
        return np.linalg.norm(residual/scale) / np.sqrt(x.size)

    def advance(self, x):
        y = x.copy()
        for it in range(30):
            g, dg = self.flux.evaluate(x, y, True)
            residual = self.residual(x, y, g)
            loss = self.scaled(residual, x, y)
            if loss <= 1.:
                # Same half-wave projection convention as production Radau.
                return (y-np.roll(y,y.size//2))/2, it, loss
            matrix = self.mass_band + self.dt*self.k_band*dg[self.perm]
            corr = np.empty_like(y)
            corr[self.perm] = solve_banded((4,4),matrix,-residual[self.perm],
                                           overwrite_ab=True, check_finite=False)
            for cut in range(16):
                trial = y + (2.**-cut)*corr
                candidate = self.residual(x,trial,self.flux.evaluate(x,trial))
                if self.scaled(candidate,x,trial) < loss:
                    y = trial
                    break
            else:
                raise RuntimeError('line search failed, scaled RMS='+str(loss))
        raise RuntimeError('Newton limit reached, scaled RMS='+str(loss))


def diagnostics(u):
    z = np.fft.rfft(u) / u.size
    r = 2*abs(z[1])
    h = 4*sum(abs(z[2:-1])**2) + 2*abs(z[-1])**2
    e5 = 4*abs(z[5])**2
    return dict(D=float(np.sqrt(2*z[0].real**2+(1-r)**2+h)), r=r, H=h,
                Phi1=r*r/(r*r+h), e5_over_H=e5/h if h else 0)


def run(args):
    model_class, crossing_time, domain_length, initial_data = setup_code(args.supplement)
    p, m = args.p, args.M
    if args.N%2: raise ValueError('Half-wave projection needs even N')
    mod = model_class(args.N,domain_length(p,m),p,0)
    T = crossing_time(p,m)
    dt = T/args.K
    solver = AVFStep(mod,dt)
    u = initial_data(mod)
    u = (u-np.roll(u,args.N//2))/2
    i0 = mod.lp_invariant(u)
    tag = f'p{p:g}_M{m}_N{args.N}_K{args.K}'
    path = Path(args.out);path.mkdir(exist_ok=True,parents=True)
    lo = round(.94*args.K)
    last = round(1.1*args.K)
    if abs(last-1.1*args.K)>1.e-8:raise ValueError('K incompatible with endpoint')
    profile = None; best = math.inf; bestrow = {}
    max_drift = 0.; max_rms=0.; max_newton = 0; failed = None
    trace = []
    for k in range(last+1):
        if k:
            try:
                u, it, rms = solver.advance(u)
            except RuntimeError as error:
                failed=str(error);break
            max_newton=max(it,max_newton);max_rms=max(rms,max_rms)
        drift = mod.lp_invariant(u)/i0-1.
        max_drift=max(abs(drift),max_drift)
        if k%max(1,round(args.K/100))==0 or k>=lo:
            row={'step':k,'tau':k/args.K,**diagnostics(u),'relative_invariant_change':drift}
            trace.append(row)
            if lo<k<last and row['D']<best:
                best=row['D'];profile=u.copy();bestrow=row.copy()
        last_accepted=k
    with (path/(tag+'.csv')).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=trace[0]);w.writeheader();w.writerows(trace)
    if profile is not None:
        ix=next(i for i,r in enumerate(trace) if r['step']==bestrow['step'])
        if ix==0 or ix+1>=len(trace) or not (trace[ix-1]['D']>best<trace[ix+1]['D']):
            bestrow={};profile=None
    if profile is not None:
        np.savez_compressed(path/(tag+'.npz'),u_at_return=profile,u_last=u)
    summary={'N':args.N,'K':args.K,'p':p,'M':m,'T_cross':T,'dt':dt,'solver':'AVF',
             'half_wave_projection':True,'failed':failed,'last_tau':last_accepted/args.K,
             'max_absolute_relative_invariant_change':max_drift,
             'max_accepted_scaled_rms':max_rms,'max_newton':max_newton,
             'return':bestrow}
    (path/(tag+'.json')).write_text(json.dumps(summary,indent=2,allow_nan=False))
    print(json.dumps(summary),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--supplement',default=default_supplement())
    ap.add_argument('--out',default='results')
    ap.add_argument('--N',type=int,required=True)
    ap.add_argument('--K',type=int,required=True,help='steps per crossing')
    ap.add_argument('--p',type=float,default=2.25)
    ap.add_argument('--M',type=int,default=4)
    run(ap.parse_args())
