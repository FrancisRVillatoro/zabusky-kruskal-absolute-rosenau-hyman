"""Summarize AVF and archived Radau calculations and draw the integrator comparison."""
import csv
import json
from pathlib import Path
import numpy as np
from avf_control import default_supplement

HERE=Path(__file__).resolve().parent


def read_csv(path):
    with path.open(newline='') as f: return list(csv.DictReader(f))


def write_csv(path, rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)


def summarize():
    source=default_supplement()
    directory=source/'exports/returns'
    paths=sorted((HERE/'long_results').glob('*.json'))
    rows=[]; audits=[];fields=[]
    for path in paths:
        d=json.loads(path.read_text())
        n,k=d['N'],d['K']
        audits.append({k:d[k] for k in ('N','K','last_tau','failed','max_absolute_relative_invariant_change','max_accepted_scaled_rms','max_newton')})
        for j,r in d['returns'].items():
            rows.append(dict(method='AVF',N=n,K=k,j=int(j),tau=r['tau'],D=r['D'],r=r['r'],H=r['H'],
                             Phi1=r['Phi1'],fifth_resid_fraction=r['e5_over_H'],drift_at_return=r['relative_invariant_change']))
        if n==1800:
            shared=np.load(path.with_suffix('.npz'))
            for j in [1,2,3]:
                key=f'u_radau_time_{j}'
                if key not in shared:continue
                profile=read_csv(directory/f'profile_return{j}_N1800.csv')
                u=np.array([float(v['u']) for v in profile])
                tau=float(profile[0]['tau'])
                fields.append(dict(N=n,AVF_K=k,Radau_K=3200,return_index=j,tau=tau,
                                   shared_time_initial_norm_difference=float(np.linalg.norm(u-shared[key])/np.sqrt(n/2))))
    baseline=read_csv(directory/'retornos.csv')
    for n in [450,900,1800]:
        history=read_csv(directory/f'modes_N{n}.csv')
        initial=float(history[0]['I_p1'])
        lookup={float(q['tau']):q for q in history}
        for q in baseline:
            if int(q['N'])!=n or q['status']!='LOCAL_MIN':continue
            m=lookup[float(q['tau'])]
            rows.append(dict(method='Radau',N=n,K=3200,j=int(q['index']),tau=float(q['tau']),D=float(q['D']),
                             r=float(q['r']),H=float(q['H']),Phi1=float(q['Phi1']),
                             fifth_resid_fraction=float(m['e5'])/float(m['H']),drift_at_return=float(q['I_p1'])/initial-1))
    for q in read_csv(source/'exports/fourth_return/retornos4b.csv'):
        if int(q['N'])==1800 and int(q['dt_divisor'])==4:
            rows.append(dict(method='Radau final-block restart',N=1800,K=12800,j=4,tau=float(q['tau']),D=float(q['D']),
                             r=float(q['r']),H=float(q['H']),Phi1=float(q['Phi1']),
                             fifth_resid_fraction=float(q['e5_over_H']),drift_at_return=''))
    write_csv(HERE/'method_returns.csv',rows)
    write_csv(HERE/'avf_run_status.csv',audits)
    write_csv(HERE/'shared_time_profiles.csv',fields)
    return rows


def plot(rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(6.85,2.6),layout='constrained')
    for k,col,marker,ls in ((3200,'#8c321b','s','--'),(6400,'#0a7260','^',':'),(12800,'#755486','x','-.')):
        vals=sorted([r for r in rows if r['method']=='AVF' and r['N']==1800 and r['K']==k],key=lambda r:r['j'])
        if not vals:continue
        for ax,key in zip(axes,['D','fifth_resid_fraction']):
            ax.plot([r['j'] for r in vals],[r[key] for r in vals],ls=ls,color=col,marker=marker,
                    lw=1.25,ms=4.8,label=f'AVF, {k}')
    vals=sorted([r for r in rows if r['method'].startswith('Radau') and r['N']==1800],key=lambda r:r['j'])
    for ax,key,title in zip(axes,['D','fifth_resid_fraction'],['(a)  Distance at a return','(b)  Fifth-mode share']):
        ax.plot([r['j'] for r in vals],[r[key] for r in vals],color='#184665',marker='o',
                markersize=5.7,markerfacecolor='none',lw=1.2,label='Radau')
        ax.set(xlabel='Return index',xticks=[1,2,3,4],xlim=(.85,4.15))
        ax.set_title(title,loc='left',fontsize=10.8)
        ax.spines[['top','right']].set_visible(False)
        ax.grid(axis='y',lw=.44,alpha=.28)
    axes[0].set_ylabel(r'$D_j$')
    axes[1].set_ylabel(r'$e_5/H$')
    axes[0].legend(frameon=False,fontsize=7.1,loc='upper left')
    fig.savefig(HERE/'avf_return_comparison.pdf')
    plt.close(fig)


if __name__=='__main__':plot(summarize())
