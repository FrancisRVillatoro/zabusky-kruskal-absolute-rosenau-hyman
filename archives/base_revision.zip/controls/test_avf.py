"""Independent numerical checks of discrete-gradient and banded implementations."""
import unittest
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.linalg import solve_banded
from scipy.sparse import diags

from avf_control import MeanFlux, AVFStep, setup_code, default_supplement


class TestAVF(unittest.TestCase):
    def test_secant_and_analytic_jacobian_against_split_quadrature(self):
        p=2.25
        pairs=[(-1,1),(-.01,1),(-.4,-.40000000000003),(.8,.73),
               (0,-.3),(0,0),(-1,-1),(1,1.049),(1,1.051)]
        for x,y in pairs:
            points=[] if y==x or x*y>=0 else [-x/(y-x)]
            w=lambda t:x+(y-x)*t
            q=quad(lambda t:np.abs(w(t))**(p-1)*w(t),0,1,points=points,epsabs=1e-14)[0]
            dq=quad(lambda t:p*t*np.abs(w(t))**(p-1),0,1,points=points,epsabs=1e-14)[0]
            g,dg=MeanFlux(p).evaluate(np.array([x],dtype=float),np.array([y],dtype=float),True)
            self.assertAlmostEqual(g[0],q,places=11)
            self.assertAlmostEqual(dg[0],dq,places=9)

    def test_banded_newton_matrix_matches_full_sparse_jacobian(self):
        cls,_,domain,_=setup_code(default_supplement())
        model=cls(100,domain(2.25,4),2.25,0)
        step=AVFStep(model,.019)
        x=np.cos(2*np.pi*np.arange(100)/100)
        d=MeanFlux(2.25).evaluate(x,x+.01,True)[1]
        J=(model.mass+step.dt*(model.K@diags(d))).toarray()
        ab=step.mass_band+step.dt*step.k_band*d[step.perm]
        rhs=np.sin(.3+np.arange(100))
        correction=np.empty_like(rhs)
        correction[step.perm]=solve_banded((4,4),ab,rhs[step.perm])
        np.testing.assert_allclose(J@correction,rhs,rtol=1e-12,atol=1e-12)

    def test_fixed_grid_second_order_and_energy(self):
        from scipy.integrate import solve_ivp
        cls,_,domain,initial=setup_code(default_supplement())
        model=cls(48,domain(2.25,4),2.25,0)
        x=initial(model); x=(x-np.roll(x,24))/2;T=.8
        reference=solve_ivp(lambda t,u:model.velocity(u),(0,T),x,method='DOP853',rtol=2e-13,atol=1e-14).y[:,-1]
        errors=[]
        for k in [16,32,64]:
            trial=x.copy(); step=AVFStep(model,T/k,relative=1.e-12,absolute=1.e-14)
            for _ in range(k):
                trial,_,_=step.advance(trial)
            errors.append(np.linalg.norm(trial-reference))
            self.assertLess(abs(model.lp_invariant(trial)/model.lp_invariant(x)-1),2.e-11)
        ratios=np.array(errors[:-1])/errors[1:]
        self.assertTrue(np.all((ratios>3.7)&(ratios<4.3)),(errors,ratios))

if __name__=='__main__': unittest.main()
