"""AVF evolution from the initial cosine through four complete return windows."""
import argparse
import csv
import json
import sys
from pathlib import Path
import numpy as np

from avf_control import default_supplement, setup_code, AVFStep, diagnostics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--supplement',default=default_supplement())
    parser.add_argument('--out',default='long_results')
    parser.add_argument('--N',type=int,required=True)
    parser.add_argument('--K',type=int,required=True)
    parser.add_argument('--M',type=int,default=4)
    parser.add_argument('--p',type=float,default=2.25)
    parser.add_argument('--end',type=float,default=4.25)
    args=parser.parse_args()
    n,kappa=args.N,args.K
    if n%2: raise ValueError('even N required')
    p,m=args.p,args.M
    model_class, crossing, domain, initial=setup_code(args.supplement)
    model=model_class(n,domain(p,m),p,0)
    dt=crossing(p,m)/kappa
    solver=AVFStep(model,dt)
    u=initial(model)
    u=(u-np.roll(u,n//2))/2
    I0=model.lp_invariant(u)
    tag=f'p{p:g}_M{m}_N{n}_K{kappa}'
    path=Path(args.out)
    path.mkdir(exist_ok=True,parents=True)
    last_index=round(args.end*kappa)
    if not np.isclose(last_index/kappa,args.end,rtol=0,atol=1e-13):
        raise ValueError('Endpoint is not on temporal grid')
    windows=[(.94,1.10)]+[(j-.2,j+.2) for j in range(2,5)]
    minima={}; max_drift=0.; max_scaled=0.; max_newton=0
    trace=[]; best_profiles={}; shared_profiles={}; failed=None
    radau_times=[1.0090625,2.019375,3.02625,4.0334375]
    for k in range(last_index+1):
        if k:
            try:
                u,it,loss=solver.advance(u)
            except RuntimeError as error:
                failed=str(error)
                break
            max_newton=max(it,max_newton);max_scaled=max(loss,max_scaled)
        tau=k/kappa
        Ichange=model.lp_invariant(u)/I0-1
        max_drift=max(max_drift,abs(Ichange))
        for j,tref in enumerate(radau_times,1):
            if abs(tau-tref)<1.e-12:shared_profiles['u_radau_time_'+str(j)]=u.copy()
        j=next((j for j,(a,b) in enumerate(windows,1) if a<=tau<=b),0)
        if j or k%max(1,round(kappa/100))==0:
            row=dict(step=k,tau=tau,**diagnostics(u),relative_invariant_change=Ichange)
            trace.append(row)
            if j and windows[j-1][0]<tau<windows[j-1][1] and (j not in minima or row['D']<minima[j]['D']):
                minima[j]=row.copy()
                best_profiles['u_at_return_'+str(j)]=u.copy()
        last=k
    for j in list(minima):
        ix=next(i for i,r in enumerate(trace) if r['step']==minima[j]['step'])
        if trace[-1]['tau']<windows[j-1][1]-1e-12 or ix==0 or ix+1>=len(trace) or not trace[ix-1]['D']>minima[j]['D']<trace[ix+1]['D']:
            del minima[j]
            del best_profiles['u_at_return_'+str(j)]
    with (path/(tag+'.csv')).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=trace[0]);w.writeheader();w.writerows(trace)
    np.savez_compressed(path/(tag+'.npz'),**best_profiles,**shared_profiles,u_last=u)
    summary={'N':n,'K':kappa,'p':p,'M':m,'dt':dt,'half_wave_projection':True,
             'last_tau':last/kappa,'failed':failed,'max_absolute_relative_invariant_change':max_drift,
             'max_accepted_scaled_rms':max_scaled,'max_newton':max_newton,'returns':minima}
    (path/(tag+'.json')).write_text(json.dumps(summary,indent=2,allow_nan=False))
    print(summary,flush=True)


if __name__=='__main__': main()
