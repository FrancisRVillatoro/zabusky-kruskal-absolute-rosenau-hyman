"""Like-for-like relative field errors at four precisely matched time sections.
The positive-viscosity rows come from final_L2 in refinement.csv. At zero
viscosity j=2,3 use the exact published norms rescaled by the contemporaneous
coarse Qosc. Other rows use the published or independently replayed checkpoints.
"""
import argparse
import sys
from pathlib import Path
import numpy as np
import pandas as pd


def evolve(r,n,u,start,end,k):
    model=r.PeriodicAbsK(n,r.domain_length(2.25,4),2.25)
    opts=[r.NewtonOptions(predictor='euler'),r.NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='euler'),
          r.NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='constant')]
    solvers=[r.FixedPatternRadau(model,o,True) for o in opts]
    dt=r.crossing_time(2.25,4)/k
    if abs(k*start-round(k*start))>1e-7 or abs(k*end-round(k*end))>1e-7:
        raise ValueError('off-lattice checkpoint')
    for i in range(round(start*k),round(end*k)):
        for solver in solvers:
            try:
                u,_=solver.step(u,dt)
                break
            except r.NewtonFailure as exc:
                message=str(exc)
        else:
            raise RuntimeError(f'N={n}, tau={(i+1)/k}: {message}')
    return u


def prep(r,args,j,n):
    dest=args.out/f'section_j{j}_N{n}.npz'
    if dest.exists():
        return
    if j==1 and n==1800:
        profile=pd.read_csv(args.exports/'returns/profile_return1_N1800.csv')
        u=profile.u.to_numpy(); t=float(profile.tau.iloc[0])
    elif n==900:
        t={1:1.12,4:3.25}[j]
        with np.load(args.experiments/'results/project900/fields.npz') as z:
            i=np.flatnonzero(z['step']==round(3200*t)).item()
            u=z['u'][i].copy()
    elif n==1800 and j==4:
        with np.load(args.experiments/'results/fine_fourth/near_integer.npz') as z:
            u=z['u4'].copy();t=float(z['tau'])
    else:
        raise ValueError('unsupported section')
    k=12800 if j==4 else 3200
    z=evolve(r,n,u,t,j+.125,k)
    np.savez_compressed(dest,u=z,tau=j+.125,steps_per_crossing=k)


def summarize(args):
    reg=pd.read_csv(args.exports/'regularization/fase6/results/analysis/refinement.csv')
    reg=reg.loc[(reg.dimension=='spatial')&(reg.N0==900)&(reg.N1==1800)&
                (reg.dtdiv0==1)&(reg.dtdiv1==1)].copy()
    assert len(reg)==12 and np.allclose(reg.tau_end,reg['return']+.125)
    rows=[dict(j=int(v['return']),nu=v.nu,tau=v.tau_end,divisor=1,error=v.final_L2,
               source='regularized full-field refinement export') for _,v in reg.iterrows()]
    baseline=pd.read_csv(args.exports/'returns/field_comparisons.csv')
    coarse=pd.read_csv(args.exports/'returns/modes_N900.csv')
    for j in (1,2,3,4):
        t=j+.125
        if j in (2,3):
            err=baseline.loc[(baseline.Ncoarse==900)&(baseline.tau==t)].iloc[0].L2_unaligned
            c=coarse.loc[coarse.tau==t].iloc[0]
            # Qosc = 2 sum of oscillatory Parseval power (initial energy = 1/2).
            err=err/np.sqrt(c.Qosc+2*c.E0)
            src='production field difference and exact contemporaneous coarse norm by Parseval'
        else:
            with np.load(args.out/f'section_j{j}_N900.npz') as x,np.load(args.out/f'section_j{j}_N1800.npz') as y:
                assert x['tau']==t==y['tau']
                uc=x['u'];uf=y['u']
            err=np.linalg.norm(uc-uf[::2])/np.linalg.norm(uc)
            src='replayed coarse and fine fields at common time section'
        rows.append(dict(j=j,nu=0.,tau=t,divisor=4 if j==4 else 1,error=err,source=src))
    table=pd.DataFrame(rows).sort_values(['j','nu'])
    table.to_csv(args.out/'matched_field_sections.csv',index=False)
    wide=100*table.pivot(index='j',columns='nu',values='error')
    print(wide.to_string())
    lines=[r'\begin{table}[!htbp]\centering\small',r'\caption{Relative full-field differences (percent) between the $900$- and $1800$-node solutions at common time sections, normalized by the instantaneous $900$-node norm. Fine-grid values are sampled on coarse nodes. At the fourth section, both $\nu=0$ runs use the quarter step after $\tau=3.25$; all positive-$\nu$ runs use the base step throughout.}',r'\label{tab:commonfield}',r'\begin{tabular}{@{}crrrr@{}}\toprule',r'$\tau$ & $\nu=0$ & $0.00025$ & $0.001$ & $0.004$\\\midrule']
    for j,values in wide.iterrows():
        lines.append(' & '.join([f'{j+.125:.3f}']+[f'{value:.2f}' for value in values])+r'\\')
    lines.extend([r'\bottomrule\end{tabular}',r'\end{table}'])
    (args.out/'matched_field_sections.tex').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exports',required=True,type=Path)
    parser.add_argument('--experiments',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path)
    parser.add_argument('--section',choices=('j1-900','j1-1800','j4-900','j4-1800','summary'),required=True)
    a=parser.parse_args()
    if a.section=='summary':
        summarize(a)
    else:
        sys.path.insert(0,str(a.experiments.resolve()))
        import compare_radau
        jj,nn=a.section[1:].split('-')
        prep(compare_radau,a,int(jj),int(nn))
