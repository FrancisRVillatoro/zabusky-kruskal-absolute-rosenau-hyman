"""Local finite-grid measurements for periodic one-dimensional waves."""
import numpy as np


def crossing_stats(u, length, residual=None):
    """One row per zero, including sign, cell increment and width between levels ±0.05.

    Field normalized to peak amplitude of the initial cosine, A=1. The width
    is determined on the two branches adjacent to the crossing, interpolating
    linearly; it labels a threshold interval and does not assume a shock.
    """
    u = np.asarray(u)
    n = len(u)
    h = length/n
    u_next = np.roll(u, -1)
    # Sign convention assigns a zero grid node to only one bracketing cell.
    crossed = np.flatnonzero((u < 0) != (u_next < 0))
    items = []
    for i in crossed:
        jump = u_next[i] - u[i]
        sgn = np.sign(jump)
        offset = -u[i] / jump
        zero = (i + offset) % n
        distances = np.arange(-n//2, n//2)
        signed = sgn*u[(i+distances) % n]
        left = np.flatnonzero((distances<=0) & (signed<=-.05))
        right = np.flatnonzero((distances>=1) & (signed>=.05))
        width = np.nan
        if len(left) and len(right):
            j,k=left[-1],right[0]
            xa=distances[j]+(-.05-signed[j])/(signed[j+1]-signed[j])
            xb=distances[k-1]+(.05-signed[k-1])/(signed[k]-signed[k-1])
            width=(xb-xa)*h
        slopes_5 = (u[(i+np.array([-5,5])+1)%n]-u[(i+np.array([-5,5]))%n])/h
        items.append(dict(cell=int(i), zero_over_L=zero/n, orientation=int(sgn),
                          cell_increment=abs(jump), cell_slope=abs(jump)/h,
                          slope_minus5=abs(slopes_5[0]), slope_plus5=abs(slopes_5[1]),
                          level_width_pm005=width, level_width_cells=width/h))
    return items


