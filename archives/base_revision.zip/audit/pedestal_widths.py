"""Exact positive-background K(2,2) solitary-pulse widths vs native observed half prominences."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.integrate import quad


def width(a,b):
    """Full width at U=(a+b)/2; peak a, asymptotic level b (0 <= b < a)."""
    a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float)
    q=a*b/(2*a+b)
    theta=np.arcsin(np.sqrt((a-b)/(2*(a+q))))
    ratio=(b+q)/(a-b)
    term=np.divide(b,np.sqrt((a-b)*(b+q)),out=np.zeros_like(theta),where=b>0)
    return 8*(theta + term*np.arctanh(np.sqrt(ratio)*np.tan(theta)))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--exports',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    for b in (0.,.001,.05,.2,.5,.99):
        a=1.;q=a*b/(2*a+b)
        th=np.arcsin(np.sqrt((a-b)/(2*(a+q))))
        independent=quad(lambda z:8*(a-(a+q)*np.sin(z)**2)/(a-b-(a+q)*np.sin(z)**2),0,th)[0]
        assert np.isclose(width(a,b),independent,rtol=1e-12) and np.isclose(width(1.,0.),2*np.pi)
    path=args.exports/'pulse_morphology/fase5/results/analysis/peaks.csv'
    raw=pd.read_csv(path)
    t=raw.loc[(raw['case']=='P_p2_M8') & (raw.N==4000) &
              (raw.role=='space_high') & (raw.tau>=.25)].copy()
    # Exactly the contour used to measure the output widths by peak_widths(...,rel_height=.5).
    a=t.u_peak.to_numpy(); b=(t.u_peak-t.prominence).to_numpy()
    assert (b>0).all() and (a>b).all()
    t['prominence_floor']=b
    t['effective_c']=3*(a+b)**2/(2*(2*a+b))
    t['exact_W_over_Wp']=width(a,b)/(4*np.pi)
    t['zero_floor_W_over_Wp']=.5
    t['abs_error_pedestal_Wp']=abs(t.exact_W_over_Wp-t.fwhm_over_Wp)
    t['abs_error_zero_Wp']=abs(.5-t.fwhm_over_Wp)
    keys=['tau','peak_id','u_peak','prominence_floor','effective_c','fwhm_over_Wp',
          'exact_W_over_Wp','zero_floor_W_over_Wp','abs_error_pedestal_Wp','abs_error_zero_Wp']
    t[keys].to_csv(args.out/'single_pulse_exact_widths.csv',index=False)
    def summary(g):
        return dict(n_peaks=len(g),n_snapshots=g.tau.nunique(),
                    median_measured_Wp=g.fwhm_over_Wp.median(),
                    median_exact_predicted_Wp=g.exact_W_over_Wp.median(),
                    median_abs_error_pedestal_Wp=g.abs_error_pedestal_Wp.median(),
                    median_abs_error_zero_Wp=g.abs_error_zero_Wp.median(),
                    fraction_predicted_broader=(g.exact_W_over_Wp>g.fwhm_over_Wp).mean(),
                    fraction_pedestal_closer=(g.abs_error_pedestal_Wp<g.abs_error_zero_Wp).mean())
    rows=[dict(sample='all',**summary(t))]
    for tau in (.25,.5,1.,2.):
        rows.append(dict(sample=str(tau),**summary(t.loc[np.isclose(t.tau,tau)])))
    pd.DataFrame(rows).to_csv(args.out/'single_pulse_exact_summary.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False))


if __name__=='__main__':
    main()
