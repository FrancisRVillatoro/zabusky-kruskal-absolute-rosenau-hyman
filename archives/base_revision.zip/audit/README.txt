Numerical checks for the revised absolute K(p,p) manuscript

Rebuild the primary-table audits from the existing supplement, using Python
with NumPy, pandas and Matplotlib.

  python3 audit_returns.py --exports /absolute/path/to/exports --out results

The tables report observed spreads, signed refinement increments and log2
increment ratios. Their values do not constitute estimated continuum error
bars. The frozen linear Radau cutoff is the first mode meeting the amplitude
criterion, evaluated in both the full integer and the projected odd mode sets.
I_baseline.csv contains signed endpoint changes; last-block maxima in the
manuscript are read separately from fourth_return/retornos4b.csv.

Cross-resolution profile reconstruction

With the compare_radau.py calculation and results under /path/to/experiments,
the following commands create raw per-grid return fields at the published
sampled times, the crossing inventory, the field provenance comparison and
the overlaid zero-crossing figure.

  python3 replay_at_archive_times.py --experiments /path/to/experiments --exports /path/to/exports --out results
  python3 replayed_widths.py --experiments /path/to/experiments/results --exports /path/to/exports --out results

For N=450,900 the study advances from saved replay fields to each catalogued
return time using the original solver and the base time step. The N=1800
fields at the first three minima are the all-node production CSVs. The fourth
fine-grid field is the quarter-step replay of the final block using the
archived third-return field and the original base step up to tau=3.25.
profile_provenance.csv records every event time and its depth difference from
the archival value. zero_refinement.csv records all sign changes. When a
lobe contains several increasing zeros, the plot uses the steepest increasing
crossing in the increasing lobe of the phase-matched fundamental. Threshold
width is the distance between the nearest flanking levels ±0.05, via linear
interpolation, and can include multiple crossings. A missing width indicates
that the required flanking pair was not found.

Optional read-only postprocessing of the original Picasso HDF5s

From the original project root containing fase3/, fase4/, fase4b/ and fase6/
(where the production HDF5s were created), with this folder at /path/to/audit:

  sbatch /path/to/audit/picasso_fields.slurm /path/to/audit

Alternatively, in an environment with NumPy and h5py:

  python3 /path/to/audit/picasso_fields.py --root . --out cnsns_review_fields

The HDF5 collector writes the profiles and zero statistics at every spatial
resolution covered by the production catalog, the finest-grid pair for three
fixed positive viscosities, and the extra fourth-return time refinements at
zero viscosity. It reports spatial relative L2 discrepancies with the same
initial norm, same [j−0.1,j+0.1] window and identical saved times in all four
viscosities. The zero-viscosity j=4 pair uses the quarter-step continuation
on both grids. Positive viscosities use their production base step. For j=1,
the baseline and fine-output replay are combined, matching the source order
in the original analysis. Incomplete trajectories are never used. Missing
inputs are listed in unavailable.csv, with a nonzero exit. A new destination
is required. Production files must be accessible to exercise this extraction.

Exact isolated K(2,2) positive-background pulse-width comparator

  python3 pedestal_widths.py --exports /absolute/path/to/exports --out results

The measured crest and the prominence floor specify the homoclinic comparator
and its speed. Full width is evaluated at the very same half-prominence level
as in the original measurements. The closed form is checked against numerical
quadrature including the zero-pedestal compacton limit. All 1,101 nominal
peak observations in the 176 snapshots are retained. The floor is a prominence
contour, not an assertion that the field has an asymptotically uniform pedestal.

Identical-time, identical-denominator full-field comparison at four sections

  python3 matched_field_sections.py --experiments /path/to/experiments --exports /path/to/exports --out results --section j1-900
  python3 matched_field_sections.py --experiments /path/to/experiments --exports /path/to/exports --out results --section j1-1800
  python3 matched_field_sections.py --experiments /path/to/experiments --exports /path/to/exports --out results --section j4-900
  python3 matched_field_sections.py --experiments /path/to/experiments --exports /path/to/exports --out results --section j4-1800
  python3 matched_field_sections.py --experiments /path/to/experiments --exports /path/to/exports --out results --section summary

The table uses the actual full-field error at tau=j+0.125 on the nested grids
900 and 1800 for all four physical viscosities. Its normalization is always
the instantaneous coarse-field norm. The positive-viscosity rows are exactly
the recorded endpoint ("final_L2") in the production refinement table. For the
second and third unregularized sections the archived full-field discrepancy
has been converted from the initial norm to the contemporaneous coarse norm by
Parseval's identity: relative factor 1/sqrt(Qosc+2 E0). Unregularized sections
one and four use replayed fields at precisely those times. At the fourth
section both unregularized grids use quarter steps after tau=3.25. No
interpolation in time or space is used. These four sections do not represent
maxima over the windows. The separate read-only HDF5 procedure above can
produce maxima on an explicitly common time sample and norm.
