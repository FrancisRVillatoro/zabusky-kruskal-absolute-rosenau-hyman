"""Extract zero profiles and like-for-like field discrepancies from the production HDF5s.
Run in the Picasso project with --root . --out cnsns_review_fields .
"""
import argparse
import csv
import json
from pathlib import Path

import numpy as np

from zero_metrics import crossing_stats

P = 2.25
CASE = 'Z_p225_M4'
L = 2*np.pi*4*P/(P-1)
TC = L*2*P/(P+1)
TICKS = 12800
POSITIVE = {0.00025: '0p00025', 0.001: '0p001', 0.004: '0p004'}


def window(path, n, nu, divisor, lo, hi):
    import h5py
    with h5py.File(path, 'r') as f:
        if f.attrs.get('status') != 'COMPLETED':
            raise ValueError('incomplete HDF5')
        cfg = json.loads(f.attrs['config_json'])
        if (cfg['N'] != n or cfg['p'] != P or cfg['M'] != 4 or cfg['family'] != 'Z'
                or cfg['nu'] != nu or cfg['project_half'] is not True
                or not np.isclose(cfg['dt']*3200*divisor, TC, atol=1e-9, rtol=0)
                or (nu and (cfg['regularization'] != 'fourth_order' or cfg['strict']))):
            raise ValueError('run metadata mismatch')
        t = f['t'][:]/TC
        ticks = np.rint(t*TICKS).astype(int)
        if (np.any(np.diff(ticks) <= 0) or np.max(np.abs(t-ticks/TICKS)) > 1e-9
                or f['u'].shape != (len(t), n) or f['diagnostics'].shape != (len(t), 10)):
            raise ValueError('inconsistent time series')
        sl = slice(np.searchsorted(ticks, round(lo*TICKS)),
                   np.searchsorted(ticks, round(hi*TICKS), side='right'))
        u, d = f['u'][sl], f['diagnostics'][sl,5]
        if not len(u) or not np.isfinite(u).all() or not np.isfinite(d).all():
            raise ValueError('empty or nonfinite window')
        return {int(k): (v, float(e), str(path)) for k,v,e in zip(ticks[sl],u,d)}


def collect(root, n, nu, j, div=1):
    bounds = j-.21, j+.21
    if nu:
        kind = 'short' if j == 1 else 'long'
        suffix = '' if j == 1 else f'_seg{j}'
        path = root/'fase6/results'/kind/f'{CASE}_nu{POSITIVE[nu]}_N{n}_d1{suffix}.h5'
        return window(path, n, nu, 1, *bounds)
    if j == 1:
        role = {450:'low',900:'mid',1800:'high'}[n]
        problems = []
        for name in ('combined_fixed','rescue_fixed','main'):
            path = root/'fase3/results'/name/f'{CASE}__space_{role}.h5'
            try:
                samples = window(path, n, 0., div, *bounds)
                break
            except (OSError, ValueError) as exc:
                problems.append(str(path)+' '+str(exc))
        else:
            raise ValueError(' | '.join(problems))
        path = root/'fase4/results/zoom1'/f'{CASE}_N{n}_zoom1.h5'
        samples.update(window(path, n, 0., div, .94, 1.10))
        return samples
    if div == 1:
        path = root/'fase4/results/long'/f'{CASE}_N{n}_seg{j}.h5'
    else:
        path = root/'fase4b/results'/f'dt_divisor_{div}'/f'{CASE}_N{n}_seg4_dtdiv{div}.h5'
    return window(path, n, 0., div, *bounds)


def at_minimum(samples,j):
    ticks=np.array(sorted(samples))
    d=np.array([samples[k][1] for k in ticks])
    lo, hi=(.94,1.10) if j==1 else (j-.20,j+.20)
    i=np.flatnonzero((d[1:-1]<=d[:-2]) & (d[1:-1]<=d[2:]) &
                     ((d[1:-1]<d[:-2])|(d[1:-1]<d[2:])))+1
    i=i[(ticks[i]>round(lo*TICKS))&(ticks[i]<round(hi*TICKS))]
    if not len(i):
        raise ValueError('no interior minimum')
    return int(ticks[i[np.argmin(d[i])]])


def budget(series, j):
    """Take the maximum on the same saved times for all four regularizations."""
    lo,hi=round((j-.1)*TICKS),round((j+.1)*TICKS)
    ticks=sorted(k for k in set.intersection(*(set(v) for v in series.values())) if lo<=k<=hi)
    if len(ticks)<3 or ticks[0]!=lo or ticks[-1]!=hi:
        raise ValueError('missing common field comparison interval')
    rows=[]
    for nu in [0.,*POSITIVE]:
        diffs=[]
        for tick in ticks:
            coarse=series[900,nu][tick][0]
            fine=series[1800,nu][tick][0][::2]
            diffs.append(np.linalg.norm(fine-coarse)/np.sqrt(len(coarse)/2))
        imax=int(np.argmax(diffs))
        rows.append(dict(j=j,nu=nu,divisor=(4 if j==4 and nu==0 else 1),
                         t_start=ticks[0]/TICKS,t_end=ticks[-1]/TICKS,n_common=len(ticks),
                         max_L2_relative_to_initial=diffs[imax],tau_max=ticks[imax]/TICKS))
    return rows


def write_csv(out,name,rows):
    if not rows:
        return
    with (out/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path)
    a=parser.parse_args()
    # Each execution has a separate destination, so partial attempts cannot mix results.
    a.out.mkdir(parents=True,exist_ok=False)
    cross=[]; profiles=[]; fields=[]; missing=[]
    for j in (1,2,3,4):
        primary={}
        runs=[(n,0.,1) for n in (450,900,1800) if (j,n)!=(4,1800)]
        if j==4:
            runs.extend((n,0.,div) for n in (900,1800) for div in (2,4))
        runs.extend((n,nu,1) for n in (900,1800) for nu in POSITIVE)
        for n,nu,div in runs:
            try:
                samples=collect(a.root,n,nu,j,div)
                k=at_minimum(samples,j)
                u,d,path=samples[k]
                coef=np.fft.rfft(u)/n
                ref=np.cos(2*np.pi*np.arange(n)/n+np.angle(coef[1]))
                residual=u-ref
                if not np.isclose(d,np.sqrt(2*np.mean(residual**2)),rtol=1e-7,atol=1e-11):
                    raise ValueError('D disagrees with translated cosine')
                starts=dict(j=j,N=n,nu=nu,divisor=div,tau=k/TICKS,D=d,source=path)
                for z in crossing_stats(u,L):
                    cross.append(dict(**starts,**z))
                for i,v in enumerate(u):
                    profiles.append(dict(**starts,index=i,x=i*L/n,u=float(v),
                                         aligned_initial=float(ref[i]),residual=float(residual[i])))
                if n in (900,1800) and div==(4 if j==4 and nu==0 else 1):
                    primary[n,nu]=samples
            except (OSError,KeyError,ValueError) as exc:
                missing.append(dict(j=j,N=n,nu=nu,divisor=div,problem=str(exc)))
        if len(primary)==8:
            try:
                fields.extend(budget(primary,j))
            except ValueError as exc:
                missing.append(dict(j=j,N='900/1800',nu='all',divisor='',problem=str(exc)))
    write_csv(a.out,'zero_crossings.csv',cross)
    write_csv(a.out,'return_profiles.csv',profiles)
    write_csv(a.out,'common_field_budget.csv',fields)
    write_csv(a.out,'unavailable.csv',missing)
    print(f'{len(cross)} crossings, {len(fields)}/16 common-window budgets; {len(missing)} issues')
    return int(bool(missing))


if __name__=='__main__':
    raise SystemExit(main())
