#!/bin/bash -l
#SBATCH --job-name=absk_fields
#SBATCH --constraint=cpu
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=00:30:00
#SBATCH --output=absk_fields_%j.out

set -euo pipefail
: "${1:?Pass the absolute directory containing picasso_fields.py}"
cd "$SLURM_SUBMIT_DIR"
module load python/3.14.3
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python3 "$1/picasso_fields.py" --root . --out "cnsns_review_fields_${SLURM_JOB_ID}"
