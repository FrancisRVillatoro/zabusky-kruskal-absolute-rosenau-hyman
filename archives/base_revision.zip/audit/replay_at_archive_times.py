"""Recover *exact saved production return times* between the coarse replay snapshots.

Use the same integrator and fixed-step Newton fallback as compare_radau.py. At
most 31 steps per event. This removes differences caused solely by the denser
new output sampling. See profile_provenance.csv for the actual depth mismatch.
"""
import argparse
import importlib
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--experiments',required=True,type=Path,help='directory containing compare_radau.py and results')
    p.add_argument('--exports',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    a=p.parse_args()
    sys.path.insert(0,str(a.experiments.resolve()))
    r=importlib.import_module('compare_radau')
    catalog=pd.read_csv(a.exports/'return_checks/huella_modal_retornos.csv').rename(columns={'return':'j'})
    a.out.mkdir(parents=True,exist_ok=True)
    for n in (450,900):
        root=a.experiments/'results'/f'project{n}'
        if not (root/'status.json').is_file():continue
        with np.load(root/'fields.npz') as z:
            steps=z['step']; snapshots=z['u']
        k=json.loads((root/'status.json').read_text())['k']
        model=r.PeriodicAbsK(n,r.domain_length(2.25,4),2.25)
        solvers=[r.FixedPatternRadau(model,r.NewtonOptions(predictor='euler'),True),
                 r.FixedPatternRadau(model,r.NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='euler'),True),
                 r.FixedPatternRadau(model,r.NewtonOptions(max_iter=28,line_search_backtracks=20,predictor='constant'),True)]
        saved={}
        for row in catalog.loc[catalog.N==n].itertuples():
            target=round(k*row.tau)
            if np.abs(k*row.tau-target)>1e-8 or steps[-1]<target:continue
            i=np.searchsorted(steps,target,side='right')-1
            u=snapshots[i].copy()
            for step in range(steps[i],target):
                for solver in solvers:
                    try:
                        u,_=solver.step(u,r.crossing_time(2.25,4)/k)
                        break
                    except r.NewtonFailure as exc:
                        message=str(exc)
                else:
                    raise RuntimeError(f'profile N={n}, step {step+1}: {message}')
            saved[f'u{row.j}']=u;saved[f'step{row.j}']=target
        np.savez_compressed(a.out/f'archive_times_N{n}.npz',**saved)


if __name__=='__main__':
    main()
