"""Recompute refinement envelopes, near-zero profiles and invariant/filter diagnostics.

Usage: python audit_returns.py --exports /path/to/supplement/exports --out audit_output
All inputs are numerical tables distributed with the article. Nothing here integrates the PDE.
"""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from zero_metrics import crossing_stats

P = 2.25
L = 2*np.pi*4*P/(P-1)
TC = L*2*P/(P+1)


def zeros(exports, out):
    figure,axes=plt.subplots(1,2,figsize=(6.8,2.85),layout='constrained')
    profiles=[]; full=[]
    for j,color,ls in [(1,'#275b87','-'),(2,'#b15732','--'),(3,'#22765c','-.')]:
        df=pd.read_csv(exports/'returns'/f'profile_return{j}_N1800.csv')
        u=df.u.to_numpy(); res=df.residual.to_numpy(); n=len(u); x=df.x.to_numpy()
        assert np.max(np.abs(x-np.arange(n)*L/n))<1e-10
        rows=crossing_stats(u,L)
        for row in rows: profiles.append(dict(j=j,N=n,tau=df.tau.iloc[0],**row))
        c=next(k for k in rows if k['orientation']==1); z=c['zero_over_L']*n
        idx=np.arange(c['cell']-12,c['cell']+14); ax=axes[0]
        ax.plot(idx-z,u[idx%n],color=color,ls=ls,marker='o',ms=2.0,lw=1.05,label=f'$j={j}$')
        fr=[]; eff=[]
        for level in (.05,.1,.15,.2,.25,.3,.4,.5):
            mask=np.abs(u)<level
            frac=np.dot(res[mask],res[mask])/np.dot(res,res)
            full.append(dict(j=j,level=level,area_fraction=mask.mean(),residual_fraction=frac))
            fr.append(100*mask.mean());eff.append(100*frac)
        axes[1].plot(fr,eff,color=color,ls=ls,marker='o',ms=2.3,lw=1.2,label=f'$j={j}$')
        axes[1].scatter(fr[3],eff[3],s=27,facecolor='white',edgecolor=color,zorder=4)
    axes[0].axvline(0,color='.68',lw=.6);axes[0].axhline(0,color='.68',lw=.6)
    axes[0].set(xlabel=r'$(x-x_0)/h$',ylabel=r'$u$',xlim=(-12,12),title='(a)  Increasing zero')
    axes[1].plot([0,40],[0,40],ls=':',lw=.65,c='.4')
    axes[1].set(xlabel='Domain fraction (%)',ylabel='Squared residual inside (%)',
                title='(b)  Localization near both zeros',ylim=(0,101))
    for a in axes:
        a.spines[['top','right']].set_visible(False)
        a.legend(frameon=False,fontsize=8)
        a.grid(axis='y',alpha=.18)
    figure.savefig(out/'zero_structure.pdf',bbox_inches='tight')
    plt.close(figure)
    pd.DataFrame(profiles).to_csv(out/'crossings.csv',index=False)
    pd.DataFrame(full).to_csv(out/'localization.csv',index=False)


def envelopes(exports,out):
    early=pd.read_csv(exports/'return_checks/huella_modal_retornos.csv').rename(columns={'return':'j'})
    early['step_divisor']=1
    late=pd.read_csv(exports/'fourth_return/retornos4b.csv')
    late=late.loc[late.dt_divisor>1].rename(columns={'dt_divisor':'step_divisor'})
    late['j']=4
    observables=['tau','D','r','H','e5_over_H','Phi1']
    sets=pd.concat([early,late],ignore_index=True)
    budget=[]
    for j, group in sets.groupby('j'):
        for scope,g in [('all',group),('N_ge_900',group.loc[group.N>=900])]:
            for obs in observables:
                budget.append(dict(j=j,scope=scope,observable=obs,minimum=g[obs].min(),
                                   maximum=g[obs].max(),n_runs=len(g)))
    pd.DataFrame(budget).to_csv(out/'scalar_envelopes.csv',index=False)
    pobs=[]
    for j in [1,2,3]:
        group=early.loc[early.j==j].sort_values('N')
        for obs in observables:
            lower,upper=np.diff(group[obs].to_numpy())
            pobs.append(dict(j=j, observable=obs, delta900_450=lower,delta1800_900=upper,
                             log2_abs_increment_ratio=np.log2(abs(lower/upper)) if lower*upper!=0 else np.nan,
                             same_sign=bool(lower*upper>0)))
    pd.DataFrame(pobs).to_csv(out/'scalar_grid_ratios.csv',index=False)
    fields=pd.read_csv(exports/'returns/field_budget.csv')
    for metric in ['max_L2_window','max_L2_aligned_window']:
        table=fields.pivot(index='return',columns='Ncoarse',values=metric)
        fields.loc[fields.Ncoarse==450, f'log2_{metric}_ratio']=fields.loc[fields.Ncoarse==450,'return'].map(np.log2(table[450]/table[900]))
    fields.to_csv(out/'field_error_orders.csv',index=False)


def radau_filter(exports,out):
    """First positive integer index at which one crossing halves a Fourier amplitude.

    R is the [2/3] Padé approximant to exp(z). The stencil symbol is computed
    from the actual mass and derivative weights rather than the continuum k-k^3.
    """
    rows=[]
    for n in (450,900,1800):
        h=L/n; modes=np.arange(1,n//2); th=2*np.pi*modes/n
        mass=(66+52*np.cos(th)+2*np.cos(2*th))/120
        imagB=(20*np.sin(th)+2*np.sin(2*th))/(24*h)
        imagC=(2*np.sin(2*th)-4*np.sin(th))/(2*h**3)
        for div in (1,2,4):
            steps=3200*div; z=-1j*P*(imagB+imagC)*TC/(mass*steps)
            gain=np.abs((1+2*z/5+z*z/20)/(1-3*z/5+3*z*z/20-z**3/60))
            log_gain=steps*np.log(gain)
            i=np.flatnonzero(log_gain<=np.log(.5))[0]
            rows.append(dict(N=n,step_divisor=div,steps_per_crossing=steps,
                             frozen_derivative=P,first_mode=int(modes[i]),first_active_odd=int(modes[(modes%2==1)&(log_gain<=np.log(.5))][0]),k=2*np.pi*modes[i]/L,
                             crossing_amplitude_gain=np.exp(log_gain[i]),
                             preceding_gain=np.exp(log_gain[i-1])))
    pd.DataFrame(rows).to_csv(out/'radau_cutoffs.csv',index=False)
    spectra=[]
    for j in (1,2,3):
        s=pd.read_csv(exports/'returns'/f'profile_return{j}_N1800.csv')
        u=s.u.to_numpy();coef=np.fft.rfft(u)/len(u)
        power=2*abs(coef)**2;power[-1]/=2; high=power[2:].sum()
        spectra.append(dict(j=j,share_13_through_30=power[13:31].sum()/high,
                            share_22_and_above=power[22:].sum()/high))
    pd.DataFrame(spectra).to_csv(out/'high_band.csv',index=False)


def invariants(exports,out):
    baseline={}; observations=[]
    for n in [450,900,1800]:
        modes=pd.read_csv(exports/'returns'/f'modes_N{n}.csv').set_index('tau')
        initial=modes.loc[0,'I_p1'];baseline[n]=initial
        for a,b in [(0,1),(1,2),(2,3),(3,3.25),(3.25,4.25)]:
            if b in modes.index:
                ia,ib=modes.loc[a,'I_p1'],modes.loc[b,'I_p1']
                observations.append(dict(N=n,step_divisor=1,tau_start=a,tau_end=b,I_start=ia,I_end=ib,
                                         percent_signed_change=100*(ib-ia)/ia))
    pd.DataFrame(observations).to_csv(out/'I_baseline.csv',index=False)
    reg=exports/'regularization/fase6/results/analysis'
    weak=pd.read_csv(reg/'weak_summary.csv')
    weak.groupby('N',as_index=False).max_relative.max().to_csv(out/'fourier_tests.csv',index=False)
    rc=pd.read_csv(reg/'return_catalog.csv')
    rc=rc.loc[(rc.project_half==1)&(rc.strict==0)&(rc.dt_divisor==1)&(rc.regularization=='fourth_order')].copy()
    assert np.max(abs(rc.loc[rc['index']==1,'tau']-1))<.06
    rc['percent_cumulative_I_change']=100*(rc.I_p1/rc.N.map(baseline)-1)
    rc[['N','nu','index','tau','D','I_p1','percent_cumulative_I_change']].to_csv(out/'I_regularized_at_returns.csv',index=False)


def pulse(exports,out):
    raw=pd.read_csv(exports/'pulse_morphology/fase5/results/analysis/snapshots.csv')
    t=raw.loc[(raw['case']=='P_p2_M8')&(raw['role']=='space_high')&(raw.N==4000)&(raw.tau>=.25)].copy()
    assert len(t)==176
    rows=[]
    for lo,hi in [(.25,.5),(.5,1),(1,1.5),(1.5,2)]:
        a=t.loc[(t.tau>=lo)&((t.tau<hi) if hi<2 else (t.tau<=hi))]
        rows.append(dict(tau_start=lo,tau_end=hi,n=len(a),mean_min_over_max=a.minimum_over_peak.mean(),mean_min=a.min_value.mean()))
    pd.DataFrame(rows).to_csv(out/'P_background_windows.csv',index=False)
    w=t.fwhm_median_Wp
    pstats=pd.DataFrame([dict(n=len(t),w_mean=w.mean(),w_sd_pop=w.std(ddof=0),w_min=w.min(),w_max=w.max(),
                             n_count_sensitive=np.sum(t.n_peak_sensitivity_min!=t.n_peak_sensitivity_max),
                             min_ratio=t.minimum_over_peak.min(),max_ratio=t.minimum_over_peak.max())])
    pstats.to_csv(out/'P_all_snapshots.csv',index=False)


def matched_sign_control(exports, out):
    series = pd.read_csv(exports/'short_returns/series_25.csv')
    pulse_curves = pd.read_csv(exports/'pulse_morphology/fase5/results/analysis/field_curves.csv')
    horizon = 1.5
    matched = pulse_curves.loc[(pulse_curves.tau<=horizon+1e-10) &
                               (pulse_curves['case']=='P_p2_M4') &
                               (pulse_curves.comparison=='space_mid_vs_space_high')]
    z_fields = pd.read_csv(exports/'verification/fase3/results/analysis_partial/partial_comparisons.csv')
    z_fields = z_fields.loc[(z_fields['case']=='Z_p2_M4') &
                            (z_fields.comparison=='space_mid_vs_high')].iloc[0]
    rows = []
    for family, maximum in [('P',matched.norm_L2.max()),('Z',z_fields.normalized_max)]:
        a = series.loc[(series.run_id==f'{family}_p2_M4__space_high') &
                       (series.tau<=horizon+1e-10)]
        assert len(a)==len(matched)==151 and np.allclose(a.tau,matched.tau)
        drift = a.I_p1/a.I_p1.iloc[0]-1
        rows.append(dict(family=family,p=2,M=4,N_coarse=1000,N_fine=2000,
                         tau_end=horizon,n_times=len(a),max_l2_rel_u0=maximum,
                         max_fine_relative_invariant_change=drift.abs().max(),
                         end_signed_relative_invariant_change=drift.iloc[-1]))
    pd.DataFrame(rows).to_csv(out/'matched_sign_control.csv',index=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exports',required=True,type=Path)
    parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    for audit in (zeros,envelopes,radau_filter,invariants,pulse,matched_sign_control): audit(args.exports,args.out)


if __name__=='__main__':
    main()
