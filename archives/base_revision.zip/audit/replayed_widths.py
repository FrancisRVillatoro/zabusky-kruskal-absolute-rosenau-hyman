"""Compare near-zero structure at the native-grid sampled return minima.

Archive fields at N=1800,j=1..3 are read from exports. Lower resolutions and
the last N=1800 block use explicitly identified replay files. Every row also
carries the archived minimum and the difference in return depth and time.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from zero_metrics import crossing_stats


def make(exports, experiment, out):
    out.mkdir(parents=True,exist_ok=True)
    p=2.25; length=2*np.pi*4*p/(p-1); fine_spacing=length/1800
    archived=pd.read_csv(exports/'return_checks/huella_modal_retornos.csv').rename(columns={'return':'j'})
    catalog={(int(r.j),int(r.N)):(r.tau,r.D) for r in archived.itertuples()}
    fourth=pd.read_csv(exports/'fourth_return/retornos4b.csv')
    fine=fourth.loc[(fourth.N==1800)&(fourth.dt_divisor==4)].iloc[0]
    catalog[4,1800]=fine.tau,fine.D
    f,axes=plt.subplots(1,4,figsize=(8.4,2.45),sharex=True,sharey=True,layout='constrained')
    rows=[]; provenance=[];all_profiles=[]
    for j in (1,2,3,4):
        ax=axes[j-1]
        for n,color,marker in [(450,'#b7572b','s'),(900,'#1b7968','^'),(1800,'#1d5288','o')]:
            if n==1800 and j<4:
                d=pd.read_csv(exports/'returns'/f'profile_return{j}_N1800.csv')
                u=d.u.to_numpy();tau=float(d.tau.iloc[0]);origin='production CSV'
            elif n==1800:
                path=experiment/'fine_fourth/near_integer.npz'
                if not path.is_file():
                    continue
                with np.load(path) as z:
                    u=z['u4'];tau=float(z['tau'])
                origin='replay, production field at j=3, base to 3.25, quarter step thereafter'
            else:
                root=experiment/f'project{n}'
                if not (root/'status.json').is_file():
                    continue
                status=json.loads((root/'status.json').read_text())
                if status['last_tau']<j+.2:continue
                with np.load(out/f'archive_times_N{n}.npz') as z:
                    u=z[f'u{j}'];tau=float(z[f'step{j}'])/status['k']
                origin='replay from initial cosine, base step, production sampling time'
            assert len(u)==n and np.isfinite(u).all()
            Ft=np.fft.rfft(u)/n
            ref=np.cos(2*np.pi*np.arange(n)/n+np.angle(Ft[1]))
            residual=u-ref; depth=np.sqrt(2*np.mean(residual**2))
            base_tau,base_depth=catalog[j,n]
            identification=dict(j=j,N=n,origin=origin,tau=tau,D=depth,
                                archived_tau=base_tau,archived_D=base_depth,
                                tau_minus_archived=tau-base_tau,D_minus_archived=depth-base_depth)
            provenance.append(identification)
            crossed=crossing_stats(u,length)
            principal=max((c for c in crossed if c['orientation']==1 and
                           -np.sin(2*np.pi*c['zero_over_L']+np.angle(Ft[1]))>0),
                          key=lambda c:c['cell_slope'])
            for c in crossed:
                rows.append(dict(**identification,n_zeros=len(crossed),principal=(c is principal),**c))
            for i,v in enumerate(u):
                all_profiles.append(dict(j=j,N=n,tau=tau,index=i,x_over_L=i/n,u=float(v),
                                         aligned_initial=float(ref[i]),residual=float(residual[i])))
            c=principal
            idx=c['cell']+np.arange(-20,22)
            distance=(idx-c['zero_over_L']*n)*length/n
            use=np.abs(distance)<=13*fine_spacing
            ax.plot(distance[use],u[idx[use]%n],color=color,marker=marker,
                    ms=2.5,lw=.85,label=str(n),alpha=.96)
        ax.set_title(f'({chr(96+j)})  Return {j}',fontsize=10)
        ax.axvline(0,color='.5',lw=.5);ax.axhline(0,color='.5',lw=.5)
        ax.grid(axis='y',alpha=.18);ax.spines[['top','right']].set_visible(False)
    axes[0].set_ylabel('$u$')
    axes[0].legend(title='$N$',fontsize=7,title_fontsize=8,frameon=False,handlelength=1.5)
    f.supxlabel('Physical distance from increasing zero, $x-x_0$',fontsize=10)
    f.savefig(out/'zero_refinement.pdf',bbox_inches='tight')
    pd.DataFrame(rows).to_csv(out/'zero_refinement.csv',index=False)
    pd.DataFrame(provenance).to_csv(out/'profile_provenance.csv',index=False)
    pd.DataFrame(all_profiles).to_csv(out/'refinement_profiles.csv',index=False)
    print(f'{len(provenance)}/12 returns with raw profiles; figures and tables in {out}')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--exports',required=True,type=Path)
    p.add_argument('--experiments',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    a=p.parse_args();make(a.exports,a.experiments,a.out)
